# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyrig ht IBM Corp. 2019. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

# Load Data from CSV files
library(readr)
library(scales)

readDataset <- function(fileName) {read.csv(file.path(fileName))}

df <- readDataset("model output summary.csv")

month_order <- c("Jul-2018", "Aug-2018", "Sep-2018", "Oct-2018", "Nov-2018", "Dec-2018", "Jan-2019", "Feb-2019", "Mar-2019", "Apr-2019", "May-2019", "Jun-2019")
df$BILLING_MONTH <- factor(df$BILLING_MONTH, levels = month_order)

# split the data between historical and current billing period
# historical data has the actual target variable as well as the predictions 
# the current billing period data has predictions from the training notebook but no actuals

df_historical <- df[!is.na(df['actual']), ]

df_current_billing <- df %>% filter(BILLING_MONTH == "Jun-2019")
# the ordering hasn't been preserved
df_current_billing <- df_current_billing[order(-df_current_billing$predicted_probability),]


# get the latest month of data from historical data - use to find if customer in current billing month missed last payment
df_latest_hist_month <- df_historical[df_historical["BILLING_MONTH"]=="May-2019", ]
df_latest_hist_month <- select(df_latest_hist_month, "CUSTOMER_ID", "actual")
names(df_latest_hist_month)[names(df_latest_hist_month) == "actual"] <- "missed_payment_last_month"
df_current_billing <- merge(x=df_current_billing,y=df_latest_hist_month,by="CUSTOMER_ID",all.x=TRUE)

df_num_historical_missed_payments <- df_historical %>%
                                        group_by(CUSTOMER_ID) %>%
                                        summarize(total_num_missed_payments = sum(actual)) %>% 
                                        as.data.frame()

df_current_billing <- merge(x=df_current_billing,y=df_num_historical_missed_payments,by="CUSTOMER_ID",all.x=TRUE)

# calculate the billing amount less any balance overdue
df_historical["STANDARD_BILL_AMOUNT"] <- df_historical["TOTAL_TO_PAY"] - df_historical["OVERDUE_BALANCE"]

