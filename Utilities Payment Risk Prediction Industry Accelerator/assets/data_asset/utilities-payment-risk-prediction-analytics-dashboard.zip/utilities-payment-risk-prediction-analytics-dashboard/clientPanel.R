# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# Â© Copyright IBM Corp. 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.


clientPanel <- function() {
  
  tabPanel(
    "Client View",
    value = "clientPanel",
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 100% !important;
                      }
                      .html-widget.gauge svg {
                        height: 300px;
                        width: 600px;
                      }
                      "))
    ),
    shinyjs::useShinyjs(),
    shinyjs::extendShinyjs(text = refreshCode, functions = c("refresh")),
    
    fluidRow(
      column(3
      ),
      column(6, 
             panel(
               column(6,
                      h4("Personal Information", class="text-center"),
                      hr(),
                      uiOutput("clientInfo1")
               ),
               column(6,
                      h4("Current Billing Information", class="text-center"),
                      hr(),
                      uiOutput("clientInfo2")
               )
             )
      )
    ),
    fluidRow(
      column(4,
             panel(
               h2("Historical Billing Cycle Amounts"),
               plotOutput("montlyClientBill")
             )
      ),column(4,
               panel(
                 h2("Historical Billing Cycle Usage"),
                 plotOutput("monthlyusage")
               )
      ),
      column(4,
             panel(
               h2("Historical Missed Payment Probabilities"),
              plotOutput("monthlyPredictionProbability")
             )
      )
      
    ),
    fluidRow(
      panel(
        h3("Client Payment Risk Prediction "),
        br(),
        
        tags$div(
          id = "authPanel",
          column(4,
                 panel(
                   h4("Connect to IBM Cloud API"),
                   # textInput("hostname", "Hostname"),
                   #textInput("username", "REGION (e.g: us-south)"),
                   #tags$h4("Select Region"),
                   pickerInput(
                     inputId = 'username',
                     label = 'Select a Region',
                     choices = list("us-south","eu-de","eu-gb","jp_tok"),
                     options = pickerOptions(width = "auto", style = "btn-primary")
                   ),
                   passwordInput("password", "API KEY"),
                   actionButton("authBtn", "Authenticate API", class = "btn-primary btn-lg btn-block", style = "max-width:300px", disabled = TRUE),
                   tags$head(tags$style("#authError{color:red;}")),
                   verbatimTextOutput("authError")
                 ),
                 style = "max-width:360px;"
          )
        ),
        hidden(
          tags$div(
            id = "deploymentPanel",
            column(4,
                   panel(
                     tags$h4("Model Scoring Pipeline Deployment"),
                     pickerInput(
                       inputId = 'deploymentSelector',
                       label = 'Deployment Name:',
                       choices = list(),
                       options = pickerOptions(width = "auto", style = "btn-primary")
                     ),
                     tags$p(
                       tags$strong("Space Name: "),
                       textOutput(outputId = "space_name", inline = TRUE)
                     ),
                     tags$p(
                       tags$strong("GUID: "),
                       textOutput(outputId = "deployment_guid", inline = TRUE)
                     ),
                     tags$p(
                       tags$strong("Scoring Endpoint: "),
                       textOutput(outputId = "scoring_url", inline = TRUE),
                       style = "word-wrap: break-word"
                     )),
                   panel(actionButton("refresh", "Back to Home", class = "btn-primary btn-sm btn-block"))
                   
                   
                   
                   
            ),
            tags$div(id = "scoreBtnSection",
                     column(4,
                            br(),
                            actionButton(
                              "scoreBtn",
                              "Predict Missed Payment Probability",
                              class = "btn-primary btn-lg btn-block",
                              disabled = TRUE
                            ),
                            br(),
                            h4("Input JSON:"),
                            verbatimTextOutput("pipelineInput"),
                            br(),
                            tags$head(tags$style("#scoringError{color:red;}")),
                            verbatimTextOutput("scoringError"))
            ),
            column(8,
                   hidden(
                     tags$div(id = "scoringResponse")
                   )
            )
          )
        )
      )
      
    )
  )
  
}


# Reactive server variables store (pervades across all sessions)
serverVariables = reactiveValues(deployments = list(), token = '')

if(nchar(Sys.getenv('CP4D_HOSTNAME')) > 0 && nchar(Sys.getenv('CP4D_USERNAME')) > 0 && nchar(Sys.getenv('CP4D_PASSWORD')) > 0) {
  tryCatch({
    deploymentsResp = collectDeployments( Sys.getenv('CP4D_USERNAME'), Sys.getenv('CP4D_PASSWORD'), "utilities_payment_risk_prediction_scoring_pipeline_function_deployment")
    serverVariables$deployments <- deploymentsResp$deployments
    serverVariables$token = deploymentsResp$token
  }, warning = function(w) {
    print(w$message)
  }, error = function(e) {
    print(e$message)
  })
}
refreshCode <- "shinyjs.refresh = function() { location.reload(); }"
clientServer <- function(input, output, session, sessionVars) {
  observeEvent( input$refresh, {shinyjs::js$refresh()})
  
  observe({
    
    shinyjs::enable("scoreBtn")
    
    selectedCustomerID <- sessionVars$selectedClientId
    
    client_name <- paste(df_current_billing[df_current_billing["CUSTOMER_ID"]==selectedCustomerID, "FIRST_NAME"],df_current_billing[df_current_billing["CUSTOMER_ID"]==selectedCustomerID, "LAST_NAME"])
    client_email <- df_current_billing[df_current_billing["CUSTOMER_ID"]==selectedCustomerID, "EMAIL"]
    client_phone <- df_current_billing[df_current_billing["CUSTOMER_ID"]==selectedCustomerID, "PHONE_1"]
    credit_level=df_current_billing[df_current_billing["CUSTOMER_ID"]==selectedCustomerID, "CREDIT_HISTORY"]
    bill_due_date <- df_current_billing[df_current_billing["CUSTOMER_ID"]==selectedCustomerID, "DUE_DATE"]
    billing_month_total_to_pay <- df_current_billing[df_current_billing["CUSTOMER_ID"]==selectedCustomerID, "TOTAL_TO_PAY"]
    overdue_balance <- df_current_billing[df_current_billing["CUSTOMER_ID"]==selectedCustomerID, "OVERDUE_BALANCE"]
    client_missed_payment_last_month_flag <- df_current_billing[df_current_billing["CUSTOMER_ID"]==selectedCustomerID, "missed_payment_last_month"]
    client_total_missed_payments <- df_current_billing[df_current_billing["CUSTOMER_ID"]==selectedCustomerID, "total_num_missed_payments"]
   
    if (client_missed_payment_last_month_flag=="1") {
      client_missed_payment_last_month_flag <- "Yes"
    } else {
      client_missed_payment_last_month_flag <- "No"
    }
    
    
    bill_due_date <- as.character(bill_due_date)
    bill_due_date <- paste(substr(bill_due_date, 7, 8), substr(bill_due_date, 5, 6), substr(bill_due_date, 1, 4), sep="-")
    
    
    output$clientInfo1 <- renderUI({
      
      tags$ul( class = 'list-unstyled',
               tags$li(
                 tags$strong('Name: '), tags$span(class = "pull-right", client_name)
               ),
               tags$li(
                 tags$strong('ID: '), tags$span(class = "pull-right", selectedCustomerID)
               ),
               tags$li(
                 tags$strong('Email: '), tags$span(class = "pull-right", client_email)
               ),
               tags$li(
                 tags$strong('Phone: '),tags$span(class = "pull-right", client_phone)
               ),
               tags$li(
                 tags$strong('Credit Level: '), tags$span(class = "pull-right", credit_level)
               )
      )
    })
 
    output$clientInfo2 <- renderUI({
      tags$ul( class = 'list-unstyled',
               tags$li(
                 tags$strong('Bill Due Date: '), tags$span(class = "pull-right", bill_due_date)
               ),
               tags$li(
                 tags$strong('Bill Amount: '),tags$span(class = "pull-right", format(billing_month_total_to_pay,big.mark = ','))
               ),
               tags$li(
                 tags$strong('Overdue Balance: '), tags$span(class = "pull-right", format(overdue_balance,big.mark = ','))
               ),
               tags$li(
                 tags$strong('Missed Payment Last Month?: '), tags$span(class = "pull-right", client_missed_payment_last_month_flag)
               ),
               tags$li(
                 tags$strong('Number of Historical Missed Payments: '), tags$span(class = "pull-right", client_total_missed_payments)
               )
      )
    })  
    
    
    # plot the historical bill amounts
    df_historical_billing_client <- df_historical[df_historical["CUSTOMER_ID"]==selectedCustomerID, ]
    df_historical_billing_client <- select(df_historical_billing_client, "BILLING_MONTH", "TOTAL_TO_PAY", "STANDARD_BILL_AMOUNT", "OVERDUE_BALANCE","BASE_USAGE","ALTERNATE_USAGE","predicted_probability","actual")
    # ensure order is preserved
    df_historical_billing_client <- df_historical_billing_client[order(df_historical_billing_client$BILLING_MONTH),]
    
    # create a temporary dataset for stacked area chart
    df_temp <- melt(df_historical_billing_client,id.vars="BILLING_MONTH",measure.vars=c("STANDARD_BILL_AMOUNT","OVERDUE_BALANCE"))
    df_temp$variable <- factor(df_temp$variable , levels=c("OVERDUE_BALANCE", "STANDARD_BILL_AMOUNT") )
    
    output$montlyClientBill <- renderPlot({
      ggplot(df_temp, aes(x=BILLING_MONTH, y=value, fill=variable, group=variable)) + 
        geom_area(position='stack') +
        theme_minimal() +
        theme(legend.position = c(0.2, 1), axis.text.x = element_text(angle = 45, hjust = 1)) +
        labs(x = "Month", y = "Total Bill Amount")
    })
    
    df_historical_billing_client$TOTAL_USAGE = df_historical_billing_client$BASE_USAGE + df_historical_billing_client$ALTERNATE_USAGE 
    
    output$monthlyusage <-renderPlot({
      ggplot(df_historical_billing_client, aes(x=BILLING_MONTH,group = 1)) + 
        geom_area(aes(y=TOTAL_USAGE, fill="ALTERNATE USAGE")) + 
        geom_area(aes(y=BASE_USAGE, fill="BASE USAGE")) + 
        scale_fill_manual(values=c("#E69F00", "#999999")) +
        theme_minimal() +
        theme(legend.position = c(0.2, 1), axis.text.x = element_text(angle = 45, hjust = 1)) +
        labs(x = "Month", y = "Total Electricity Usage(wh)")
    })
    
    
    df_historical_client_probs <- select(df_historical_billing_client, "BILLING_MONTH", "actual", "predicted_probability")
    df_historical_client_probs["month_actual"] <- NA
    df_historical_client_probs["month_actual"][df_historical_client_probs["actual"] == 1] <- df_historical_client_probs["predicted_probability"][df_historical_client_probs["actual"] == 1]

    output$monthlyPredictionProbability <-renderPlot({
      
      if (sum(df_historical_client_probs[["actual"]]) == 0) {
        ggplot(df_historical_client_probs, aes(x=BILLING_MONTH, group=1)) + 
          geom_line(aes(y=predicted_probability, color="Missed Payment Prediction Probability")) + 
          theme_minimal() +
          theme(legend.position = c(0.2, 0.2), legend.title=element_blank(), axis.text.x = element_text(angle = 45, hjust = 1)) +
          scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, by = 0.1)) +
          expand_limits(x = 0, y = 0) +
          labs(x = "Month", y = "Missed Payment Probability") +
          scale_color_manual(values = c("red"),
                             guide = guide_legend(override.aes = list(
                               linetype = c("solid"),
                               shape = c(NA)))
          )          
      } else {
        ggplot(df_historical_client_probs, aes(x=BILLING_MONTH, group=1)) + 
          geom_line(aes(y=predicted_probability, color="Missed Payment Prediction Probability")) + 
          geom_point(aes(y=month_actual, color="Actually Missed Payment"), na.rm=TRUE, size=5) + 
          theme_minimal() +
          theme(legend.position = c(0.2, 0.2), legend.title=element_blank(), axis.text.x = element_text(angle = 45, hjust = 1)) +
          scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, by = 0.1)) +
          expand_limits(x = 0, y = 0) +
          labs(x = "Month", y = "Missed Payment Probability") +
          scale_color_manual(values = c("blue","red"),
                             guide = guide_legend(override.aes = list(
                               linetype = c("blank", "solid"),
                               shape = c(19, NA)))
          )        
      }
  
    })    
    
    output$risklevel <- renderText({
      paste("Customer Credit Rating :",credit_level)
      
    })
    
    # Reset scoring
    removeUI(selector = "#scoringResponse > *", multiple = TRUE)
    shinyjs::hide(id = "scoringResponse")
    shinyjs::show(id = "scoreBtnSection")
    output$scoringError <- renderText('')
    sessionVars$pipelineInput <- list(values = '06-2019', cust_id = selectedCustomerID)
    sessionVars$pipelineInput = list(
      fields=list("CUSTOMER ID","Billing Date(%mm-%YYYY)"),
      values = list(list(selectedCustomerID,'06-2019'))
    )
    
    output$pipelineInput <- renderText(toJSON(sessionVars$pipelineInput, indent = 2))
    
  })
  

  # Enable buttons when inputs are provided
  observe({
    toggleState("authBtn",  nchar(input$username) > 0 && nchar(input$password) > 0)
    toggleState("scoreBtn", nchar(input$endpoint) > 0 && nchar(input$token) > 0 && length(input$allCustomers_rows_selected) > 0)
  })
  
  # Handle CP4D API authentication button
  observeEvent(input$authBtn, {
    shinyjs::disable("authBtn")
    
    tryCatch({
      deploymentsResp = collectDeployments(input$username, input$password, "utilities_payment_risk_prediction_scoring_pipeline_function_deployment")
      serverVariables$deployments <- deploymentsResp$deployments
      serverVariables$token = deploymentsResp$token
    }, warning = function(w) {
      output$authError <- renderText(w$message)
    }, error = function(e) {
      output$authError <- renderText(e$message)
    })
    
    shinyjs::enable("authBtn")

    if(length(serverVariables$deployments) > 0) {
      updateSelectInput(session, "deploymentSelector", choices = names(serverVariables$deployments))
      shinyjs::hide(id = "authPanel")
      shinyjs::show(id = "deploymentPanel")
    }
  })
  
  # Handle model deployment dropdown switching
  observeEvent(input$deploymentSelector, {
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    output$deployment_guid <- renderText(selectedDeployment$guid)
    output$space_name <- renderText(selectedDeployment$space_name)
    output$scoring_url <- renderText(selectedDeployment$scoring_url)
    toggleState("scoreBtn", nchar(selectedDeployment$scoring_url) > 0 && nchar(serverVariables$token) > 0)
  })
  
  observeEvent(input$scoreBtn, {
    shinyjs::disable("scoreBtn")
    
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    sessionVars$selectedDeployment <- selectedDeployment
    
    payload <- sessionVars$pipelineInput
    

    
    response <- scoreModelDeployment(selectedDeployment$scoring_url, payload, serverVariables$token)
    
    if(length(response$error) > 0) {
      output$scoringError <- renderText(toString(response$error))
    } else if (length(response$predictions) > 0) {
      shinyjs::hide(id = "scoreBtnSection")
      shinyjs::show(id = "scoringResponse")
      
      predicted_prob <- response$predictions[[1]]$values$predictions[[1]]$values[[1]][[2]][[2]]
      
      insertUI(
        selector = "#scoringResponse",
        where = "beforeEnd",
        ui = panel(
          tags$head(
            tags$style(HTML("
                      .datatables {
                      width: 100% !important;
                      }
                      .html-widget.gauge svg {
                        height: 300px;
                        width: 600px;
                      }
                      "))
          ),
          h3("Client Bill Missed Payment Probability:"),
          p(
            gaugeOutput("gauge")
          )
        )
      )
      
      output$gauge = renderGauge({
        gauge(round(predicted_prob*100), 
              symbol = '%',
              min = 0, 
              max = 100, 
              sectors = gaugeSectors(success = c(0, 0.02),
                                     warning = c(0.02, 70),
                                     danger = c(70, 100)))
      })
    } else {
      output$scoringError <- renderText(response)
    }
    
  })
  

  
  
}



