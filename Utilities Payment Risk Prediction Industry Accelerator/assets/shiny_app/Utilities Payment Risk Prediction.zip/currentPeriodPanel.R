# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# Â© Copyright IBM Corp. 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

currentPeriodPanel <- function() {
  
  city_choice=unique(levels(df$CITY))
  segment_choice <- unique(levels(df$SEGMENT))
  building_type <- unique(levels(df$BUILDING_TYPE))
  max_bill_amt=round(max(df$TOTAL_TO_PAY),0)+1
  min_bill_amt=round(min(df$TOTAL_TO_PAY),0)-1
  
  tabPanel(
    "Billing Cycle View",
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 90% !important;
                      }
                      .shiny-split-layout > div {
                                overflow: visible;
                      }
                      .small-box {height: 75px}
                      .fa { font-size: 40px; }
                       #historical_view_border { border: 2px solid LightGray; }
                      "))
    ),
    shinyjs::useShinyjs(),
    useShinydashboard(),
    
    fluidRow(
      column(12, 
             panel(
               valueBoxOutput("billingCycle"),
               valueBoxOutput("numCustomers"),
               valueBoxOutput("totalAmountOwed"),
               valueBoxOutput("totalAmountOverdue")
             )
      )
    ),
    fluidRow(
      column(2,
             panel(selectInput("city", "Select Service Territory",
                               c("Any" = 99,
                                 city_choice), selected=99
             ),
             selectInput("segment", "Customer Segment",
                         c("Any" = 99,
                           segment_choice), selected=99
             ),
             selectInput("last_month_payment_status", "Missed Payment Last Cycle",
                         c("Either" = 99,
                           "No" = 0,
                           "Yes" = 1), selected=99
             ),
             sliderInput("monthly_bill_range", "Select Monthly Bill Amount Range:", min=0, 
                         max=ceiling(max_bill_amt/10)*10, value = c(0, ceiling(max_bill_amt/10)*10),
                         step = 50
             ),
             sliderInput("historical_num_missed_payments", "Select Historical Number of Missed Payments Range:", min=0, 
                         max=11, value = c(0, 11),
                         step = 1.0
             )
             
             
             
             
             )
      ),
      column(3,
             panel(
               h3("Predicted Payment Risk"),
               fluidRow(
                 valueBoxOutput("numHighRisk")
               ),
               fluidRow(
                valueBoxOutput("numMediumRisk")
               ),
               fluidRow(
                valueBoxOutput("numLowRisk")
               )
             )),
      column(7,
             panel(
               h3("Current Billing Cycle Customers"),
               h4("Click on a customer to drill down into more detail"),
               dataTableOutput("showCurrentPeriodCustomers")
             )
      )
    ),
    fluidRow(id="historical_view_border",
      column(4,
             panel(
               h2("Missed Payments by Billing Cycle"),
               plotOutput("montlyMissedPaymentCustomers")
             )   
      ),
      column(4,
             panel(
               h2("Overdue Amount by Billing Cycle"),
               plotOutput("montlyOverduePayments")
             )   
      ),
      column(4,
             panel(
               h2("Frequency of Missed Payment"),
               plotOutput("missedPaymentCustFreq")
             )   
      )
    )
  )
}


currentPeriodServer <- function(input, output, session, sessionVars) {
  
  observe({
    
    # we filter the current billing dataset based on the user's selection
    selected_last_month_payment_status <- as.numeric(input$last_month_payment_status)
    selected_historical_missed_payments_range <- input$historical_num_missed_payments
    
    # if the user has selected to show both customer's who have and haven't missed last months payment
    # they input is set to 99, we don't include the this in the filter
    if (selected_last_month_payment_status==99) {
      df_current_billing_filtered <- dplyr::filter(df_current_billing, (df_current_billing$total_num_missed_payments %in% (selected_historical_missed_payments_range[1] : selected_historical_missed_payments_range[2]))
                                                   )
    } else {
      df_current_billing_filtered <- dplyr::filter(df_current_billing, (df_current_billing$total_num_missed_payments %in% (selected_historical_missed_payments_range[1] : selected_historical_missed_payments_range[2]))
                                                   & (df_current_billing$missed_payment_last_month %in% selected_last_month_payment_status)
                                                  )
    }
    
    if (input$city!=99) {
      
      df_current_billing_filtered <- df_current_billing_filtered[df_current_billing_filtered$CITY==input$city,]
    } 
    
    if (input$segment!=99) {
      
      df_current_billing_filtered <- df_current_billing_filtered[df_current_billing_filtered$SEGMENT==input$segment,]
    }
    
    df_current_billing_filtered <- df_current_billing_filtered[(df_current_billing_filtered$TOTAL_TO_PAY>=input$monthly_bill_range[1])&(df_current_billing_filtered$TOTAL_TO_PAY<=input$monthly_bill_range[2]),]
    # we want to show only the same customers for the historical data
    df_historical_filtered <- dplyr::filter(df_historical, (df_historical$CUSTOMER_ID %in% unique(df_current_billing_filtered[["CUSTOMER_ID"]])))
    
    
    
    if (dim(df_current_billing_filtered)[1]>0) {
      
    num_customers <- length(unique(df_current_billing_filtered[['CUSTOMER_ID']]))
    total_amount_owed <- round(sum(df_current_billing_filtered[["TOTAL_TO_PAY"]]), 0)
    total_amount_overdue <- round(sum(df_current_billing_filtered[["OVERDUE_BALANCE"]]), 0)
    num_high_risk_cust <- length(unique(df_current_billing_filtered[df_current_billing_filtered["payment_risk"]=="High", "CUSTOMER_ID"]))
    num_medium_risk_cust <- length(unique(df_current_billing_filtered[df_current_billing_filtered["payment_risk"]=="Medium", "CUSTOMER_ID"]))
    num_low_risk_cust <- length(unique(df_current_billing_filtered[df_current_billing_filtered["payment_risk"]=="Low", "CUSTOMER_ID"]))
    
    # find number of customers, number of customers who missed a payment and amount overdue by month
    df_monthly_miss_payments_cust <- df_historical_filtered %>%
      group_by(BILLING_MONTH) %>%
      summarize(num_cust = n(), num_missed_payment_cust=sum(actual), amount_overdue=sum(OVERDUE_BALANCE)) %>%
      arrange(BILLING_MONTH) %>% 
      as.data.frame()
    
    # get the number of customers by number of missed payment months
    # first count the number of months missed payments per customer
    df_num_missed_payments_per_cust <- df_historical_filtered %>%
      group_by(CUSTOMER_ID) %>%
      summarize(num_missed_payment_cust=sum(actual)) %>%
      as.data.frame()
    # next group by the "num_missed_payment_cust" column to get the number of customers who missed payments by the number of payments missed
    df_missed_payment_freq <- df_num_missed_payments_per_cust %>%
      group_by(num_missed_payment_cust) %>%
      summarize(num_cust = n()) %>%
      arrange(num_missed_payment_cust) %>% 
      as.data.frame()
    
    output$montlyMissedPaymentCustomers <- renderPlot({
      ggplot(df_monthly_miss_payments_cust, aes(x=BILLING_MONTH, y=num_missed_payment_cust)) + 
        geom_bar(stat="identity", fill="firebrick2",width=0.6) + 
        theme_minimal() +
        theme(legend.position = c(0, 1), axis.text.x = element_text(angle = 45, hjust = 1)) +
        labs(x = "Month", y = "Number of Customers")
    })
    
    output$montlyOverduePayments <- renderPlot({
      ggplot(df_monthly_miss_payments_cust, aes(x=BILLING_MONTH, y=amount_overdue,group = 1)) + 
        geom_area(color="green", fill = "seagreen2") + 
        
        theme_minimal() +
        theme(legend.position = c(0, 1), axis.text.x = element_text(angle = 45, hjust = 1)) +
        labs(x = "Month", y = "Total Amount Overdue")
    })  
    
    output$missedPaymentCustFreq <- renderPlot({
      ggplot(tail(df_missed_payment_freq, -1), aes(x=num_missed_payment_cust, y=num_cust)) + 
        geom_bar(stat="identity", fill="blue",width=0.7) + 
        scale_x_continuous(breaks = seq(0, 11, by = 1)) + 
        theme_minimal() +
        theme(legend.position = c(0, 1)) +
        labs(x = "Number of Missed Payments", y = "Number of Customers")
    })
    
    output$numCustomers <- renderValueBox({
      shinydashboard::valueBox(
        tags$p("Number of Billed Customers", style = "font-size: 15px; text-align: center;"),
        tags$p(paste0(format(num_customers,big.mark = ',')), style = "font-size: 30px; text-align: center;"), 
        color = "aqua", width = 3, icon = icon("user")
      )
    })
    
    output$billingCycle <- renderValueBox({
      shinydashboard::valueBox(
        tags$p("Current Billing Cycle", style = "font-size: 15px; text-align: center;"),
        tags$p("June '19", style = "font-size: 30px; text-align: center;"), 
        color = "light-blue", width = 3, icon = icon("calendar-alt")
      )
    })
    
    output$totalAmountOwed <- renderValueBox({
      shinydashboard::valueBox(
        tags$p("Total Amount Owed in Billing Cycle", style = "font-size: 15px; text-align: center;"),
        tags$p(paste0("$", format(total_amount_owed,big.mark = ',')), style = "font-size: 30px; text-align: center;"), 
        color = "olive", width = 3, icon = icon("dollar-sign")
      )
    })
    
    output$numHighRisk <- renderValueBox({
      shinydashboard::valueBox(
        tags$p("High Risk Customers", style = "font-size: 15px; text-align: center;"),
        tags$p(paste0(format(num_high_risk_cust,big.mark = ',')), style = "font-size: 30px; text-align: center;"), 
        color = "red", width = 9, icon = icon("times-circle")
      )
    })
    
    output$numMediumRisk <- renderValueBox({
      shinydashboard::valueBox(
        tags$p("Medium Risk Customers", style = "font-size: 15px; text-align: center;"),
        tags$p(paste0(format(num_medium_risk_cust,big.mark = ',')), style = "font-size: 30px; text-align: center;"), 
        color = "yellow", width = 9, icon = icon("exclamation")
      )
    })
    
    output$numLowRisk <- renderValueBox({
      shinydashboard::valueBox(
        tags$p("Low Risk Customers", style = "font-size: 15px; text-align: center;"),
        tags$p(paste0(format(num_low_risk_cust,big.mark = ',')), style = "font-size: 30px; text-align: center;"), 
        color = "green", width = 9, icon = icon("check")
      )
    })
    
    output$totalAmountOverdue <- renderValueBox({
      shinydashboard::valueBox(
        tags$p("Overdue Amount Owed in Billing Cycle", style = "font-size: 15px; text-align: center;"),
        tags$p(paste0("$", format(total_amount_overdue,big.mark = ',')), style = "font-size: 30px; text-align: center;"), 
        color = "red", width = 3, icon = icon("dollar-sign")
      )
    })
    
    
    
    output$showCurrentPeriodCustomers <- DT::renderDataTable({
      df_current_billing_filtered$NAME <- paste(df_current_billing_filtered$FIRST_NAME,df_current_billing_filtered$LAST_NAME)
      filtered_df <- select(df_current_billing_filtered, "CUSTOMER_ID", "NAME", "PHONE_1", "EMAIL", "TOTAL_TO_PAY", "predicted_probability")
      
      filtered_df <- filtered_df %>% mutate_if(is.numeric, round, 2)
      
      filtered_df <- filtered_df[order(-filtered_df$predicted_probability),]
      
    }, rownames = FALSE, selection = 'single', options = list(pageLength = 5),server = FALSE, callback = JS("table.on('click.dt', 'tr', 
    function() {
           Shiny.onInputChange('customer_row',table.rows(this).data().toArray() );
    });"))
    
    
    
    }
    
    else{
      output$numCustomers  <- NULL
      output$showCurrentPeriodCustomers <- NULL
      output$pieRisk <- NULL
      output$montlyOverduePayments <- NULL
      output$missedPaymentCustFreq <- NULL
      output$montlyMissedPaymentCustomers <- NULL
    }
    
  })
  
  observeEvent(input$customer_row, {
    selected_customerID <- as.numeric(input$customer_row[1])
    sessionVars$selectedClientId <- selected_customerID
    updateTabsetPanel(session, "proNav",
                      selected = "clientPanel")
    
  }
  )
  
  
  
}