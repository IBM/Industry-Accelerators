# knowledge-accelerator-scripts - IKC Cloning

Please find the Guidelines document in the `ikc-cloning` folder.

## Introduction
Cloning refers to the ability identify the subsets of business terms and categories in the Source Glossary that are actually needed by the business and the copying of these terms to the Cloned Glossary for use by the business users. Cloning includes both the business term itself, the associated term properties of the terms and of any relationships to other cloned terms. Cloning can be done on an iterative basis, so that the required business terms can be added to the cloned glossary over time whenever required.<br>

#### Cloning can be triggered either by : <br>
a) Business Terms being referenced by a specific category or categories to be cloned. <br>
b) Business Terms that are assigned to a set of data assets to specific catalogs which now need to be covered by the cloned glossary. <br>
c) Both Options a & b.<br>

The script enables a user to clone a subset of the terms in a parent category hierarchy based on the above 2 inputs. 
- It is envisaged that business users might only get visibility access to the curated set of terms in the clone, and the source vocabulary would be available to an admin/steward type role, whom is responsible for transitioning terms into the cloned/curated category.
- Once the input set of terms and categories has been arrived at, either via Option 'a', 'b' or 'c', this utility will create a clone of the terms and categories as per the source glossary, including any inter-relationships between the cloned terms. 
- Note that no terms will be added to the cloned glossary, that were not directly cloned via Option a/b/c above. 
- Optionally the terms can have assigned assets from the catalog mapped as well.
- It is possible to re-run the cloning, to do an overlay on the terms & categories whilst maintaining their artifact id's. Howver, any user updates to the cloned terms via UI may be overwritten, therefore as part of the process, the admin/steward user should consider updating the source term rather than cloned term. 

## Pre-Requisites
- Ensure that you have a CPD Environment with IKC installed. 
- Ensure that the user performing the cloning has admin/data steward permissions. This is to create categories/publish terms etc.
- If you wish to clone the glossary to a Root Category that you wish to create, then login to CPD with your admin credentials, Navigate to **Governance >> Categories >> Add Category >> New Category** and Provide a name for the Category & click **Create**.
- After creating the category in IKC, note down the Category ID from the URL. See highlighted section image below:

![Category ID](images_readme/1.png)
- This will be used as an input parameter for the script in the `.env` file. (Discussed later below)
- If not already installed then, download and install Python from https://www.python.org/downloads/. This is a primary requirement for the script.

##### NOTE : Please update the environment variables provided as as part of the script package with any editor of your choice and save. Instructions for each variable is provided within the file. <hr>

There are 3 modes of executing the cloning as mentioned in the environment variables file. 
- If you wish to only clone from categories/secondary categories Enter cloning_choice = "1"
- If you wish to clone from terms picked up from asset-to-term relationships in a catalog Enter cloning_choice = "2"
- If you wish to clone from both categories as well as catalog assets (ie perform 1 & 2), then Enter cloning_choice = "3" 

## Installation & Execution - Command Line or CP4D Terminal.

##### NOTE : CP4D Terminal requires either Watson Studio or Jupyter Notebooks service provisioned. 
An easy way to navigate to CP4D Terminal for executing is - **Open any jupyter notebook on the CP4D platform in edit mode >> Goto information tab >> Goto Environment section >> Click `Open Terminal`.**

![Terminal](images_readme/6.png)

1. Verify that python exists. Can be done by running `python --version` on the command line/command prompt Terminal. 
2. Run  `cd /project_data/data_asset/` and goto the data_asset folder.  Ensure that the `ikc-cloning.zip` file is downloaded to this path. 
3. Extract the `ikc-cloning.zip` file by running `unzip ikc-cloning.zip`
4. Navigate to `ikc-cloning/` folder in the command line terminal based on where your git repo was cloned.
5. Then Run this command on the terminal  : `export PYTHONPATH="$PYTHONPATH:$PWD"`. This is to set the python path for the execution.
6. Next Run `pip install -r requirements.txt`
7. After completion edit the `.env` file. Please copy/update the environment variables as per your cloning requirements. Reference to sample Environment Variables is shipped in the ikc-cloning folder.
8. Execute the script now by running `python src/cloning.py`.
9. In case of Re-runs after modification of the source glossary, please run Step 6 again from the same folder. 

## Installation & Execution - Visual Studio Code

##### For executing via Visual Studio Code follow the steps below

### Setting up Python & Visual Studio Code

1. Verify that python exists. Can be done by running `python --version` on the command line/command prompt Terminal. 
2. Download and install Visual Studio Code from https://code.visualstudio.com/download.
3. Start Visual Studio Code. 
4. To select Working Folder in VSCode. Goto **File >> Open Folder >> Navigate from the extracted `ikc-cloning.zip` file into `ikc-cloning/` >> Click Select Folder** (This makes `ikc-cloning` as the working folder). 
5. Go to View --> Extensions, search for Python and install the Python extension for Visual Studio Code
6. Go to Run & Debug mode (`Press Ctrl+Shift+D`) --> and click on `create a launch.json file`, choose Python and Python file.
![launch.json](images_readme/2.png)
7. Replace the content of the newly created `launch.json` file with the the below snippet and **Save**. 
```
// Cloning launch.json
{    
    "version": "0.2.0",
    "configurations": [
        {
            "name": "cloning",
            "type": "python",
            "request": "launch",
            "module" : "src.cloning",
            "console": "integratedTerminal",
            "envFile": "${workspaceFolder}/.env",
            "justMyCode": true
        }
    ]
}
``` 
8. Select Python Interpreter. **Type `Ctrl+Shift+P` >> Select Python Interpreter >> Choose Python version that you installed**. (It will show up on its own, see image below).<br>
![Interpreter](images_readme/3.png)<br>Ensure python version is `3.10` or above. 

### Setting up the script for execution
1. In Visual Code Navigate to Explorer mode `Ctrl+Shift+E`.
2. In the `ikc-cloning` folder, create an environment file `.env`. See under [Environment Variables section](https://ibm.box.com/s/s11n21pb23rbwx5n64slj76t1sh2kslz) for an example of content and **Save**.
3. Install the `requirements.txt` to install the dependent libraries required. Run the Requirements file to install necessary packages in the **VSCode terminal**. Command to run this : `pip install -r requirements.txt`. (see image below) <br>
![requirements](images_readme/4.png)<br>
4. If the above step fails with the error "The term `pip` is not recognized as the name of a cmdlet". 
    - In Windows, **Press Windows button >> Manage app execution aliases >> Turn off App Installer(python3.exe)**.
    - Go back to VSCode, In the python Debugger Terminal run `py -m pip install pip`
    - After this run `py -m pip install -r requirements.txt`

### Running the scripts - (Repeat these steps to re-execute with more terms or categories with updated .env file.)
1. Once the requirements are successfully installed, to execute the script, In Visual Code, **Go to Run & Debug mode `Ctrl+Shift+D` >> Click the Play button and run `cloning.py`.**
See Image below : <br>

![cloning](images_readme/5.png)

#### NOTE : Ensure that the terms appear in the UI before executing Re-Runs. The terms might sometimes take some time to appear on the platform.  

### Terms and Conditions
This project contains Sample Materials, provided under license.<br>
Licensed Materials - Property of IBM.<br>
© Copyright IBM Corp. 2023. All Rights Reserved.<br>
US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.<br>
