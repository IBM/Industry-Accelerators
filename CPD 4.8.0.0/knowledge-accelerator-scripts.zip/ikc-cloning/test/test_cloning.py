# This project contains Sample Materials, provided under license.
# Licensed Materials - Property of IBM.
# © Copyright IBM Corp. 2023. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

import os, sys
import pip
import glob

try:
    import requests
except ImportError:
    print("\n'requests' is required for this import to work. This module is not available. Will try to install it now.")
    pip.main(["install", "requests"])
    print("\nIf requests was installed successfully you can re-execute the script.")
    raise SystemExit("If requests was installed successfully you can continue with execution, rerun this cell to retest.")

import logging
import src.terms
import src.categories
import src.module_functions
import time
import pandas as pd
import numpy as np
import uuid, json


def getInputs():
    try:
        hostname = os.getenv("hostname")      
        username = os.getenv("username")
        password = os.getenv("password")
        cloned_root_category_id = os.getenv("cloned_root_category_id")
        choice = os.getenv("cloning_choice")
        inputs = dict()

        if 'hostname' not in locals() or hostname == None or len(hostname) ==0: 
            logger.critical("Hostname is a mandatory input parameter and is not provided. Please provide this in the environment variables file.")
            exit()
        else:
            inputs['hostname'] = os.getenv("hostname")      

        if 'username' not in locals() or username == None or len(username) ==0: 
            logger.critical("Username is a mandatory input parameter and is not provided. Please provide this in the environment variables file.")
            exit()
        else:
            inputs['username'] = os.getenv("username")

        if 'password' not in locals() or password == None or len(password) ==0:  
            logger.critical("Password is a mandatory input parameter and is not provided. Please provide this in the environment variables file.")
            exit()
        else:
            inputs['password'] = os.getenv("password")

        if 'cloned_root_category_id' not in locals() or cloned_root_category_id == None or  len(cloned_root_category_id) ==0:  
            logger.critical("Source Root Category ID is a mandatory input parameter and is not provided. Please provide this in the environment variables file.")
            exit()
        else:
            inputs['cloned_root_category_id'] = os.getenv("cloned_root_category_id")

        if 'choice' not in locals() or choice == None or  len(choice) == 0:  
            logger.critical("Cloning choice is a mandatory input parameter and is not provided. Please provide this in the environment variables file.")
            exit()
        else:
            inputs['choice'] = os.getenv("cloning_choice")
    except:
        logger.critical("Missing inputs!\n")
        exit()
    return inputs


def verifyInputs(inputs):
    # Authentication to CPD
    try:
        accessToken = src.module_functions.authenticate(inputs['hostname'], inputs['username'], inputs['password'])
        logger.info("CPD Authentication Successful.\n")
    except:
        logger.critical("Unable to authenticate!\n")
        exit()
    return accessToken


def check_root_category():
    # Check if Root Category exists
    logger.info("Checking if provided root category in environment variables exists.\n")

    catURL = inputs['hostname']+"/v3/categories/"
    RootCatName, RootCatDescription = src.module_functions.checkCategory(accessToken, catURL, inputs['cloned_root_category_id'])

    return RootCatName, RootCatDescription


def initialise_choice(choice):

    print("\n*********************   KA Glossary Cloning Utility Options  *********************",
        "\n1. Clone Glossary based on Input Catalog Assets.", 
        "\n2. Clone Glossary based on Input Categories.",
        "\n3. Clone Glossary based on Input Catalog Assets Input Categories. (1 & 2)\n")

    result = dict()

    match choice:
        case "1":              
            try:  
                result['catalogsList'] = json.loads(os.getenv("catalogName"))        
            except : 
                logger.info("No Catalog Assets found")
                exit()
                
            logger.info("Cloning based on Input Catalog assets assigned via MDE.\n")    

        case "2":
            try :
                result['secondaryCategoryList'] = json.loads(os.getenv("input_categorylist"))
                result['scope_terms']=pd.DataFrame(columns=['ColumnName','Business Term','Term ID', 'Route'])
                logger.info("Cloning based on Input Categories.\n")
            except : 
                    logger.info("No Input Categories found")
                    exit()

        case "3":
            try: 
                result['catalogsList'] = json.loads(os.getenv("catalogName"))            
                result['df_scope_terms']=pd.DataFrame(columns=['ColumnName','Business Term','Term ID', 'Route'])
                result['secondaryCategoryList'] = json.loads(os.getenv("input_categorylist"))
                if not result['catalogsList'] or not result['secondaryCategoryList']:
                    logger.critical("Input Parameters Catalog/Categories missing")
                    exit()
            except : 
                logger.info("Existing Input Categories and Input Catalogs need to be provided for this scenario.")
                exit()

            logger.info("Cloning based on both Option 1 & 2.\n")

        case _:
            logger.critical("No possible option entered.\n")
            exit()
    return result


def getOption1and3Details(logger, catalogsList, inputs, accessToken):
        
    # Get details based on Option 1 & 3
    try: 
        if catalogsList == []:
            #trigger_exception
            catalogsList[0]
            
        df_total_assigned_terms = pd.DataFrame(columns=['ColumnName','Business Term','Term ID', 'Route'])
        # Get Catalog ID details
        getCatalogURL = inputs['hostname']+'/v2/catalogs'
        for i in catalogsList:
            catalog_id = src.module_functions.getCatalogs(getCatalogURL,accessToken, i)

            if catalog_id == None:
                logger.critical('Please provide a valid Catalog with assets & run again..\n')
                exit()
            else:
                logger.info('"%s" with Catalog ID : %s, will be used for publishing assets.\n', i, catalog_id)   

                # Fetch Catalog data assets
                getCatalogAssetsURL = inputs['hostname']+"/v2/asset_types/asset/search?catalog_id="+catalog_id
                data_asset_dict = src.module_functions.getCatalogAssets(getCatalogAssetsURL,accessToken)

                # Fetch all term assignments of the assets
                retrieveAssetURL= inputs['hostname']+"/v2/assets/"
                df_assigned_terms = src.module_functions.getTermAssignments(retrieveAssetURL, data_asset_dict, accessToken, catalog_id)

                df_total_assigned_terms = pd.concat([df_total_assigned_terms,df_assigned_terms]) 
                logger.info('%s terms identified based on available mappings to columns.\n', df_total_assigned_terms.shape[0])
                            
                map_terms = df_total_assigned_terms[["ColumnName", "Business Term", "Route"]].copy() 
                
    except:
        logger.info("Skipping Catalog route..\n")
        if inputs['choice'] == "3" or inputs['choice'] == "1": 
            logger.info("Input Catalog cloning route selected but no assets/assigned terms found.")
            exit()

        catalogsList = []


    try:
        if df_total_assigned_terms.shape[0] == 0 and inputs['choice'] == "1":
            logger.info("No terms available for cloning either via Catalog route.")
            exit()    
    except : pass

    try:
        secondaryCategoryList
        logger.info("Cloning via Input Category route..\n")
    except:
        secondaryCategoryList = []
        logger.info("Skipping Input Category route..\n")

    return df_assigned_terms, df_total_assigned_terms, data_asset_dict, map_terms


def determine_existing_categories(logger, inputs, manifest):
    if scenario == 0 : # 1st Run of Cloning
        logger.info("First time cloning from source to clone category, New Manifest created as no previous Manifest was found.. \n")
        #print("\n",manifest)
        df_existing_categories = pd.DataFrame()
        df_export_terms = pd.DataFrame()
        df_existing_terms = pd.DataFrame()
        
    elif scenario == 1 : # Re-Run of Cloning
        #print(manifest,"\n")
        logger.info("Overlay onto an existing clone, please cross check inputs for last run against this run along with current latest inputs.")
        manifest = json.loads(manifest)
        print("\nRoot Category Name :")
        print(manifest['source_root_category']['name'])
        if manifest['source_root_category']['id'] != inputs['cloned_root_category_id'] : 
            logger.critical("Attempt to overlay from a source category : %s onto a clone created from a different source category : %s. This is not supported.", manifest['source_root_category']['id'], inputs['cloned_root_category_id'])
            exit()

        print("\nExisting & New Input Categories :") 
        if manifest['source_input_categories']['id'] != "":
            for x in manifest['source_input_categories']['name']: print(x)
        else : print("No input catagories provided")

        print("\nExisting & New Input Catalogs :")
        if manifest['source_input_catalogs']['cat_name'] != "":
            for x in manifest['source_input_catalogs']['cat_name']: print(x)
        else : print("No input catalogs provided")


        # zip export of the glossary
        logger.info("Starting Zip export of terms under the new root category: %s",manifest['source_root_category']['id'])
        df_export_categories, df_export_terms = src.module_functions.zipExport(accessToken, manifest)
        print("Number of Categories Exported : ", df_export_categories.shape[0])
        print("Number of Terms Exported      : ", df_export_terms.shape[0])
        

        # Map of Existing Categories
        df_existing_categories = pd.DataFrame()
        df_existing_categories['Artifact ID'] = list(df_export_categories['Artifact ID'])
        df_existing_categories['Name'] = list(df_export_categories['Name'])
        df_existing_categories['Category'] = list(df_export_categories['Category'])
        df_existing_categories['Description'] = list(df_export_categories['Description'])

        # Map of Existing Terms
        df_existing_terms = pd.DataFrame()
        df_existing_terms['Name'] = list(df_export_terms.loc[df_export_terms['Name'].notnull(), 'Name'])
        df_existing_terms['Artifact ID'] = list(df_export_terms.loc[df_export_terms['Artifact ID'].notnull(), 'Artifact ID'])
        df_existing_terms['Category'] = list(df_export_terms.loc[df_export_terms['Category'].notnull(), 'Category'])
        df_existing_terms['Description'] = list(df_export_terms.loc[df_export_terms['Description'].notnull(), 'Description'])
        df_existing_terms.head()
    return df_export_terms, df_existing_categories , df_existing_terms


def addSecondaryCatTerms(logger, secondaryCategoryList, df_scope_terms):
    # Fetching Secondary Categories via search query  , secondaryCategoryList passed as env variable at the moment
    if 'df_scope_terms' in locals(): # should this be globals()
        logger.info("Fetching terms based on Input Categories.\n")
        fetchSecCatsURL =  inputs['hostname']+"/v3/search"
        df_scope_terms = src.module_functions.getSecCatTerms(df_scope_terms, fetchSecCatsURL, accessToken, secondaryCategoryList)   
        #print(df_scope_terms)
        logger.info('%s Terms identified based on input categories provided.\n', df_scope_terms.shape[0])
    else:
        logger.info("Only selecting terms based on input catalogs.\n")
    return df_scope_terms


def setTotalTerms(logger, scope_terms = pd.DataFrame(), total_assigned_terms = pd.DataFrame(), assigned_terms = pd.DataFrame()):
    # Initial Summary 
    if len(scope_terms) > 0 and len(total_assigned_terms) > 0 and len(assigned_terms) > 0:
        df_total_terms = pd.concat([scope_terms, assigned_terms])
        logger.info('Total terms to be cloned via both Input Catalog and Input Categories : %s\n',df_total_terms.shape[0])
    elif len(scope_terms) > 0 and len(total_assigned_terms) == 0:
        df_total_terms = scope_terms
        logger.info("Only selecting terms based on Input Categories and not Input Catalog assets. No Catalog assets were found.\n")
    elif len(scope_terms) == 0 and len(total_assigned_terms) > 0 and len(assigned_terms) >0:
        df_total_terms = total_assigned_terms
        logger.info("Only selecting terms based on Catalog assets and not Input Categories.\n")
    else:
        logger.critical("No terms to be cloned..\n")
        exit()
    # Is this a Fresh-Run or a Re-Run? Need to check this
    return df_total_terms


def getTotalAssignedTerms(logger, inputs, df_total_terms, accessToken):   
    # Fetch all term assignments of the assets
    getDataAssetsURL =  inputs['hostname']+"/v3/search"
    df_assigned_terms = src.module_functions.getNoCatalogTermAssignedAssets(getDataAssetsURL, df_total_terms, accessToken)

    df_total_assigned_terms = df_assigned_terms.drop_duplicates()
    logger.info('%s terms identified based on available mappings to columns.\n', df_assigned_terms.shape[0])
    #print(df_assigned_terms)
    #df_total_assigned_terms = pd.concat([df_total_assigned_terms,df_assigned_terms]) 
    map_terms = df_total_assigned_terms[["ColumnName", "Business Term", "Route", "Catalog ID"]].copy() 

    return map_terms


def saveCategoriesToCSV(logger, CategoryCSV):
    df_categories = pd.DataFrame(CategoryCSV)
    df_categories.reindex(columns=["artifact_id", 
                                "Name", 
                                "Artifact Type", 
                                "Category", 
                                "Description", 
                                "Tags",
                                "Stewards"]).to_csv('supplemental-glossary-categories.csv', index=False ,encoding='utf-8-sig')

    logger.info("Categories csv file <supplemental-glossary-categories.csv> is generated..\n")
    return df_categories


def saveTermsToCSV(logger, df_total_terms,accessToken, CategoryCSV, RootCatName, df_categories, df_existing_terms, df_export_terms):
    # TERMS
    if scenario == 1:
        # Overlay Terms
        TermsCSV, NewTermsArtifactIDs = src.terms.GenerateOverlayTermsFile(df_total_terms,accessToken, CategoryCSV, RootCatName, df_categories, df_existing_terms, df_export_terms) 

    elif scenario == 0:       
        TermsCSV, NewTermsArtifactIDs = src.terms.GenerateTermsFile(df_total_terms,accessToken, CategoryCSV, RootCatName, df_categories)

    # TermsCSV is converted to DataFrame
    df_terms = pd.DataFrame(TermsCSV)
    if len(TermsCSV) == 0:
        logger.critical("No New Terms to be cloned based on current input parameters. Cloning will end here.")
        exit()

    getCatName = inputs['hostname']+'/v3/categories/'
    df_final_terms = src.categories.StitchSecondaryCategories(getCatName, accessToken, df_terms, df_total_terms, CategoryCSV)

    if scenario == 1 and not df_existing_terms.empty:
        # Adding newly generated terms to concatenate with overlay terms that already existed.
        df_export_terms.rename(columns = {'Artifact ID' : 'artifact_id'}, inplace = True)
        df_total_overlay_terms = pd.concat([df_final_terms, df_export_terms])
        df_total_overlay_terms = df_total_overlay_terms.reset_index(drop=True)
        df_total_overlay_terms.reindex(columns=["artifact_id", "Name", 'Artifact Type', "Category", "Description", "Tags", 
                        "Classifications", "Stewards", "Related Terms", 
                        "Part Of Terms","Type Of Terms","Abbreviations", "Data Classes","Synonyms",
                        "Secondary Categories"]).to_csv('supplemental-glossary-terms.csv', index=False ,encoding='utf-8-sig')
    else:     
        df_final_terms.reindex(columns=["artifact_id", "Name", 'Artifact Type', "Category", "Description", "Tags", 
                        "Classifications", "Stewards", "Related Terms", 
                        "Part Of Terms","Type Of Terms","Abbreviations", "Data Classes","Synonyms",
                        "Secondary Categories"]).to_csv('supplemental-glossary-terms.csv', index=False ,encoding='utf-8-sig')

    logger.info("Terms file <supplemental-glossary-terms.csv> is generated.\n")


if __name__ == "__main__":

    logger = src.module_functions.setup_logger('ka-logger-cloning', 'cloning.log')

    inputs = getInputs()

    accessToken = verifyInputs(inputs)

    RootCatName, RootCatDescription = check_root_category()

    result = initialise_choice(inputs["choice"])

    catalogsList = result['catalogsList'] if 'catalogsList' in result else []
    secondaryCategoryList = result['secondaryCategoryList'] if 'secondaryCategoryList' in result else []
    df_scope_terms = result['scope_terms'] if "scope_terms" in result else pd.DataFrame()
    df_mapped_terms = {}

    if len(catalogsList) > 0:
        df_assigned_terms, df_total_assigned_terms, data_asset_dict, map_terms = getOption1and3Details(logger, catalogsList, inputs, accessToken)
    else:
        df_assigned_terms = pd.DataFrame()
        df_total_assigned_terms = pd.DataFrame()

    # Checks if the catalogs and input categories given in env variables exists 
    # If so then checks if its available in the manifest, or creates a new one.
    manifest,scenario = src.module_functions.checkManifestInfo(RootCatName, secondaryCategoryList, catalogsList, inputs['username'], RootCatDescription, inputs['cloned_root_category_id'], accessToken)

    df_export_terms, df_existing_categories , df_existing_terms = determine_existing_categories(logger, inputs, manifest)

    df_scope_terms = addSecondaryCatTerms(logger, secondaryCategoryList, df_scope_terms)


    df_total_terms = setTotalTerms(logger, df_scope_terms, df_total_assigned_terms, df_assigned_terms)

    # For scope scenario, we now have scope terms, so can retrieve any Data Assets mappings
    if inputs['choice'] == "2":
        mapTerms = getTotalAssignedTerms(logger, inputs, df_total_terms, accessToken)


    # CATEGORIES
    CategoryCSV = [] 
    CategoryCSV, New_Category_Artifact_IDs = src.categories.GenerateCategoryFile(df_total_terms, inputs['cloned_root_category_id'], RootCatName, accessToken, secondaryCategoryList, manifest, df_existing_categories)

    df_categories = saveCategoriesToCSV(logger, CategoryCSV)

    ## Import Categories file into CPD cluster
    categories_csv = "supplemental-glossary-categories.csv"

    cat_status=src.categories.ImportCategories(categories_csv, accessToken, inputs['hostname'])
    time.sleep(10)

    terms_csv = "supplemental-glossary-terms.csv"

    wf_json_workflowDetails = src.terms.ImportTerms(terms_csv, accessToken, inputs['hostname'])
    logger.info("Terms have been imported into Draft state with workflow id : %s\n", wf_json_workflowDetails)

    # Publish Terms
    src.terms.publishTerms(accessToken, wf_json_workflowDetails)

    # Map Terms to Catalog Assets
    try:
        if len(catalogsList) == 0:
            # trigger exception
            catalogsList[0]
        else:
            for catalog_id in catalogsList: #list or dataframe? list()
                df_new_terms = src.terms.prepareNewTerms(accessToken, map_terms, New_Category_Artifact_IDs)
                final_result = src.terms.mapCatalogTermAssets(map_terms, df_new_terms, data_asset_dict, accessToken, catalog_id)
    except:
        catalog_id_list = list(set(list(map_terms.loc[map_terms['Catalog ID'].notnull(), 'Catalog ID'])))
        logger.info("Mapping to Data Assets using all Catalogs that comtain assets to which Scope terms are assigned.\n")
        # Need to use all catalogs that have assets mapped to scope terms
        for catalog_id in catalog_id_list:
            # Fetch Catalog data assets
            getCatalogAssetsURL = inputs['hostname']+"/v2/asset_types/asset/search?catalog_id="+catalog_id
            data_asset_dict = src.module_functions.getCatalogAssets(getCatalogAssetsURL,accessToken)

            # Fetch all term assignments of the assets
            retrieveAssetURL= inputs['hostname']+"/v2/assets/"
            df_assigned_terms = src.module_functions.getTermAssignments(retrieveAssetURL, data_asset_dict, accessToken, catalog_id)
            
            # reduce mappings set to those only in clone scope, and replace Term IDs with cloned ones
            df_assigned_terms_in_scope = df_assigned_terms.loc[df_assigned_terms["Business Term"].isin(list(df_total_terms["Business Term"]))]

            df_new_terms = src.terms.prepareNewTerms(accessToken, map_terms, New_Category_Artifact_IDs)
            final_result = src.terms.mapCatalogTermAssets(map_terms, df_new_terms, data_asset_dict, accessToken, catalog_id)
