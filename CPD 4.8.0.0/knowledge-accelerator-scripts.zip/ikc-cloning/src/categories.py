# This project contains Sample Materials, provided under license.
# Licensed Materials - Property of IBM.
# © Copyright IBM Corp. 2023. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from datetime import datetime
import json
import os, sys
import pip
import logging
import src.module_functions
import time
import pandas as pd
import numpy as np
import uuid

hostname = os.getenv("hostname")      
username = os.getenv("username")
password = os.getenv("password")

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
s = requests.Session()

logger = src.module_functions.setup_logger('ka-logger-categories', 'cloning.log')

def getParentCategoryList(accessToken, prim_cat_and_input_cat_list):

    df_parent_cats = pd.DataFrame(columns=['Artifact ID','Category Name'])
    parent_category_list=[]
    headers = {
        'Content-Type': "application/json",
        'Authorization': "Bearer "+accessToken
        }
    for i in prim_cat_and_input_cat_list:
        url = hostname + "/v3/categories/hierarchy?category_id="+i
        res=s.get(url,headers=headers,verify=False)
        if res.status_code == 200:
            for j in json.loads(res.text)['category_hierarchy_paths']:
                for k in j['category_hierarchy_path']:            
                    cID = k['artifact_id']
                    cName = k['name']   
                    #print(cID, cName)
                    new_row = {
                        'Artifact ID' :  cID,                    
                        'Category Name' : cName,                    
                        }
                        
                    if cID not in parent_category_list:
                        df_parent_cats.loc[len(df_parent_cats)] = new_row
                        parent_category_list.append(cID)
                    #else:
                    #    print(cName, 'skipped as Category already exists')
        else:
            logger.error('The below error has occurred.\n %s', res.text)
    
    return parent_category_list

def generateCategoryDictionary(accessToken, final_categories_list):

    # Generate Categories
    categoryDict = []
    headers = {
        'Content-Type': "application/json",
        'Authorization': "Bearer "+accessToken
        }
    for i in final_categories_list:
        
        url = hostname+"/v3/governance_artifact_types/category/"+i
        res=s.get(url,headers=headers,verify=False)
        
        if res.status_code == 200:
            try : 
                json.loads(res.text)['entity']['parent_category_id']
                print("Category cloned : ", json.loads(res.text)['metadata']['name'])
                addtoList = {
                    "artifact_id" : json.loads(res.text)['metadata']['artifact_id'],
                    "Name" : json.loads(res.text)['metadata']['name'],
                    "Artifact Type": json.loads(res.text)['metadata']['artifact_type'],
                    "Category": json.loads(res.text)['entity']['parent_category_id'],
                    "Description": json.loads(res.text)['entity']['long_description']+"\n CLONED FROM : "+hostname+"/gov/categories/"+i  ,
                    "Tags": "",
                    "Stewards": ""
                    }
                #print(addtoList['Description'])
                categoryDict.append(addtoList)
            except:          
                pass
        else:
            logger.error('The below error has occurred.\n %s', res.text)
        
    return categoryDict

def handleCategoryArtifact_IDs(df_categories, scenario,cloned_root_category_id, cloned_root_cat_name, cloned_root_cat_desc, source_root_category_id, df_overlay_export_categories):
    
    # Handle Categories
    print("\n")
    logger.info("Generating Categories for the Glossary.")
    if scenario == 0: # 1st Pass of Cloning 
        df_old_new_ids = pd.DataFrame(columns=["Old Artifact IDs", "New Artifact IDs"])
        logger.debug("Generating new artifact ids for all categories as this is the 1st Pass of Cloning")
        
        # Create new artifact IDs for all terms
        for i in df_categories['artifact_id'].values:
            new_row = {
                    'Old Artifact IDs' : i,                    
                    'New Artifact IDs' : str(uuid.uuid4())
                    }
            df_old_new_ids.loc[len(df_old_new_ids)] = new_row

            # Find and Replace all Old Artifact IDs & Category IDs with New
            df_ids_dict = df_old_new_ids.set_index("Old Artifact IDs")["New Artifact IDs"].to_dict()
            df_categories['artifact_id'] = df_categories['artifact_id'].replace(df_ids_dict)
            df_categories['Category'] = df_categories['Category'].replace(df_ids_dict)

        # Adding root category to the cats df
        root_cat_row = {
                "artifact_id" : cloned_root_category_id,
                "Name" : cloned_root_cat_name,
                "Artifact Type" : "category",
                "Category" : "",
                "Description" : cloned_root_cat_desc+" \n\n\n  Overlay Manifest : \n\n\n", 
                "Tags" : "",
                "Stewards" : ""
                }
        df_categories.loc[len(df_categories)] = root_cat_row
        # Replacing all old Root Cat IDs to New Cloned Root Cat ID in cat column. 
        df_categories['Category']= df_categories['Category'].replace(source_root_category_id, cloned_root_category_id)
    
    elif scenario == 1: # Overlay Scenario
        # Adding Root Category to the cat dataframe
        root_cat_row = {
                    "artifact_id" : cloned_root_category_id,
                    "Name" : cloned_root_cat_name,
                    "Artifact Type" : "category",
                    "Category" : "",
                    "Description" : cloned_root_cat_desc+" \n\n\n  Overlay Manifest : \n\n\n", 
                    "Tags" : "",
                    "Stewards" : ""
                    }
        #print(df_categories, "\n",len(df_categories),"\n", root_cat_row,"\n")

        if len(df_categories) == 0:
            #print(df_categories, "\n",len(df_categories),"\n", root_cat_row,"\n")
            logger.critical("No Categories/Terms found. Stopping Execution")
            exit()
            
        df_categories.loc[len(df_categories)] = root_cat_row
        # Replacing all old Root Cat IDs to New Cloned Root Cat ID. 
        df_categories['Category']= df_categories['Category'].replace(source_root_category_id, cloned_root_category_id)
        # Creating a df of old and new cats
        df_old_art_ids = df_categories[["Name", "artifact_id"]]
        df_overlay_art_ids = df_overlay_export_categories[["Name", "Artifact ID"]]
        df_new_categories=pd.merge(df_old_art_ids,df_overlay_art_ids,how='left',on='Name')[['Artifact ID']]
        df_new_categories['Old Artifact IDs'] = df_categories[["artifact_id"]]

        # generating new artifact IDs for categories that do not exist in overlay 
        for ind in df_new_categories.index:
            if df_new_categories['Artifact ID'][ind] is np.nan:
                df_new_categories['Artifact ID'][ind] = str(uuid.uuid4())
    
        df_new_dict = df_new_categories.set_index("Old Artifact IDs")["Artifact ID"].to_dict()
        df_categories['artifact_id'] = df_categories['artifact_id'].replace(df_new_dict)
        df_categories['Category'] = df_categories['Category'].replace(df_new_dict) 

        logger.info("Categories generated successfully.\n")

    return df_categories


# Category Import function
def ImportCategories(categories_csv, accessToken, manifest_new_categories):

    importheaders = {
        'accept': 'application/json',
        'Authorization': 'Bearer '+accessToken,
        #'Content-Type': 'multipart/form-data'
        }

    params = (
            ('merge_option', 'all'),
        )

    pd.read_csv(categories_csv).to_csv(categories_csv,index=False)

    files = {
            'file': (categories_csv, open(categories_csv, 'rb'))
        }

    try:
        categoryimport_url = hostname+'/v3/governance_artifact_types/category/import'
        cat_import = s.post(categoryimport_url, headers=importheaders, params=params, files=files)
    
        if cat_import.status_code in (200,202):            
            logger.info("Category import has %s, with %s new categories.",json.loads(cat_import.text)['status'], manifest_new_categories)    
            #print(cat_import.text)
            return cat_import.status_code
        else:
            logger.critical("Category import is unsuccessful %s\n", json.loads(cat_import.text)['errors'][0]['message'])
        
    except:
        logger.critical("The below error has occurred. Please ensure that categories csv file exists\n")
        raise

