# This project contains Sample Materials, provided under license.
# Licensed Materials - Property of IBM.
# © Copyright IBM Corp. 2023. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

import argparse
import time
import pandas as pd
import numpy as np
import json
import pip
import glob
try:
    import requests
except ImportError:
    print("\n'requests' is required for this import to work. This module is not available. Will try to install it now.")
    pip.main(["install", "requests"])
    print("\nIf requests was installed successfully you can re-execute the script.")
    raise SystemExit("If requests was installed successfully you can continue with execution, rerun this cell to retest.")
import os
from dotenv import load_dotenv
load_dotenv()

# Load Environment Variables 

hostname = os.getenv("hostname")      
username = os.getenv("username")
password = os.getenv("password")
source_root_category_id = os.getenv("source_root_category_id")
cloned_root_category_id = os.getenv("cloned_root_category_id")
choice = os.getenv("cloning_choice")
mapTermsFlag = os.getenv("mapTermsFlag")
publish_terms = os.getenv("publish_terms")

print("Setting environment variables..")


# KA Cloning

def ikc_cloning():

    import src.terms
    import src.categories
    import src.module_functions
    

    # Setting Up Logging
    logger = src.module_functions.setup_logger('ka-logger-cloning', 'cloning.log')
    
    print("\n*********************   IKC GLOSSARY CLONING UTILITY  *********************\n",
        "\n1. Clone Glossary based on Input Categories.", 
        "\n2. Clone Glossary based on Input Catalogs.",
        "\n3. Clone Glossary based on both Input Categories and Catalog Assets. (1 & 2)\n",
        "\n***************************************************************************\n")


    # Validation for input environmental parameters
    if 'hostname' not in globals() or hostname == None or len(hostname) == 0: 
        logger.critical("'hostname' is a mandatory input parameter and is not provided. Please provide this in the environment variables file.")
        return False
    elif 'username' not in globals() or username == None or len(username) == 0: 
        logger.critical("'username' is a mandatory input parameter and is not provided. Please provide this in the environment variables file.")
        return False
    elif 'password' not in globals() or password == None or len(password) == 0:  
        logger.critical("'password' is a mandatory input parameter and is not provided. Please provide this in the environment variables file.")
        return False
    elif 'source_root_category_id' not in globals() or source_root_category_id == None or  len(source_root_category_id) == 0:  
        logger.critical("'source_root_category_id' is a mandatory input parameter and is not provided. Please provide this in the environment variables file.")
        return False    
    elif 'cloned_root_category_id' not in globals() or cloned_root_category_id == None or  len(cloned_root_category_id) == 0:  
        logger.critical("'cloned_root_category_id' is a mandatory input parameter and is not provided. Please provide this in the environment variables file.")
        return False
    elif 'choice' not in globals() or choice == None or  len(choice) == 0:  
        logger.critical("'cloning_choice' is a mandatory input parameter and is not provided. Please provide this in the environment variables file.")
        return False
    elif 'publish_terms' not in globals() or publish_terms == None or len(publish_terms) == 0:
        logger.critical("'publish_terms' is a mandatory input parameter and is not provided. Please provide this in the environment variables file.")
        return False


    # Authentication to CP4D
    try:    
        accessToken = src.module_functions.authenticate(hostname, username, password)
        logger.info("CP4D Authentication Successful.\n")
    except:
        logger.critical("\nUnable to authenticate! Please check the hostname, username password and try agin\n")
        return False

    catURL = hostname+"/v3/categories/"
    # Validation of Source Root Category and retrieval of name
    logger.debug("Checking if provided Source root category in environment variables exists.")
    source_root_cat_name, source_root_cat_desc = src.module_functions.checkCategory(accessToken, catURL, source_root_category_id)

    # Validation of Target Root Category and retrieval of name
    logger.debug("Checking if provided Cloned root category in environment variables exists.")
    cloned_root_cat_name, cloned_root_cat_desc = src.module_functions.checkCategory(accessToken, catURL, cloned_root_category_id)

    # Validation of Cloning Choice

    if choice == "1":
        try:
            input_categories_list = json.loads(os.getenv("input_categories_list"))
            input_catalogs_list=""
            logger.info("Cloning choice based on Input Categories selected.\n")        
        except:
            logger.critical("No Input Categories found. Please check environment file and try again.")
            return False

    elif choice == "2":
        try:
            input_catalogs_list = json.loads(os.getenv("input_catalogs_list"))
            input_categories_list = ""
            logger.info("Cloning choice based on Input Catalogs selected.\n") 
        except:
            logger.critical("No Input Catalogs found. Please check environment file and try again.")
            return False

    elif choice == "3":
        try:
            input_categories_list = json.loads(os.getenv("input_categories_list"))        
        except:
            logger.critical("No Input Categories found. Please check environment file and try again.")
            return False
        try:
            input_catalogs_list = json.loads(os.getenv("input_catalogs_list"))
        except:
            logger.critical("No Input Catalogs found. Please check environment file and try again.")
            return False
        
        logger.info("Cloning choice based on both options Input Catalogs and Input Categories selected.\n")

    else:
        logger.critical("No possible choice entered. Exiting.\n")
        return False

    # Overlay Check
    # Checks if the catalogs and input categories given in env variables exists in the platform.  
    # If so then checks if its available in the manifest, or creates a new one.

    # STAT VARIABLES
    manifest_total_terms=0
    manifest_total_categories=0
    manifest_existing_terms=0
    manifest_existing_categories=0
    manifest_new_terms=0
    manifest_new_categories=0

    manifest,scenario = src.module_functions.checkManifestInfo(cloned_root_cat_name, input_categories_list, input_catalogs_list, cloned_root_cat_desc, source_root_category_id, accessToken)

    # Need to update & add stats to manifest after terms are cloned before import and publish. 

    manifest = json.loads(manifest)
    print("\nExisting and/or New Input Categories :") 
    if manifest['source_input_categories']['id'] != "":
        for x in manifest['source_input_categories']['name']: print(x)
    else : print("No input catagories provided")

    print("\nExisting and/or New Input Catalogs :")
    if manifest['source_input_catalogs']['cat_name'] != "":
        for x in manifest['source_input_catalogs']['cat_name']: print(x)
    else : print("No input catalogs provided")

    if scenario == 0 : # 1st Pass of Cloning
        logger.info("First time cloning from source to clone category\n")
        logger.debug("New Manifest was created as no previous Manifest was found.\n")
        df_overlay_export_categories=None
        df_overlay_export_terms=None

    elif scenario == 1: # Re-Run/Overlay of Cloning
        logger.debug("Re-Run of Cloning (a.k.a overlay scenario), inputs for last run against this run must be consistent with current latest inputs.")
        
        if manifest['source_root_category']['id'] != source_root_category_id :
            logger.critical("Attempting to clone from a source category : %s onto a clone created from a different source category : %s. This is not supported.", manifest['source_root_category']['id'], source_root_category_id)
            logger.error("The source root category must be consistent in each run of cloning.")
            return False

        print("\n")
        # Zip Export of existing cloned glossary for overlay
        logger.info("Starting Zip export of cloned terms under the cloned root category: %s, with ID : %s. Please wait.",cloned_root_cat_name, cloned_root_category_id)
        
        df_overlay_export_categories, df_overlay_export_terms = src.module_functions.zipExport(accessToken, cloned_root_category_id)
        # Saving info for manifest
        manifest_existing_categories = df_overlay_export_categories.shape[0]
        #manifest_existing_terms = len(df_overlay_export_terms.loc[df_overlay_export_terms['Artifact ID'].notnull()])
        manifest_existing_terms = df_overlay_export_terms["Artifact ID"].count()
        print("Existing Categories in the Glossary : ",manifest_existing_categories, "Existing Terms in the Glossary : ",manifest_existing_terms)


    if choice == "1" or choice == "3": # Below tasks must be done only if there are input categories in the picture.
    # Total Zip Export of the Glossary based on the input category list to get the Unique total list of input categories and subcategories etc.

        input_category = ','.join(manifest['source_input_categories']['id'])
        #print(input_category)
        logger.info("Fetching all unique terms and categories based on unique list of input categories and subcategories. Please wait.")    
        df_export_categories, df_export_terms = src.module_functions.zipExport(accessToken, input_category)
        

        # Get all input categories and their sub-categories from the zip export
        df_input_cat_and_sub_cat_list = pd.DataFrame()
        df_input_cat_and_sub_cat_list[["Name", "Artifact ID", "Category"]] = df_export_categories[["Name", "Artifact ID", "Category"]]

        # Create Unique list of input cats and sub cats, This is required for getting all terms & primary cats for cloning
        input_cat_and_sub_cat_unique_list = list(set(df_input_cat_and_sub_cat_list['Artifact ID']))

        # Fetch All Referenced terms and their Primary cats based on the unique list of input cats and their sub-cats using global search    
        input_cat_unique_terms = src.module_functions.getAllReferencedTerms_and_PrimaryCats(accessToken, input_cat_and_sub_cat_unique_list)    
        input_unique_terms_list = input_cat_unique_terms['Artifact ID'].to_list()
        input_unique_terms_globalID_list = input_cat_unique_terms['Term ID'].to_list()

        #print(input_cat_unique_terms)

        # Unique list of primary cats of all referenced terms.
        input_terms_primary_cat_list = list(set(input_cat_unique_terms['Primary Category ID']))

        # Unique Total list of all input cats , sub cats and primary cats of terms 
        prim_cat_and_input_cat_list = list(set(input_terms_primary_cat_list+input_cat_and_sub_cat_unique_list))

        # Get Category List with their Respective Parent Cats all the way upto Root Category Level 
        logger.debug("Fetching parent categories all the way upto root category level.")
        parent_categories_list = src.categories.getParentCategoryList(accessToken, prim_cat_and_input_cat_list)

        final_categories_list = list(set(parent_categories_list+prim_cat_and_input_cat_list))

        #print(len(final_categories_list), "\n", final_categories_list)

    if choice == "2" or choice == "3":
    # This needs to get all terms and primary categories based on the assignments to catalog assets
        
        getCatalogURL = hostname+'/v2/catalogs'
        for i in input_catalogs_list:
            catalog_id = src.module_functions.getCatalogs(getCatalogURL,accessToken, i)
            if catalog_id == None:
                logger.critical('Please provide a valid Catalog with assets & run again..\n')
                return False
            else:
                logger.info('"%s" with Catalog ID : %s, will be used for publishing assets listed.\n', i, catalog_id) 
            
                # Fetching Catalog Data Assets
                getCatalogAssetsURL = hostname+"/v2/asset_types/asset/search?catalog_id="+catalog_id
                data_asset_dict = src.module_functions.getCatalogAssets(getCatalogAssetsURL,accessToken)

                # Fetch all term assignments of the assets, to get list of categories and terms from the catalog asset assignments
                retrieveAssetURL= hostname+"/v2/assets/"
                df_assigned_terms = src.module_functions.getTermAssignments(retrieveAssetURL, data_asset_dict, accessToken, catalog_id)
                
                # List for cloning
                unique_terms_from_catalog = list(set(df_assigned_terms['Artifact ID']))
                unique_categories_from_catalog = list(set(df_assigned_terms['Primary Category ID']))

                logger.debug("Fetching parent categories all the way upto root category level.")
                catalog_parent_categories_list = src.categories.getParentCategoryList(accessToken, unique_categories_from_catalog)

                if choice == "2" :
                    # Used as input parameter for cloning of terms
                    input_cat_unique_terms = df_assigned_terms
                    
                    final_categories_list = list(set(catalog_parent_categories_list+unique_categories_from_catalog))
                    input_unique_terms_list = unique_terms_from_catalog
                    #print(input_cat_unique_terms)
                    #print(final_categories_list, input_unique_terms_list)

    if choice == "3":

        # Total List of categories in both route 1 & 2
        # Unique cats and terms list based on catagories and catalog route
        final_categories_list = list(set(final_categories_list+unique_categories_from_catalog+catalog_parent_categories_list))
        input_unique_terms_list = list(set(input_unique_terms_list+unique_terms_from_catalog))
        
        df1 = input_cat_unique_terms.filter(['Artifact ID','Business Term Name', 'Category', 'Primary Category ID' ], axis=1)
        df2 = df_assigned_terms.filter(['Artifact ID','Business Term Name', 'Category', 'Primary Category ID' ], axis=1)

        # Final list of Unique Cats & Terms Dataframe which comprised of terms with and without artifact IDs
        input_cat_unique_terms = pd.concat([df1,df2]).drop_duplicates().reset_index(drop=True)

        #print(input_cat_unique_terms)

                                    
    # By this point the terms and categories based on all 3 cloning choices are put together

    # Create Category Dictionary
    category_dictionary = src.categories.generateCategoryDictionary(accessToken, final_categories_list)
    #print(category_dictionary)
    df_categories = pd.DataFrame(category_dictionary)

    # Create New Artifact IDs for all the categories - Handles First Pass and Overlay
    df_categories = src.categories.handleCategoryArtifact_IDs(df_categories, 
                                                            scenario, 
                                                            cloned_root_category_id, 
                                                            cloned_root_cat_name, 
                                                            cloned_root_cat_desc, 
                                                            source_root_category_id,
                                                            df_overlay_export_categories)

    #print(df_categories)

    # Category Stats for manifest
    manifest_total_categories = df_categories.shape[0]
    manifest_new_categories = manifest_total_categories - manifest_existing_categories

    # Create Terms Dictionary
    terms_dictionary = src.terms.generateTermsDictionary(accessToken, 
                                                        input_unique_terms_list, 
                                                        df_categories, 
                                                        scenario, 
                                                        df_overlay_export_terms, 
                                                        input_cat_unique_terms)

    # Replace all Relationship Terms with New Artifact IDs - Handles First Pass and Overlay
    df_final_terms = src.terms.handleTermArtifact_IDs(terms_dictionary)

    #manifest_total_terms = df_final_terms["artifact_id"].count()

    for i in df_final_terms["artifact_id"]: 
        if i!="": manifest_total_terms = manifest_total_terms+1

    manifest_new_terms = manifest_total_terms - manifest_existing_terms

    if manifest_new_terms == 0 and manifest_new_categories == 0:
        logger.info("No New Terms to be cloned based on current input parameters.")

        
        # Map Terms to Catalog Assets
        if  mapTermsFlag == "True" and publish_terms == "True":
            logger.info("Starting term assignment mappings to catalog assets.")
            if choice == "1":
                # Fetch all term assignments of the assets
                getDataAssetsURL =  hostname+"/v3/search"
                df_scope_assigned_terms = src.module_functions.getNoCatalogTermAssignedAssets(getDataAssetsURL, input_unique_terms_globalID_list, accessToken)
                logger.info('%s terms identified based on available mappings to columns.\n', df_scope_assigned_terms.shape[0])

                map_terms = df_scope_assigned_terms[["ColumnName", "Business Term Name", "Route", "Catalog ID"]].copy() 
                catalog_id_list = list(set(list(map_terms.loc[map_terms['Catalog ID'].notnull(), 'Catalog ID'])))

            elif choice == "2" or choice == "3":
                map_terms =  df_assigned_terms.filter(["ColumnName", "Business Term Name", "Route", "Catalog ID"], axis=1)
                catalog_id_list = manifest['source_input_catalogs']['cat_id']

            retrieveAssetURL= hostname+"/v2/assets/"

            for catalog_id in catalog_id_list:            

                getCatalogAssetsURL = hostname+"/v2/asset_types/asset/search?catalog_id="+catalog_id
                data_asset_dict = src.module_functions.getCatalogAssets(getCatalogAssetsURL,accessToken)
                new_categories_list = list(df_categories['artifact_id'])
                df_new_terms = src.terms.prepareNewTerms(accessToken, map_terms, new_categories_list)
                final_result = src.terms.mapCatalogTermAssets(map_terms, df_new_terms, data_asset_dict, accessToken, catalog_id)              
                
            logger.info("Terms mappings completed.")
        return True  


    # Rounding up manifest details.
    manifest["total_terms"] = manifest_total_terms
    manifest["new_terms"] = manifest_new_terms
    manifest["existing_terms"] = manifest_existing_terms

    manifest["total_categories"] = manifest_total_categories
    manifest["new_categories"] = manifest_new_categories
    manifest["existing_categories"] = manifest_existing_categories


    # Updating Root Cat Description with latest manifest info and stats
    cloned_root_cat_desc = "This is the root category created into which the cloned terms and categories will be placed. \nCopyright IBM Corp. 2020, 2023."
    df_categories.loc[df_categories["artifact_id"] == cloned_root_category_id, "Description"] = cloned_root_cat_desc+" Overlay Manifest  "+str(manifest)


    # Create Category CSV File - might move this to update manifest details
    df_categories.reindex(columns=["artifact_id", 
                                "Name", 
                                "Artifact Type", 
                                "Category", 
                                "Description", 
                                "Tags",
                                "Stewards"]).to_csv('supplementary-glossary-categories.csv', index=False ,encoding='utf-8-sig')
    print("\n")
    logger.info("Categories csv file <supplementary-glossary-categories.csv> is generated...")

    # Create Terms CSV File - might move this to update manifest details

    df_final_terms.reindex(columns=["artifact_id", 
                                    "Name", 
                                    'Artifact Type', 
                                    "Category", 
                                    "Description", 
                                    "Tags", 
                                    "Classifications", 
                                    "Stewards", 
                                    "Related Terms", 
                                    "Part Of Terms",
                                    "Type Of Terms",
                                    "Abbreviations", 
                                    "Data Classes",
                                    "Synonyms",
                                    "Secondary Categories"]).to_csv('supplementary-glossary-terms.csv', index=False ,encoding='utf-8-sig')
    logger.info("Terms csv file <supplementary-glossary-terms.csv> is generated...\n")

    # Import Categories & Terms File to IKC
    categories_csv = "supplementary-glossary-categories.csv"
    terms_csv = "supplementary-glossary-terms.csv"

    #Import Cats
    category_import = src.categories.ImportCategories(categories_csv, accessToken, manifest_new_categories)
    logger.info("Preparing for Terms import. Please wait.")
    time.sleep(15) 

    #Import Terms
    terms_import_workflow = src.terms.ImportTerms(terms_csv, accessToken)


    if publish_terms == "True" : 
        # Publish Terms
        src.terms.publishTerms(accessToken, terms_import_workflow, manifest_new_terms)
        time.sleep(30)

    else:
        logger.info("Terms are imported into draft state. You can publish the terms via UI.") 
        logger.info("Please find them here: %s/gov/workflow/tasks. This scenario will not be doing term mappings.", hostname)   
        print("\n#######################################################################  CLONING METRICS  ###########################################################################\n",
            "\n TOTAL TERMS             : ", manifest_total_terms, 
            "\n TOTAL CATEGORIES        : ", manifest_total_categories,
            "\n NEW TERMS               : ", manifest_new_terms, 
            "\n NEW CATEGORIES          : ", manifest_new_categories,
            "\n EXISTING TERMS          : ", manifest_existing_terms, 
            "\n EXISTING CATEGORIES     : ", manifest_existing_categories, "\n\n",
            "\n Kindly note that the categories may take a while to appear on the cluster after being published.\n", 
            "#####################################################################################################################################################################")
        return True

    # Map Terms to Catalog Assets
    if  mapTermsFlag == "True" and publish_terms == "True":
        logger.info("Starting term assignment mappings to catalog assets.")
        if choice == "1":
            # Fetch all term assignments of the assets
            getDataAssetsURL =  hostname+"/v3/search"
            df_scope_assigned_terms = src.module_functions.getNoCatalogTermAssignedAssets(getDataAssetsURL, input_unique_terms_globalID_list, accessToken)
            logger.info('%s terms identified based on available mappings to columns.\n', df_scope_assigned_terms.shape[0])

            map_terms = df_scope_assigned_terms[["ColumnName", "Business Term Name", "Route", "Catalog ID"]].copy() 
            catalog_id_list = list(set(list(map_terms.loc[map_terms['Catalog ID'].notnull(), 'Catalog ID'])))

        if choice == "2" or choice == "3":
            map_terms =  df_assigned_terms.filter(["ColumnName", "Business Term Name", "Route", "Catalog ID"], axis=1)
            catalog_id_list = manifest['source_input_catalogs']['cat_id']

        retrieveAssetURL= hostname+"/v2/assets/"

        for catalog_id in catalog_id_list:
            
            getCatalogAssetsURL = hostname+"/v2/asset_types/asset/search?catalog_id="+catalog_id
            data_asset_dict = src.module_functions.getCatalogAssets(getCatalogAssetsURL,accessToken)
            new_categories_list = list(df_categories['artifact_id'])
            df_new_terms = src.terms.prepareNewTerms(accessToken, map_terms, new_categories_list).drop_duplicates().reset_index(drop=True)
            final_result = src.terms.mapCatalogTermAssets(map_terms, df_new_terms, data_asset_dict, accessToken, catalog_id)              
        logger.info("Terms mappings completed.")

    print("\n#######################################################################  CLONING METRICS  ###########################################################################\n",
        "\n TOTAL TERMS             : ", manifest_total_terms, 
        "\n TOTAL CATEGORIES        : ", manifest_total_categories,
        "\n NEW TERMS               : ", manifest_new_terms, 
        "\n NEW CATEGORIES          : ", manifest_new_categories,
        "\n EXISTING TERMS          : ", manifest_existing_terms, 
        "\n EXISTING CATEGORIES     : ", manifest_existing_categories, "\n\n",
        "CLONING IS COMPLETED, PLEASE FIND YOUR GLOSSARY HERE : ", hostname+"/gov/categories/"+cloned_root_category_id, 
        "\n Kindly note that the terms may take a while to appear on the cluster after being published.\n", 
        "#####################################################################################################################################################################")
    
    return True

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description= 'See the environment variables file(.env) for help to set the mandatory variables. To view .env file from the command line/terminal Navigate to ikc-cloning/ folder.')
    
    args = parser.parse_args()
    
    result = ikc_cloning()

    if result == False:
       print("Cloning has exited. Please visit cloning.log for more information.")



   

    










