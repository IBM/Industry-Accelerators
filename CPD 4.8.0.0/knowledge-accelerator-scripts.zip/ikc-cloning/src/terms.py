# This project contains Sample Materials, provided under license.
# Licensed Materials - Property of IBM.
# © Copyright IBM Corp. 2023. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from datetime import datetime
import json
import os, sys
import pip
import logging
import src.module_functions
import time
import pandas as pd
import numpy as np
import uuid



hostname = os.getenv("hostname")      
username = os.getenv("username")
password = os.getenv("password")

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
s = requests.Session()

logger = src.module_functions.setup_logger('ka-logger-terms', 'cloning.log')

def generateTermsDictionary(accessToken, input_unique_terms_list, df_categories, scenario, df_overlay_export_terms, input_cat_unique_terms):

    termsDict=[]

    headers = {
        'Content-Type': "application/json",
        'Authorization': "Bearer "+accessToken
    }

    for i in input_unique_terms_list:
        url = hostname+"/v3/glossary_terms/"+i+"/versions?include_relationship=all&limit=200"
        res=s.get(url,headers=headers,verify=False)
        json_term_details = json.loads(res.text)

        version_id = json_term_details['resources'][0]['metadata']['version_id']
        artifact_type = json_term_details['resources'][0]['metadata']['artifact_type']
        artifact_id = json_term_details['resources'][0]['metadata']['artifact_id']
        term_name = json_term_details['resources'][0]['metadata']['name']    
        if 'child_description' in json_term_details['resources'][0]['entity']['parent_category']['resources'][0]['entity']: 
            term_description = json_term_details['resources'][0]['entity']['parent_category']['resources'][0]['entity']['child_description']+" \n\n\n CLONED FROM : "+hostname+"/gov/terms/"+artifact_id+"/"+version_id        
        else:
            term_description = "CLONED FROM : "+hostname+"/gov/terms/"+artifact_id+"/"+version_id

        primary_cat_name = json_term_details['resources'][0]['entity']['parent_category']['resources'][0]['entity']['parent_name']
        df_categories = df_categories.drop_duplicates(subset=['artifact_id', 'Name', 'Category'])
        new_primary_cat_id = df_categories.loc[df_categories['Name'] == primary_cat_name, 'artifact_id'].item()
        print("Term cloned : ", term_name, " || Primary Category : ",primary_cat_name)

        # Handling Artifact ID for 1st Pass and Overlay 
        if scenario == 0:
            artifact_id = str(uuid.uuid4())
            
        elif scenario == 1:
            #if term_name in df_overlay_export_terms['Name'].values:            
            #    artifact_id =  df_overlay_export_terms.loc[df_overlay_export_terms['Name'] == term_name, 'Artifact ID'].item()
            #else:
            #    artifact_id = str(uuid.uuid4())            

            if artifact_id in df_overlay_export_terms['Artifact ID'].values:
                artifact_id =  df_overlay_export_terms.loc[df_overlay_export_terms['Artifact ID'] == artifact_id, 'Artifact ID'].item()                
            else:
                artifact_id = str(uuid.uuid4())                
                

        #Secondary Categories
        first_sec_category=""
        sec_cats = []
        if 'categories' in json_term_details['resources'][0]['entity']:
            for j in json_term_details['resources'][0]['entity']['categories']['resources']:
                if j['entity']['target_name'] in df_categories['Name'].values:               
                    new_sec_cat_id = df_categories.loc[df_categories['Name'] == j['entity']['target_name'], 'artifact_id'].item()
                    sec_cats.append(new_sec_cat_id)
        if len(sec_cats)>0:
            first_sec_category = sec_cats[0]
        #print(first_sec_category)

        #Tags
        firstTag = ""
        tags = []
        if 'tags' in json_term_details['resources'][0]['metadata']:
            for tag in json_term_details['resources'][0]['metadata']['tags']:
                tags.append(tag)
        if len(tags) > 0:
            firstTag = tags[0]
        #print(firstTag)

        #Classifications
        firstClassification = ""
        Classifications = []
        if 'classifications' in json_term_details['resources'][0]['entity']:
            for j in json_term_details['resources'][0]['entity']['classifications']['resources']:
                Classifications.append(j['entity']['target_name'])
        if len(Classifications) > 0:
            firstClassification = Classifications[0]
        #print(firstClassification)

        #Data Classes
        firstDataClass = ""
        data_classes = []
        if 'data_classes' in json_term_details['resources'][0]['entity']:
            for l in json_term_details['resources'][0]['entity']['data_classes']['resources']:
                data_classes.append(l['entity']['target_name'])            
        if len(data_classes) > 0:
            firstDataClass = data_classes[0]
        #print(firstDataClass)

        # Part Of Terms
        firstPartOfTerm = ""
        partOfTerms = []
        if 'is_of_terms' in json_term_details['resources'][0]['entity']:
            for k in json_term_details['resources'][0]['entity']['is_of_terms']['resources']:
                if k['entity']['relationship_type'] == 'is_part_of':
                    curPartTerm=k['entity']['parent_name']
                    if curPartTerm in input_cat_unique_terms['Business Term Name'].values:
                        #part_term_id = df_terms.loc[df_terms['Name'] == curPartTerm, 'artifact_id'].item()
                        partOfTerms.append(curPartTerm)

        if len(partOfTerms) > 0:
            firstPartOfTerm = partOfTerms[0]
        #print(partOfTerms)
        
        # Type Of Terms
        firstTypeOfTerm = ""
        typeOfTerms = []
        if 'is_a_type_of_terms' in json_term_details['resources'][0]['entity']:
            for k in json_term_details['resources'][0]['entity']['is_a_type_of_terms']['resources']:
                if k['entity']['relationship_type'] == 'is_type_of':
                    curTypeTerm=k['entity']['parent_name']
                    if curTypeTerm in input_cat_unique_terms['Business Term Name'].values:
                        #type_term_id = df_terms.loc[df_terms['Name'] == curTypeTerm, 'artifact_id'].item()
                        typeOfTerms.append(curTypeTerm)

        if len(typeOfTerms) > 0:
            firstTypeOfTerm = typeOfTerms[0]
        #print(typeOfTerms)

        # Related Terms
        firstRelatedTerm = ""
        relatedTerms = []
        if 'related_terms' in json_term_details['resources'][0]['entity']:
            for k in json_term_details['resources'][0]['entity']['related_terms']['resources']:
                if k['entity']['relationship_type'] == 'related':
                    curRelatedTerm=k['entity']['target_name']
                    if curRelatedTerm in input_cat_unique_terms['Business Term Name'].values:
                        #related_term_id = df_terms.loc[df_terms['Name'] == curRelatedTerm, 'artifact_id'].item()
                        relatedTerms.append(curRelatedTerm)

        if len(relatedTerms) > 0:
            firstRelatedTerm = relatedTerms[0]
        #print(relatedTerms)            

        termsDict.append({       
                            
                        "artifact_id" : artifact_id,
                        "Name": term_name,
                        "Artifact Type": artifact_type,
                        "Category": new_primary_cat_id,
                        "Description": term_description,
                        "Tags": firstTag,
                        "Classifications": firstClassification,
                        "Stewards": "",
                        "Related Terms": firstRelatedTerm,
                        "Part Of Terms": firstPartOfTerm,
                        "Type Of Terms" : firstTypeOfTerm,
                        "Abbreviations" : "",
                        "Data Classes": firstDataClass,
                        "Synonyms": "",
                        "Secondary Categories":first_sec_category
                    })
        
        rowsNeeded = max(len(sec_cats), 
                     len(data_classes), 
                     len(Classifications), 
                     len(tags), 
                     len(relatedTerms), 
                     len(partOfTerms), 
                     len(typeOfTerms)
                    )
        
        if rowsNeeded > 1:
            for rowNum in range(1,rowsNeeded):
                newCsvRow = {                                    
                                        
                                    "artifact_id" : "",
                                        "Name": "",
                                        "Artifact Type": "",
                                        "Category": "",
                                        "Description": "",
                                        "Tags": "",
                                        "Classifications": "",
                                        "Stewards": "",
                                        "Related Terms": "",
                                        "Part Of Terms": "",
                                        "Type Of Terms" : "",
                                        "Abbreviations" : "",
                                        "Data Classes": "",
                                        "Synonyms": "",
                                        "Secondary Categories":""
                                        
                                        }

                if rowNum < len(Classifications):
                    newCsvRow["Classifications"] = Classifications[rowNum]

                if rowNum < len(tags):
                    newCsvRow["Tags"] = tags[rowNum]
                        
                if rowNum < len(sec_cats):
                    newCsvRow["Secondary Categories"] = sec_cats[rowNum]
                                
                if rowNum < len(data_classes):
                    newCsvRow["Data Classes"] = data_classes[rowNum]
                
                if rowNum < len(partOfTerms):
                    newCsvRow["Part Of Terms"] = partOfTerms[rowNum]
                
                if rowNum < len(typeOfTerms):
                    newCsvRow["Type Of Terms"] = typeOfTerms[rowNum]
                
                if rowNum < len(relatedTerms):
                    newCsvRow["Related Terms"] = relatedTerms[rowNum]            
                                
                termsDict.append(newCsvRow)

    return termsDict

def handleTermArtifact_IDs(termsDict):    

    # Replace Relationship term names with latest Artifact IDs
    df_temp_terms = pd.DataFrame(termsDict)
    for x in termsDict:
        if len(x['Part Of Terms'])!=0:
            x['Part Of Terms'] = df_temp_terms.loc[df_temp_terms['Name'] == x['Part Of Terms'], 'artifact_id'].item()
    for x in termsDict:
        if len(x['Type Of Terms'])!=0:
            x['Type Of Terms'] = df_temp_terms.loc[df_temp_terms['Name'] == x['Type Of Terms'], 'artifact_id'].item()
    for x in termsDict:
        if len(x['Related Terms'])!=0:
            x['Related Terms'] = df_temp_terms.loc[df_temp_terms['Name'] == x['Related Terms'], 'artifact_id'].item()
    
    df_final_terms = pd.DataFrame(termsDict)

    return df_final_terms
   

def ImportTerms(terms_csv, accessToken):
 
    importheaders = {
        'accept': 'application/json',
        'Authorization': 'Bearer '+accessToken,
        #'Content-Type': 'multipart/form-data'
        }

    params = (
            ('merge_option', 'all'),
        )

    pd.read_csv(terms_csv).to_csv(terms_csv,index=False)

    files = {
            'file': (terms_csv, open(terms_csv, 'rb'))
        }
    
    try:
        termsimport_url = hostname+'/v3/governance_artifact_types/glossary_term/import'
        term_import = s.post(termsimport_url, headers=importheaders, params=params, files=files)
        if term_import.status_code in (200,202):
            wf_json=json.loads(term_import.text)
            #logger.info("Terms import has %s\n",wf_json['status'])#, " with", len(NewTermsArtifactIDs), "terms")
            return wf_json['workflow_id']
            #print("Number of Business terms imported:",max(json.loads(term_import.text)['operations_count']['glossary_term']['IMPORT_MODIFY'],json.loads(term_import.text)['operations_count']['glossary_term']['IMPORT_CREATE']))
        else:
            logger.critical("Import of Business Terms failed.\n")
            raise Exception(json.loads(term_import.text)['errors'][0]['message'])
    except:
        logger.critical("The below error has occurred.\n")
        raise
    

def publishTerms(accessToken, wf_json_workflowDetails, manifest_new_terms):
    headers = {
    'Content-Type': "application/json",
    'Authorization': "Bearer "+accessToken

    }
    try:
        wf_url=hostname+"/v3/workflows/"+wf_json_workflowDetails+"?includeUserTasks=true"
        wf_response=s.get(wf_url,headers=headers)
        if wf_response.status_code in (200,202):
            idtopublish=json.loads(wf_response.text)['entity']['user_tasks'][0]['metadata']['task_id']
    except:
        logger.critical("The below error has occurred. Please ensure that terms are imported correctly\n")
        raise

    data = {
    "action": "complete",
    "form_properties": [
        {
            "id": "action",
            "value": "#publish"
            }
        ]
    }

    publish_url=hostname+'/v3/workflow_user_tasks/'+idtopublish+'/actions'

    try:
        publish = s.post(publish_url, headers=headers, json=data, verify=False)

        if publish.status_code in (200,202,204):            
            logger.info("Terms import has SUCCEEDED, with %s new business terms.", manifest_new_terms)    
    except:
        logger.critical("The below error has occurred. Please ensure that terms are imported correctly\n")
        raise


def prepareNewTerms(accessToken, map_terms, category_ids):
    new_terms=pd.DataFrame(columns=['Global ID','Business Term Name'])

    #url = hostname+"/v3/search"
    
    headers = {
    'Content-Type': "application/json",
    'Authorization': "Bearer "+accessToken
    }
    
    
    for j in category_ids:
        
        url = hostname+"/v3/categories/"+j
        #print(j)
        res = s.get(url, headers=headers, verify=False)
        
        for i in json.loads(res.text)['entity']['parent_category_for']:
            #print(i)
            term_id = i['entity']['target_global_id']
            termName = i['entity']['target_name']
            #print(termName, term_id)
        
            for x in map_terms['Business Term Name']:
                if termName == x:
                    #print(termName, new_artifact_id)
                    new_row = {'Global ID' :  term_id, 'Business Term Name' : termName}
                    new_terms.loc[len(new_terms)] = new_row
                    #print("New ROW : ", new_row)                    
    
    return new_terms


def mapCatalogTermAssets(map_terms, new_terms, data_asset_dict, accessToken, catalog_id):
    map_terms=map_terms.sort_values(by=['Route','ColumnName'])
    
    Terms_Headers=pd.merge(map_terms,new_terms,left_on='Business Term Name',right_on='Business Term Name',how='inner')
    Terms_Headers=Terms_Headers.drop_duplicates()

    for data_asset_id, data_asset_name in data_asset_dict.items():
    
        # Catalog asset id of the particular csvs
        # for each file name in the map_terms if the csv with this file name exists, get its asset_id from the catalog and use the post request publish create column_info attribute
        # This column info attribute is necessary to map the busines terms to column to header
        url = hostname+"/v2/assets/"
        headers = {
            'Content-Type': "application/json",
            'Authorization': "Bearer "+accessToken
        }
        payload={"name": "column_info", "entity":{}}
        t=requests.post(url+data_asset_id+"/attributes?catalog_id="+catalog_id,json=payload,headers=headers,verify=False)
        #print(json.loads(t.text))
        
        # For each column header in the file map its corresponding business term retrieved from the above join in the dataframe
        i=0
        for index, rows in Terms_Headers.iterrows():
            i+=1
            column_name = rows.ColumnName.strip()
            logger.info("%s, %s is mapped to %s",i,column_name.strip(), rows['Business Term Name'])
            # Create list for the current row 
            # Below payload is used for the patch request to map the header to business %s is mapped
            payload=[{"op":"add","path":"/"+column_name+"/column_terms/-","value":{"term_display_name":rows['Business Term Name'],"term_id":rows["Global ID"]},"attribute":"column_info"}]
            
            try:
                patch_url=url+data_asset_id+"/attributes/column_info?catalog_id="+catalog_id

                get_attribute=s.get(patch_url,json=payload,headers=headers,verify=False)
                
                if get_attribute.status_code in (200,202):
                    get_json=json.loads(get_attribute.text)
                    try: 
                        existing_term_ids = [n['term_id'] for n in get_json['column_info'][column_name]['column_terms']]
                        #print("Existing Term IDs: ", existing_term_ids)
                        if rows["Global ID"] in existing_term_ids:
                            logger.info('Skipping mapping term %s : already mapped', rows["Business Term Name"])
                            continue
                    

                        patch_attribute=s.patch(patch_url,json=payload,headers=headers,verify=False)

                        if patch_attribute.status_code in (200,202):
                            mt_json=json.loads(patch_attribute.text)
                            #logger.info("Term to Asset map returned %s\n",str(patch_attribute.status_code))
                        else:
                            logger.critical("Mapping of Business Terms failed.\n")
                            raise Exception(json.loads(patch_attribute.text)['errors'][0]['message'])
                        
                    except:pass
            except:
                logger.critical("The below error has occurred.\n")
                raise
    return True