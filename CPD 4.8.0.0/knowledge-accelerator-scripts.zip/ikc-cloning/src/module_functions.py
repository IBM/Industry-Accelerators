# This project contains Sample Materials, provided under license.
# Licensed Materials - Property of IBM.
# © Copyright IBM Corp. 2023. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import datetime
import json
import os, sys
import pip, ast
import logging
import shutil
import time
import pandas as pd
import numpy as np
import uuid
import glob
from zipfile import ZipFile
import src.terms

# Environmental variables
hostname = os.getenv("hostname")      
username = os.getenv("username")
password = os.getenv("password")
source_root_category_id = os.getenv("source_root_category_id")
cloned_root_category_id = os.getenv("cloned_root_category_id")

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
s = requests.Session()

def setup_logger(name, file):
    # Create a logger
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    # Create a file handler
    fh = logging.FileHandler(file)
    fh.setLevel(logging.DEBUG)

    # Create a console handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)

    # Create a formatter
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)

    # Add handlers to the logger
    logger.addHandler(fh)
    logger.addHandler(ch)

    return logger

logger = setup_logger('ka-logger-modules', 'cloning.log')


def authenticate(hostname, username, password):

    # Authenticate the cluster with specified username and password and returns access token
    wkcURLauth = hostname + "/icp4d-api/v1/authorize"

    # Payload with username and password
    payload={
        "username": username,
        "password": password
    }

    # Header with json format
    headers = {
        'Content-Type': "application/json",
        'cache-control': "no-cache"
    }

    # Creates a post request with the endpoints specified above in the wkcURLauth variable with payload and header.
    try:
        res = s.post(wkcURLauth,headers=headers,json=payload, verify=False)
        logger.debug("Attempting login to Cloud Pak for Data.\n")
        
    except:
        logger.error("Unable to connect to CP4D. Please check your connection and if your CP4D cluster URL is correct.\n")
        print(res.text)
        raise
        
    if res.status_code == 200:
        accessToken=json.loads(res.text)['token']
        return accessToken
    else:
        logger.error("Username or API Key are incorrect.\n")
        raise ValueError(res.text)

def checkCategory(accessToken, catURL, category_id):

    
    headers = {
        'Content-Type':'application/json',
        'Authorization':'Bearer '+ accessToken,
    }
    getURL = catURL+category_id
    #print(getURL)
    res=s.get(getURL, headers=headers,verify=False)

    if res.status_code == 200:
        if 'metadata' not in json.loads(res.text):
            logger.error("Issue with provided input category")
            exit()
        else:
            CatName = json.loads(res.text)['metadata']['name']
            CatDescription = json.loads(res.text)['entity']['long_description']
            #artifact_id = json.loads(d.text)['metadata']['artifact_id']        
            logger.info('Category Name : %s with artifact id : %s exists', CatName, category_id)
            return CatName, CatDescription
    else:
        logger.critical('Category does not exist. or user has no permissions to the glossary. Please check and try again')
        exit()


def checkManifestInfo(inputCatName, secondaryCategoryList, catalogsList, inputCatDescription, input_root_category_id, accessToken):    
    
    source_input_categories={}
    ids = []
    names = []
    cat_id = []
    cat_names = []
    source_input_catalogs={}
    hostname = os.getenv("hostname")
    username = os.getenv("username")
    catURL = hostname+"/v3/categories/"
    getCatalogURL = hostname+'/v2/catalogs'

    if inputCatDescription.find("{") == -1:
        logger.debug("Creating new manifest for first clone.\n")

        
        # Handling input Categories
        logger.info("Input Categories entered by the user :")
        for i in secondaryCategoryList:
            CatName, CatDescription = checkCategory(accessToken, catURL, i)
            ids.append(i)
            names.append(CatName)
        source_input_categories = {
                                    "id" : ids, 
                                    "name" : names
                                }
        # Handling Catalogs        
        logger.info("Input Catalogs entered by the user :")
        for j in catalogsList:
            catalog_id = getCatalogs(getCatalogURL,accessToken, j)
            cat_id.append(catalog_id)
            cat_names.append(j)
        source_input_catalogs = {
                                    "cat_id" : cat_id,
                                    "cat_name" : cat_names
                            }
        # New Manifest
        new_manifest = {
            "source_root_category": 
                {
                "id": input_root_category_id, 
                "name": inputCatName
                },
            "source_input_categories": source_input_categories,
            "source_input_catalogs": source_input_catalogs,
            "started_at": time.strftime(str(datetime.datetime.now())), 
            "user_name": username,
            "total_terms": "",
            "new_terms": "",
            "existing_terms": "",
            "total_categories": "",
            "new_categories" : "",
            "existing_categories" : ""
        }
        logger.debug("\nMANIFEST INFO : %s",new_manifest)
        return json.dumps(new_manifest), 0

    else:
        logger.debug("Manifest info found, script will update manifest with new details.\n")
        substring1 = inputCatDescription.find("{")
        substring2 = inputCatDescription.rfind("}")+1
        #print(substring1, substring2)
        #print(inputCatDescription[substring1:substring2])
        #print("\n\n\n", json.loads(json.dumps(inputCatDescription[substring1:substring2])))
        try : 
            old_manifest = json.loads(inputCatDescription[substring1:substring2])
        except : 
            old_manifest = ast.literal_eval(inputCatDescription[substring1:substring2])
            #old_manifest = json.dumps(old_manifest)
                    
        logger.debug("OLD MANIFEST INFO : %s", old_manifest)        
        

        # Categories 
        if len(list(old_manifest["source_input_categories"]["id"])) >= 1 and len(secondaryCategoryList) == 0:
            logger.info("The current glossary was initally cloned with input categories included.")  
            secondaryCategoryList = list(old_manifest["source_input_categories"]["id"])  
        else:
            for i in list(old_manifest["source_input_categories"]["id"]):
                if i not in secondaryCategoryList:
                    secondaryCategoryList.append(i)
                    
            for x in secondaryCategoryList:
                cat_name, cat_desc = checkCategory(accessToken, catURL, x)  
                if cat_name not in list(old_manifest["source_input_categories"]["name"]):           
                    old_manifest['source_input_categories']['name'].append(cat_name)

        # Catalogs
        if len(list(old_manifest["source_input_catalogs"]["cat_name"])) >= 1 and len(catalogsList) == 0:
            logger.info("The current glossary was initally cloned with catalog assets included.")
            catalogsList = list(old_manifest["source_input_catalogs"]["cat_name"])

        else : 
            for i in list(old_manifest["source_input_catalogs"]["cat_name"]):
                if i not in catalogsList:
                    catalogsList.append(i)
                    
            for x in catalogsList:
                catalog_id = getCatalogs(getCatalogURL,accessToken, x)
                if catalog_id not in list(old_manifest["source_input_catalogs"]["cat_id"]):           
                    old_manifest['source_input_catalogs']['cat_id'].append(catalog_id)

        new_manifest = {
            "source_root_category": 
                {
                "id": input_root_category_id, 
                "name": inputCatName
                },
            "source_input_categories": {
                                            "id" : secondaryCategoryList,
                                            "name" : old_manifest['source_input_categories']['name']
                                },
            "source_input_catalogs": {
                                            "cat_id" : old_manifest['source_input_catalogs']['cat_id'], 
                                            "cat_name" : catalogsList 
                                    },
            "started_at": time.strftime(str(datetime.datetime.now())), 
            "user_name": username,
            "total_terms": "",
            "new_terms": "",
            "existing_terms": "",
            "total_categories": "",
            "new_categories" : "",
            "existing_categories" : ""
        }
        logger.debug("\nNEW MANIFEST INFO : %s", new_manifest)

        return json.dumps(new_manifest), 1

        
def zipExport(accessToken, input_root_category_id):

    headers = {
        'Content-Type':'application/json',
        'Authorization':'Bearer '+ accessToken,
    }

    dir = 'temp'
    
    if os.path.exists(dir):
        shutil.rmtree(dir)
    os.mkdir(dir)
    extrall = os.path.join('temp', 'wkc_export')
    shutil.rmtree(extrall, ignore_errors=True)
    os.mkdir(extrall)

    url = hostname+"/v3/governance_artifact_types/export?artifact_id_mode=always&artifact_types=category,glossary_term&category_ids="+str(input_root_category_id)+"&include_custom_attribute_definitions=false"
    #print(url)
    d = s.get(url,verify=False,headers=headers)
    time.sleep(20)
    if d.status_code == 200:
        logger.debug("Zip Export Successfully completed.")
    
    zfile = os.path.join('temp', 'all.zip')

    with open(zfile, 'wb') as wkczip:
        for chunk in d.iter_content(chunk_size=1024):
            if chunk:
                wkczip.write(chunk)
    
    with ZipFile(zfile) as zipObj:
        zipObj.extractall(extrall)

    for file1 in glob.glob("temp/wkc_export/category/category*.csv"):    
        df_export_categories = pd.read_csv(file1)

    for file2 in glob.glob("temp/wkc_export/glossary_term/glossary_term*.csv"):
        df_export_terms = pd.read_csv(file2)
    
    
    return df_export_categories, df_export_terms


def getCatalogs(getCatalogURL, accessToken, catalogName):
    
    headers = {
        'Content-Type':'application/json',
        'Authorization':'Bearer '+ accessToken,
    }
    try:
        res = s.get(getCatalogURL,verify=False,headers=headers)
        logger.debug("Getting Catalog details..\n")
    except:
        logger.error("Unable to connect to CP4D. Please check your connection and if your CP4D cluster URL is correct.\n")
        print(res.text)
        raise

    if res.status_code == 200:
        fetch_catalog = json.loads(res.text)

        for catalogs in fetch_catalog['catalogs']:
            if catalogs['entity']['name'] == catalogName:
                cat_id = catalogs['metadata']['guid']
                logger.info("Catalog Name : %s with Catalog ID : %s exists", catalogName, cat_id)
                return cat_id
    else:
        logger.error('Assets/Catalog does not exist, Fetching Catalog Details failed\n', res.text)
        #raise ValueError(res.text)
        exit()


def getCatalogAssets(getCatalogAssetsURL, accessToken):

    headers = {
    'Content-Type': "application/json",
    'Authorization': "Bearer " + accessToken,
    'Cache-Control': "no-cache",
    'Connection': "keep-alive"
    }

    payload = {
                "query":"*:*",
                "limit":200
                }
    try:
        res=s.post(getCatalogAssetsURL,json=payload,headers=headers,verify=False)        
        #for i in json.loads(res.text)['results']:
            #print(i['metadata']['name'])

    except:
        logger.error("The below error has occurred. Please check that the parameters entered are correct.\n")
        print(res.text) 
        raise

    if res.status_code == 200:
        logger.debug("Catalog Assets are retrieved successfully.")
        
        # Get Asset IDs of the Data Assets retrieved
        
        data_asset_dict={}
        for i in json.loads(res.text)['results']:
            if i['metadata']['asset_type'] == 'data_asset':
                logger.info("Asset Details : %s :: %s", i['metadata']['name'], i['metadata']['asset_id'])
                data_asset_dict[i['metadata']['asset_id']]=i['metadata']['name']
                
        return data_asset_dict
            
    else:
        logger.error('The below error has occurred.\n')
        raise ValueError(res.text)    


def getNoCatalogTermAssignedAssets(getDataAssetsURL, term_globalID_list, accessToken):

    headers = {
        'Content-Type': "application/json",
        'Authorization': "Bearer "+accessToken
    }

    payload={ 
        "query": {
            "bool": {
                "should": [
                    { "terms": {"entity.assets.column_term_global_ids": term_globalID_list}},
                    { "terms": {"metadata.term_global_ids": term_globalID_list }}
                ]
            }
        }
    }
    try:
        res=requests.post(getDataAssetsURL,json=payload,headers=headers,verify=False)
    except:
        logger.error("The below error has occurred. Please check that the parameters entered are correct.\n")
        print(res.text) 
        raise

    if res.status_code == 200:
        logger.info("Assigned Assets are retrieved successfully.\n")
        
        mapped_data_assets = [row for row in json.loads(res.text)['rows'] if row['metadata']['artifact_type'] in ['data_asset', 'data_asset_column'] and row['metadata']['term_global_ids'] and row['metadata']['term_global_ids'][0] in term_globalID_list and 'catalog_id' in row['entity']['assets']]

        df_term=pd.DataFrame(columns=['ColumnName','Business Term Name','Term ID', 'Route', 'Catalog ID'])

        # Get Asset IDs of the Data Assets retrieved
        for mapping in mapped_data_assets:
            try:
                colName = mapping['metadata']['name']
                catalog_id = mapping['entity']['assets']['catalog_id']
                dataAssetName = mapping['entity']['assets']['asset_name'] if mapping['metadata']['artifact_type'] == 'data_asset_column' else mapping['metadata']['name']
                for i, term in enumerate(mapping['metadata']['term_global_ids']):
                    term_global_id = term
                    bus_term = mapping['metadata']['terms'][i]   
                    df_term.loc[len(df_term.index)] = [colName, bus_term, term_global_id, dataAssetName, catalog_id]
            except:
                continue
        return df_term
            
    else:
        logger.error('The below error has occurred.\n')
        raise ValueError(res.text)    
   

def getTermAssignments(retrieveAssetURL, data_asset_dict, accessToken, catalog_id):

    # Each term from each asset in each catalog is formed into a dataframe here   
    headers = {
            'Content-Type': "application/json",
            'Authorization': "Bearer " + accessToken,
            'Cache-Control': "no-cache",
            'Connection': "keep-alive"
    }
    payload = {
                "query":"*:*",
                "limit":200
              }
    
    df_term_assignments=pd.DataFrame(columns=['ColumnName','Business Term Name','Artifact ID','Term ID', 'Category', 'Primary Category ID', 'Route', 'Catalog ID'])

    for data_asset_id, data_asset_name in data_asset_dict.items():

        logger.info("Getting Term Assignments for :  %s\n",data_asset_dict[data_asset_id])

        d=s.get(retrieveAssetURL+data_asset_id+"?catalog_id="+catalog_id, verify=False,json=payload,headers=headers)
        json_asset=json.loads(d.text)
        #print(json_asset)
        if 'column_info' in json_asset['entity']:
            for colName in json_asset['entity']['column_info'].keys():
                if 'column_terms' in json_asset['entity']['column_info'][colName]:
                    for term in json_asset['entity']['column_info'][colName]['column_terms']:
                        bus_term = term['term_display_name']
                        term_id = term['term_id']  
                        artifact_id = term_id.split('_')[1]
                        # Get Primary Categories of these terms
                        url = hostname +"/v3/glossary_terms/"+artifact_id+"/versions?include_relationship=all"
                        try:
                            res = s.get(url, headers= headers, verify=False)
                            primary_cat = json.loads(res.text)['resources'][0]['entity']['parent_category']['resources'][0]['entity']['parent_name']
                            primary_cat_id = json.loads(res.text)['resources'][0]['entity']['parent_category']['resources'][0]['entity']['parent_id']
                            
                            if bus_term not in df_term_assignments['Business Term Name'].values:
                                df_term_assignments.loc[len(df_term_assignments.index)] = [colName, bus_term, artifact_id, term_id, primary_cat, primary_cat_id,data_asset_name, catalog_id] 
                            else:
                                logger.debug('%s skipped as the term already exists.', bus_term) 
                        except:
                            logger.debug('%s skipped as the term does not exist.', bus_term) 
                            print(res.text)
                            continue
        else: 
            logger.info("No columns have any term mappings to the current asset.")

    return df_term_assignments

def createRootCategory(createRootCatURL, accessToken, RootCat):

    headers = {
            'Content-Type': "application/json",
            'Authorization': "Bearer " + accessToken
            
    }
    while True:
        payload = {
                "name" : RootCat,
                "long_description" : "IBM Knowledge Accelerator for Supplementary Vocabulary.\nCopyright IBM Corp. 2020, 2023."
        }
        d = s.post(createRootCatURL, headers=headers, json=payload, verify=False)
        if d.status_code == 409:
            RootCat = RootCat+str(1)
            logger.info("Root Category with current name exists, trying with new name : %s", RootCat)
    
        elif d.status_code == 201:
            
            
            print('Name : ', RootCat, '\nartifact id : ', json.loads(d.text)['resources'][0]['artifact_id'])
            logger.info("Root Category created with name : %s\n", RootCat)
            
            root_category_id = json.loads(d.text)['resources'][0]['artifact_id']
            return root_category_id, RootCat
            # Need to add logic for when its overlay then get details from the long description
            
    
        else:
            print(d.status_code)
            return
        
def getAllReferencedTerms_and_PrimaryCats(accessToken, input_cat_and_sub_cat_unique_list):

    new_terms=pd.DataFrame(columns=['Artifact ID','Business Term Name', 'Secondary Category', 'Category', 'Primary Category ID', 'Term ID'])
    url = hostname+"/v3/search"
    headers = {
        'Content-Type': "application/json",
        'Authorization': "Bearer "+accessToken

        }
    for j in input_cat_and_sub_cat_unique_list:
        payload={"size":2000,"from":0,"_source":
          ["artifact_id","metadata.artifact_type","metadata.name","metadata.description","categories", "entity.artifacts"],
          "query":{"bool":{"filter":{"bool":{"minimum_should_match":1,"should":
                                             [
                                                 {"term":{"categories.primary_category_id":j}},
                                                 {"term":{"categories.secondary_category_ids":j}},
                                             ],
                                             "must_not":{"terms":{"metadata.artifact_type":
                                                                  ["category", "reference_data"]}}}}}}}
        
        res=s.post(url,headers=headers,json=payload,verify=False)
        if res.status_code == 200:
            for i in json.loads(res.text)['rows']:                
                termName = i['metadata']['name']
                term_id = i['entity']['artifacts']['artifact_id']
                global_id = i['entity']['artifacts']['global_id']
                prim_catName = i['categories']['primary_category_name']
                prim_catID = i['categories']['primary_category_id']
                new_row = {'Business Term Name' : termName, 
                        'Artifact ID' :  term_id, 
                        'Secondary Category' : j, 
                        'Category' : prim_catName, 
                        'Primary Category ID' : prim_catID,
                        'Term ID' :  global_id
                        }
                if term_id not in new_terms['Artifact ID'].values:
                    new_terms.loc[len(new_terms)] = new_row
                else:
                    logger.debug('%s skipped of Category %s as the term already exists',termName, i['categories']['primary_category_name'])

        else:
            logger.error('The below error has occurred.\n %s', res.text)
    
    return new_terms

def assignTermsToAssets(assetsURL, accessToken, data_asset_dict, mapping_df, catalog_id):

    df_mapped_terms = pd.DataFrame(columns=['ColumnName','Business Term','Term ID', 'Route'])
    for data_asset_id, route_name in data_asset_dict.items():
        # Catalog asset id of the particular csvs
        # for each file name in the map_terms if the csv with this file name exists, get its asset_id from the catalog and use the post request publish create column_info attribute
        # This column info attribute is necessary to map the busines terms to column to header
        catalogInfoURL = assetsURL+data_asset_id+"/attributes?catalog_id="+catalog_id

        headers = {
        'Content-Type': "application/json",
        'Authorization': "Bearer "+accessToken
        }

        payload={
            "name": "column_info",
            "entity":{
                #"sample_size":50
            }
        }
        t=requests.post(catalogInfoURL,json=payload,headers=headers,verify=False)
        
        # For each column header in the file map its corresponding business term retrieved from the above join in the dataframe
        i=0
        part_mapping_df = mapping_df[mapping_df['Route'] == route_name]
        for index, rows in part_mapping_df.iterrows():
            i+=1
            logger.info("%s, %s is mapped to %s", i,rows.ColumnName.strip(), rows['Business Term'])
            # Create list for the current row 
            # Below payload is used for the patch request to map the header to business terms
            payload=[{"op":"add","path":"/"+rows.ColumnName.strip(),"value":{"column_terms":[{"term_display_name":rows['Business Term'],"term_id":rows["Term ID"]}]},"attribute":"column_info"}]
            
            try:
                url=assetsURL+data_asset_id+"/attributes/column_info?catalog_id="+catalog_id
                patch_attribute=s.patch(url,json=payload,headers=headers,verify=False)

                if patch_attribute.status_code in (200,202):
                    mt_json=json.loads(patch_attribute.text)
                    logger.debug("Term to Asset map has %s\n",str(patch_attribute.status_code))

                    df_mapped_terms.loc[len(df_mapped_terms.index)] = [rows['ColumnName'], rows['Business Term'],rows["Term ID"], rows['Route']]
                else:
                    logger.critical("Mapping of Business Terms failed.\n")
                    raise Exception(json.loads(patch_attribute.text)['errors'][0]['message'])
            except:
                logger.critical("The below error has occurred.\n")
                raise

    return df_mapped_terms