from distutils.core import setup
setup(name='telco_custom_transformer',
      version='1.0',
      py_modules=['telco_custom_transformer'],
      )
