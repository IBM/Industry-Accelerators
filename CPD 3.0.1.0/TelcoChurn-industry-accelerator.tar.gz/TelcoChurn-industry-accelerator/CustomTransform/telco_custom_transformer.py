

import pandas as pd
from dateutil import parser
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.preprocessing import LabelEncoder
from datetime import timedelta
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import make_pipeline, make_union
from sklearn.base import clone
from sklearn.preprocessing import LabelEncoder
import datetime
import sklearn



import warnings
warnings.filterwarnings('ignore')


from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score, accuracy_score, roc_curve, roc_auc_score

import numpy as np

import urllib3, requests, json, os



class AgeCalculator(BaseEstimator, TransformerMixin):
    """Takes a date column and calculates the age as of the current date.
    Accepts a column as the parameter."""
    
    def __init__(self, column):
        self.column = column
    
    def fit(self, X, y=None, **fit_params):
        return self
    
    def transform(self, X, **transform_params):
        today = datetime.datetime.today()
        age = X.apply(lambda x : abs(today.year - parser.parse(x).year) - ((today.month, today.day) < (parser.parse(x).month, parser.parse(x).day)))
        return pd.DataFrame(age)
        
        

class BusinessTermMapping(BaseEstimator, TransformerMixin):
    """Maps the specific business terms in a pandas column 
    into the specific codes and returns the dataframe.
    Accepts a column as the parameter."""
    
    def __init__(self, column):
        self.column = column
    
    def fit(self, X, y=None, **fit_params):
        return self
    
    def transform(self, X, **transform_params):
        mapped_column = X.replace({'No internet service' : 'NIS', 'No phone service' : 'NPS', 'Fiber optic' : 'Fiber',
                                  'Month-to-month' : 'M2M', 'One year' : '1Y', 'Two year' : '2Y', 
                                  'Credit card (automatic)' : 'Bank', 'Bank transfer (automatic)' : 'CC', 'Mailed check' : 'Mailed', 'Electronic check' : 'EFT'})
        return pd.DataFrame(mapped_column)
        
        
        

class MissingValues(BaseEstimator, TransformerMixin):
    """Replaces missing values with 0.
    Accepts a column as the parameter."""
    
    def __init__(self, column):
        self.column = column
    
    def fit(self, X, y=None, **fit_params):
        return self
    
    def transform(self, X, **transform_params):
        nanCol = X.fillna(0)
        return pd.DataFrame(nanCol)
