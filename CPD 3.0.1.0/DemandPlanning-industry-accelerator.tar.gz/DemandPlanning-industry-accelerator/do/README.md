This folder contains the DO model
