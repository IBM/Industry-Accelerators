
#------------------------------------------------------------------------------------------------------------------------------
# IMPORT LIBRARIES
#------------------------------------------------------------------------------------------------------------------------------

#
library(shiny)
library(ggplot2)
library(maps)
library(RColorBrewer)
library(data.table)

#------------------------------------------------------------------------------------------------------------------------------
# MAKE FUNCTIONS
#------------------------------------------------------------------------------------------------------------------------------

#

readDataset <- function(fileName) {read.csv(file.path(fileName)) }

#------------------------------------------------------------------------------------------------------------------------------
# LOAD DATA
#------------------------------------------------------------------------------------------------------------------------------

#
model_perf <- readDataset("buildmodels_performances.csv")

#
var_imp = readDataset("variables_importances.csv")
names(var_imp)

#
timevar = readDataset("timevariantresults.csv")

#
zipcode <- fread('https://gist.githubusercontent.com/erichurst/7882666/raw/5bdc46db47d9515269ab12ed6fb2850377fd869e/US%2520Zip%2520Codes%2520from%25202013%2520Government%2520Data')

#
weather = merge(var_imp, zipcode, by.x="postalcode", by.y="ZIP")

#------------------------------------------------------------------------------------------------------------------------------
# UPDATE DATA
#------------------------------------------------------------------------------------------------------------------------------

#
model_perf["postalcode"] = sprintf("%05d", as.numeric(model_perf$postalcode))
model_perf["placeId"] = sprintf("%05d", as.numeric(model_perf$placeId))

#
var_imp["postalcode"] = sprintf("%05d", as.numeric(var_imp$postalcode))
var_imp["placeId"] = sprintf("%05d", as.numeric(var_imp$placeId))

#
timevar["postalcode"] = sprintf("%05d", as.numeric(timevar$postalcode))
timevar["placeId"] = sprintf("%05d", as.numeric(timevar$placeId))

#
weather["postalcode"] = sprintf("%05d", as.numeric(weather$postalcode))
weather["placeId"] = sprintf("%05d", as.numeric(weather$placeId))
