# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# ÃÂ© Copyright IBM Corp. 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

## Buttons to click on, each button has name, product, last offer


homePanel <- function(){
  drop_choice=c(unique(weather$placeId))
  dropdown=c(names(timevar[12:33]))
  
  drop_choice=append("ALL", drop_choice)
  tabPanel(
    "Dashboard",
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 100% !important;
                      }
                      "))
    ),
    shinyjs::useShinyjs(),
    
    
    
    
    column(6, 
           
           panel(
             div(style="float:left", prettyRadioButtons("dropdiagInput", "Choose Location",
                                                       choices = drop_choice,
                                                       selected = drop_choice[1])),
             dateRangeInput('dateRange',
                            label = "Choose Date Range (yyyy-mm-dd)",
                            start = Sys.Date() - 730, end = Sys.Date() - 720
             ),
             div(style="float:left", selectInput("dropInput", "Choose Weather Variable",
                                                choices = dropdown,
                                                selected = dropdown[1])) ,
             #print(date_select),
             br(),
             #verbatimTextOutput("dateRangeText"),
             leafletOutput("LocationPlotly", width = "670px", height = "500px")
           ),
           panel(
             plotlyOutput("distribution",width = "auto", height = "300px")
           ),
           panel(
             plotlyOutput("density",width = "auto", height = "300px")
           )     
           
           
    ),
    
    column(6,
           panel(
             
             ##h4("Predictor Importance:", class="text-center"),
             
             hr(),
             plotlyOutput("feature",width = "auto", height = "400px")
           ),
           
           fluidRow(
             

             column(5, plotlyOutput("plot1", width="300px", height="auto")),
             
             column(5, plotlyOutput("plot2", width="300px", height="auto")) 
            
           ),
           panel(
             br(),
             
             plotlyOutput("AvsP2", width = "auto", height = "400px")
           ),
           panel(
             plotlyOutput("AvsP", width = "auto", height = "400px")
           )
           
    )
    

    
    
    
  )
  
  
}




a <- list(
  autotick = FALSE,
  ticks = "outside",
  tick0 = 0,
  dtick = 1,
  ticklen = 5,
  tickwidth = 2,
  tickcolor = toRGB("blue")
)




homeServer <- function(input, output, session, sessionVars) {
  
  observeEvent({input$dropdiagInput
    input$dateRange
  },{
    if(input$dropdiagInput=="ALL"){
      weather_f <- weather
      temp="X"
      timevar2=timevar
    } else {
      weather_f <- weather[weather$placeId==input$dropdiagInput,]
      temp=input$dropdiagInput
      timevar2=timevar[timevar$placeId==temp ,]
    }
    
    
    
    if (temp!="X") {
      weather_n=as.data.frame(t(weather[weather$placeId==temp,][5:32]))
      weather_n$Predictors=rownames(weather_n)
      names(weather_n)=c("Importance", "Predictors")
      weather_n=weather_n[order(weather_n$Importance),]
      weather_n=weather_n[weather_n$Importance>0,]
      
      
      timevar2=timevar2[as.Date(timevar2$date, "%Y-%m-%d")>=as.Date(input$dateRange[1], "%Y-%m-%d"),] 
      timevar2=timevar2[as.Date(timevar2$date, "%Y-%m-%d")<=as.Date(input$dateRange[2], "%Y-%m-%d"),]
      
      
      PrecipAmountLocalDaytimeAvg	=mean(timevar2$PrecipAmountLocalDaytimeAvg)
      UVIndexLocalDaytimeAvg	=mean(timevar2$UVIndexLocalDaytimeAvg)
      GustLocalDaytimeAvg	=mean(timevar2$GustLocalDaytimeAvg)
      PrecipAmountLocalEveningAvg	=mean(timevar2$PrecipAmountLocalEveningAvg)
      RelativeHumidityLocalDaytimeAvg	=mean(timevar2$RelativeHumidityLocalDaytimeAvg)
      VisibilityLocalDaytimeAvg	=mean(timevar2$VisibilityLocalDaytimeAvg)
      DewpointLocalMorningAvg	=mean(timevar2$DewpointLocalMorningAvg)
      FeelsLikeLocalDaytimeAvg	=mean(timevar2$FeelsLikeLocalDaytimeAvg)
      GustLocalMorningAvg	=mean(timevar2$GustLocalMorningAvg)
      PrecipAmountLocalDayAvg	=mean(timevar2$PrecipAmountLocalDayAvg)
      TemperatureLocalDaytimeAvg	=mean(timevar2$TemperatureLocalDaytimeAvg)
      WindSpeedLocalDaytimeAvg	=mean(timevar2$WindSpeedLocalDaytimeAvg)
      
      tot_sales=sum(timevar2$ytrue)
      
      names(timevar)
      
      map_title <- c(input$dropdiagInput)
      my_title <- tags$p(tags$style("p {color: blue; font-size:23px}"),
                         tags$b(map_title))
      
      icons <- awesomeIcons(
        icon = 'hospital-o',
        iconColor = 'red',
        library = 'fa',
        markerColor = "green"
      )
      
      LocPlot<-leaflet() %>%
        setView(lng = -90, lat = 35, zoom = 4)  %>%
        addTiles( group = "(default)") %>%  
        addAwesomeMarkers(lng=weather_f$LNG, lat=weather_f$LAT, popup = paste("Locale:", weather_f$placeId,"<br>Sales($):",tot_sales,"<br>Dew Point:",round(DewpointLocalMorningAvg,2),"<br>Feels Like:",round(FeelsLikeLocalDaytimeAvg,2),"<br>Gust Local",round(GustLocalDaytimeAvg,2),"<br>Precipitation",round(PrecipAmountLocalDayAvg,2),"<br>Relative Humidity",round(RelativeHumidityLocalDaytimeAvg,2),"<br>UV Index",round(RelativeHumidityLocalDaytimeAvg,2),"<br>Visibility Index",round(VisibilityLocalDaytimeAvg,2),"<br>Windspeed",round(WindSpeedLocalDaytimeAvg,2)),icon=icons, group="Hospitals")  %>%
        addControl(my_title, className="map-title", position = "bottomleft")
      
      ## Render plot 1
      output$LocationPlotly <- renderLeaflet(LocPlot)
      
      
      
      output$feature= renderPlotly({
        
        plot_ly(
          data = weather_n,
          x = ~Importance,
          y = ~Predictors,
          type = 'bar',
          marker = list(
            color = c(weather_n$Importance), 
            colorscale = "Viridis", 
            reversescale = TRUE
          ), 
          orientation = 'h'
        ) %>%
          layout(title=paste0("Predictor Importance: ", temp),
                 yaxis = list(
                   categoryorder = "array",
                   categoryarray = ~c("red", "green", "yellow", "blue") )
          )
        
      })
      
      
      rss <- sum((timevar2$ypredWith - timevar2$ytrue) ^ 2)  ## residual sum of squares
      tss <- sum((timevar2$ytrue - mean(timevar2$ytrue)) ^ 2)  ## total sum of squares
      rsq <- 1 - rss/tss
      
      mae=mean( abs(timevar2$ypredWith- timevar2$ytrue), na.rm = TRUE)
      di=input$dropInput
      output$AvsP =renderPlotly({
        
        p <- plot_ly(
          data=timevar2,
          type = "scatter",
          x =~date, 
          y =~ytrue, name = "ACTUAL",
          mode = "lines", colors = c("blue", "green", "red")) %>%
          add_trace( y =~ypredWith, name = "PREDICTED WITH", line = list(color = 'rgb(0, 255, 0)')) %>%
          add_trace( y =~ypredWithout, name = "PREDICTED WITHOUT", line = list(color = 'rgb(255, 0, 0)')) %>%
          layout(title = "Predicted vs Observed", xaxis = list(tickmode = "array", title = "Date"), yaxis = list(title = "Sales ($)"))
        
        p
      })
      output$AvsP2 =renderPlotly({
        b <- ggplot(timevar2, aes(x = ytrue, y = ypredWith)) +
          ggtitle("Predicted vs Observed") + labs(x = "Actual Sales ($)", y = "Predicted Sales ($)") +
          # Scatter plot with regression line
          geom_point()+
          geom_smooth(method = "lm") + annotate(geom="text", x=mean(timevar2$ytrue), y=mean(timevar2$ypredWith)/4, label=paste0("R^2=", round(rsq,2))) + annotate(geom="text", x=mean(timevar2$ytrue), y=mean(timevar2$ypredWith)/3, label=paste0("MAE=",round(mae,2)))
        
        ggplotly(b)
      })
      
      observeEvent( {input$dropInput},{
        t=input$dropInput[1]
        output$distribution =renderPlotly(({
          trace1 <- list(
            #title=paste0("Sales vs ",t),
            mode = "markers", 
            name = paste0("Sales vs ",t), 
            type = "scatter", 
            x = timevar2[,t],
            y = timevar2$ytrue
          )
          
          data <- list(trace1)
          p <- plot_ly()%>%
            layout(
              title = paste0("Sales vs ",t),
              xaxis = list(
                
                title = t
              ),
              yaxis = list(
                title = "Sales ($)"
                
              )
            )
          p <- add_trace(p, mode=trace1$mode, name=trace1$name, type=trace1$type, x=trace1$x, y=trace1$y,
                         hovertemplate = paste0(paste0("Sale: %{y}: <br>",t),": %{x}"))
          p
          
        }))
        timevar2$WeatherCondition=timevar2[,t]
        
        output$density=renderPlotly({
          c<-ggplot(timevar2,aes(x=WeatherCondition)) +
            ggtitle(paste0("Distribution of ",t)) + 
            geom_density(color="darkblue", fill="blue") + scale_x_continuous(name=t) 
          ggplotly(c)
        })
        
      })
      
    } else {
      
      
      output$feature = renderPlotly({
        
        
        
        t1=as.data.frame(t(weather[5:32]))
        
        names(t1)=c(weather$placeId)
        
        d <- plot_ly(
          x = c(names(t1)), y = c(rownames(t1)),
          z = as.matrix(t1), type = "heatmap", colorscale = "Viridis", colorbar = list(title = "Importance"), reversescale = TRUE
        )%>% 
          layout(title="Predictor Importance: all locations", 
                 yaxis = list(title = "Predictors"), 
                 xaxis = list(tickvals = c(names(t1)), title = "Locale", ticktext = c(names(t1))))
        
        d
        
      })
      output$AvsP= renderPlotly({})
      output$AvsP2= renderPlotly({})
      output$distribution= renderPlotly({})
      output$density = renderPlotly({})
      
      
      
      timevar2=timevar[as.Date(timevar$date, "%Y-%m-%d")>=as.Date(input$dateRange[1], "%Y-%m-%d"),] 
      timevar2=timevar2[as.Date(timevar2$date, "%Y-%m-%d")<=as.Date(input$dateRange[2], "%Y-%m-%d"),]
      
      
      
      sales_calc=as.data.frame(timevar2 %>%
                                 group_by(placeId) %>% summarise(sales = sum(ytrue)))
      
      weather_f=merge(weather_f,sales_calc,by="placeId")
      PrecipAmountLocalDaytimeAvg	=mean(timevar2$PrecipAmountLocalDaytimeAvg)
      UVIndexLocalDaytimeAvg	=mean(timevar2$UVIndexLocalDaytimeAvg)
      GustLocalDaytimeAvg	=mean(timevar2$GustLocalDaytimeAvg)
      PrecipAmountLocalEveningAvg	=mean(timevar2$PrecipAmountLocalEveningAvg)
      RelativeHumidityLocalDaytimeAvg	=mean(timevar2$RelativeHumidityLocalDaytimeAvg)
      VisibilityLocalDaytimeAvg	=mean(timevar2$VisibilityLocalDaytimeAvg)
      DewpointLocalMorningAvg	=mean(timevar2$DewpointLocalMorningAvg)
      FeelsLikeLocalDaytimeAvg	=mean(timevar2$FeelsLikeLocalDaytimeAvg)
      GustLocalMorningAvg	=mean(timevar2$GustLocalMorningAvg)
      PrecipAmountLocalDayAvg	=mean(timevar2$PrecipAmountLocalDayAvg)
      TemperatureLocalDaytimeAvg	=mean(timevar2$TemperatureLocalDaytimeAvg)
      WindSpeedLocalDaytimeAvg	=mean(timevar2$WindSpeedLocalDaytimeAvg)
      
      
      
      
      map_title <- c(input$dropdiagInput)
      my_title <- tags$p(tags$style("p {color: blue; font-size:23px}"),
                         tags$b(map_title))
      
      icons <- awesomeIcons(
        icon = 'hospital-o',
        iconColor = 'red',
        library = 'fa',
        markerColor = "green"
      )
      
      LocPlot<-leaflet() %>%
        setView(lng = -90, lat = 35, zoom = 4)  %>%
        addTiles( group = "(default)") %>%  
        addAwesomeMarkers(lng=weather_f$LNG, lat=weather_f$LAT, popup = paste("Locale:", weather_f$placeId,"<br>Sales($):",weather_f$ytrue,"<br>Dew Point:",round(DewpointLocalMorningAvg,2),"<br>Feels Like:",round(FeelsLikeLocalDaytimeAvg,2),"<br>Gust Local",round(GustLocalDaytimeAvg,2),"<br>Precipitation",round(PrecipAmountLocalDayAvg,2),"<br>Relative Humidity",round(RelativeHumidityLocalDaytimeAvg,2),"<br>UV Index",round(RelativeHumidityLocalDaytimeAvg,2),"<br>Visibility Index",round(VisibilityLocalDaytimeAvg,2),"<br>Windspeed",round(WindSpeedLocalDaytimeAvg,2)),icon=icons, group="Hospitals")  %>%
        addControl(my_title, className="map-title", position = "bottomleft")
      
      ## Render plot 1
      output$LocationPlotly <- renderLeaflet(LocPlot)
      
      
      
      
    }
    
    
    #ggplotly(ss)
    #observe event
    
    output$plot1 <- renderPlotly({ 
      if(input$dropdiagInput != "ALL")
      {
        data1 = filter(model_perf, placeId==input$dropdiagInput)  
      }
      else { data1 = model_perf }
      
      p1 <- plot_ly(y = -data1$test_neg_median_absolute_error, x = data1$approach, type = "box")
      ggplotly(p1)%>% 
        layout(title="Mean Absolute Error Test", yaxis=list(title="Sales ($)"), autosize=TRUE)
    })
    
    output$plot2 <- renderPlotly({ 
      if(input$dropdiagInput != "ALL")
      {
        data1 = filter(model_perf, placeId==input$dropdiagInput)  
      }
      else { data1 = model_perf }
      p2 <- plot_ly(y = -data1$train_neg_median_absolute_error, x = data1$approach, type = "box") 
      ggplotly(p2)%>% 
        layout(title="Mean Absolute Error Train", yaxis=list(title="Sales ($)"), autosize=TRUE)
    })
    
    
  })
  
  
  
  
}