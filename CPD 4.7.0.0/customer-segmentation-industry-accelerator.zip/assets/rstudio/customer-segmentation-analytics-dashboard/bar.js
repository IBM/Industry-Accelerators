
var diameter = 400, //max size of the bubbles

    format   = d3.format(",d"),
    color    = d3.scaleOrdinal(d3.schemeCategory10);
    //more color options: https://github.com/d3/d3-scale-chromatic

var bubble = d3.pack()
    .size([diameter, diameter])
    .padding(1.5);

var svg = d3.select("body")
    .append("svg")
    .attr("width", diameter)
    .attr("height", diameter)
    .attr("class", "bubble");
    
    



r2d3.onRender(function(data, svg, width, height, options) {

data = data.map(function(d){ d.value = +d["Count"]; return d; });

    //Sets up a hierarchy of data object
    var root = d3.hierarchy({children:data})
      .sum(function(d) { return d.value; })
      .sort(function(a, b) { return b.value - a.value; });

    //Once we have hierarchal data, run bubble generator
    bubble(root);

    //setup the chart
    var bubbles = svg.selectAll('.bubble')
        .data(root.children)
        .enter();//.append('.bubble')
        /**/
       
  
    //create the bubbles
    bubbles.append("circle")
        .attr("class", "circle")
        .attr("r", function(d){ return d.r; })
        .attr("cx", function(d){ return d.x; })
        .attr("cy", function(d){ return d.y; })
        .style("fill", function(d) { return color(d.value); })
        .attr("val", function(d) { return d.data["CLUSTERS"]; })
        .style("stroke", function() { return d3.select(this).attr("val") == 1 ? "black" : "none"})
        .style("stroke-width", function() { return d3.select(this).attr("val") == 1 ? "4px" : "0px"})
        .on('mouseover', function(){ d3.select(this).style("opacity", 0.5)})
        .on('mouseout', function(){d3.select(this).style("opacity", 1)})
        .on('click', function(){
     	    Shiny.setInputValue(
              "bar_clicked",
              d3.select(this).attr("val"),
              {priority: "event"}
            );
          d3.select(this.parentNode).selectAll("circle").style("stroke", "none");
        	d3.select(this).style("stroke", "black").style("stroke-width", "4px");
         })

    //format the text for each bubble
    bubbles.append("text")
        .attr("x", function(d){ return d.x; })
        .attr("y", function(d){ return d.y + 5; })
        .attr("text-anchor", "middle")
        .text(function(d){ return d.data["CLUSTERS"]; })
        .style("fill","white")
        .style("font-family", "Helvetica Neue, Helvetica, Arial, san-serif")
        .style("font-size", "16px");

   
  });
