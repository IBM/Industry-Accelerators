

homeTab <- function(){
  
  # First tab content
  tabItem(tabName = "home",
          shinyjs::useShinyjs(),
          #useShinydashboard(),

          
          ################# UI for the first home tab
          fluidRow(
            column(12, 
                   panel(
                     valueBoxOutput("numCustomers"),
                     valueBoxOutput("attritedCustomers"),
                     valueBoxOutput("percAttritedCustomers")
                   )
            )
          ),
          #h2("Summary View"),
          fluidRow(     box(     column(2,
                                    
                                    checkboxGroupInput("contract", "Customer Contract",
                                                       contractlist, selected=contractlist
                                    ),
                                    checkboxGroupInput("segment", "Customer Segment",
                                                       segmentlist, selected=segmentlist
                                    )),
    
          column(4,
          
           
          #h3("Select a Region")    , 
          h5("Click on a region to filter the results"),
          hidden(tags$div(id = "citybox",uiOutput("displayselectedcity")
                          )),
          leafletOutput("houseLocPlot",  height = "285px",width = "500px"),
          hidden(tags$div(id = "hiddenbox",
                         
                          actionButton("cities", "Select All Cities",  style='padding:2px; font-size:80%')

                          #prettyToggle(inputId = "cities",label_on = "",status_on = "default",icon_on = icon("ok-circle", lib = "glyphicon"),label_off = "Select All Cities",status_off = "default",icon_off = icon("ok-circle", lib = "glyphicon"),plain = TRUE,inline = TRUE)
                          ))
          )),

          box(title = "Attrition Risk",
          column(4,
                 
                     
                     plotOutput("pieattritionrisk", height="330px", width="550px")
                 
                 ))
          ),
          
          fluidRow(
            
            tabBox(
              title = "Attrition Risk ",
              id = "tabset1", height = "450",
              tabPanel("Attrition Rate Vs Customers Age Groups", plotOutput("agelineplot")), 
              tabPanel("Attrition Rate vs Tenure of the Customers", plotOutput("tenurelineplot"))
            ),
            tabBox(
              title = "High risk customers and Retention ",
              id = "tabset1", height = "450",
              tabPanel("High Risk Customers", dataTableOutput("customerData")), 
              tabPanel("Retention percentage vs Current Offer", plotlyOutput("currentofferplot"))
            )
          )
          
  )}
homeTabServer <- function(input, output, session, sessionVars){

  #markerclick <- reactiveValues(x = 10)
  cityval <- reactiveVal(levels(df_summary$CITY))
  
  observeEvent(input$houseLocPlot_marker_click,{
   shinyjs::show(id = "hiddenbox")
    shinyjs::show(id = "citybox")
  cityval(input$houseLocPlot_marker_click$id)
    
  }
  )
  
  observeEvent(input$cities,{
    shinyjs::hide(id = "hiddenbox")
    shinyjs::hide(id = "citybox")
    cityval(levels(df_summary$CITY))
    
  })
 # observeEvent(input$houseLocPlot_click,{
 #  # shinyjs::show(id = "hiddenbox")
 #   cityval(levels(df_summary$CITY))
 #   
 # }
 # )
 # 
 # toListen <- reactive({
 #   list(input$cities,input$segment,input$contract)
 # })
  observe( {
    selected_cities = cityval()
    df_filter = dplyr::filter(df_summary, (df_summary$CURRENT_CONTRACT %in% input$contract)&(df_summary$SEGMENT %in% input$segment)&(df_summary$CITY %in% selected_cities))
    
    df_latlong = df_latlong[df_latlong$City %in% selected_cities,]
    num_customers <- dim(df_filter)[1]
    output$numCustomers <- renderValueBox({
      
      shinydashboard::valueBox(
        tags$p(paste0(format(num_customers,big.mark = ',')), style = "font-size: 30px;"), 
        tags$p(" Clients Analyzed", style = "font-size: 15px;"),
        color = "aqua", width = 4, icon = icon("user")
      )
    })
    
    output$attritedCustomers <- renderValueBox({
      num_predicted_attrited <- sum(df_filter$predicted_class)
      
      shinydashboard::valueBox(
        tags$p(paste0(format(num_predicted_attrited,big.mark = ',')), style = "font-size: 30px;"), 
        tags$p(" Clients Predicted to Attrit", style = "font-size: 15px;"),
        color = "red", width = 4, icon = icon("walking")
      )
    })
    
    output$percAttritedCustomers <- renderValueBox({
      num_predicted_attrited <- sum(df_filter$predicted_class)
      perc_predicted_attrited <- round((num_predicted_attrited/num_customers)*100)
      shinydashboard::valueBox(
        tags$p(paste0(perc_predicted_attrited, "%"), style = "font-size: 30px;"), 
        tags$p(" Predicted Attrition Rate", style = "font-size: 15px;"),
        color = "red", width = 4, icon = icon("percent")
      )
    })
    
    output$displayselectedcity <- renderUI({
      tags$ul( class = 'list-unstyled',
               tags$li(
                 tags$strong('Selected City: '), tags$span(class = "pull-center", selected_cities[1])
               ))
      })
    output$houseLocPlot <- renderLeaflet({
      map <- leaflet(data = df_latlong) %>%
        setView(lat =  37.39562421,
                lng = -122.13496583,
                zoom = 10) %>%
        addTiles() 
      
      map <-  map%>%
        addMarkers(~lon, ~lat, popup=~City, layerId = ~City,group = "Select All Cities")  
      
      map
      
    })
    
    output$pieattritionrisk <- renderPlot({
      df_pie <- data.frame(df_filter %>% group_by(CHANCES) %>% count() %>%  ungroup() %>% 
                             mutate(percentage=`n`/sum(`n`)) %>% 
                             arrange(desc(n)))
      
      # Compute the cumulative percentages (top of each rectangle)
      df_pie$ymax = cumsum(df_pie$percentage)
      df_pie$label <- scales::percent(df_pie$percentage)
      df_pie$`Attrition Risk` <- df_pie$CHANCES
      # Hole size
      hsize <- 2
      
      df_pie <- df_pie %>% 
        mutate(x = hsize)
      
      ggplot(df_pie, aes(x = hsize, y = percentage, fill = `Attrition Risk`)) +
        geom_col() +
        geom_text(aes(label = label),
                  position = position_stack(vjust = 0.5)) +
        coord_polar(theta = "y") +
        xlim(c(0.2, hsize + 0.5)) + theme_void()+
        scale_fill_brewer(palette = "YlGnBu") +   theme(plot.background = element_rect(fill = "#ECF0F5"))
      
      
    })
    
    output$agelineplot <- renderPlot({
      df_employment <- data.frame(df_filter %>% group_by(AGE_GROUP,predicted_class) %>% count() %>%   ungroup() %>% 
                                    arrange(desc(n))) 
      
      df_employment <- data.frame(df_employment %>% group_by(AGE_GROUP) %>% mutate(percent = n/sum(n)))
      df_employment$percent = round(df_employment$percent*100,1)
      df_employment[df_employment$predicted_class==1,]$predicted_class="Yes"
      df_employment[df_employment$predicted_class==0,]$predicted_class="No"
      
      df_employment$Attrited=as.factor(df_employment$predicted_class)
      ggplot(df_employment[df_employment$Attrited=="Yes",], text=paste("Attrition Percentage:",percent))+
        #geom_bar(aes(y=n, x= age, fill = READMITTED),stat="identity")+
        geom_line(aes(x = AGE_GROUP, y = percent),stat="identity",size = 0.5, color="red", group = 1) +
        scale_fill_manual(values = c( "#3dbbff","#ff813d")) +
        labs(x = "Age Group", y = "Attrition Percentage") +theme_minimal() + theme(legend.position = 'top')
        #theme(axis.text.x = element_text(angle = 75, vjust = 0.5, hjust=1))
    })
    
    output$tenurelineplot <- renderPlot({
      df_employment <- data.frame(df_filter %>% group_by(TENURE,predicted_class) %>% count() %>%   ungroup() %>% 
                                    arrange(desc(n))) 
      
      df_employment <- data.frame(df_employment %>% group_by(TENURE) %>% mutate(percent = n/sum(n)))
      df_employment$percent = round(df_employment$percent*100,1)
      df_employment[df_employment$predicted_class==1,]$predicted_class="Yes"
      df_employment[df_employment$predicted_class==0,]$predicted_class="No"
      
      df_employment$Attrited=as.factor(df_employment$predicted_class)
      ggplot(df_employment[df_employment$Attrited=="Yes",], text=paste("Attrition Percentage:",percent))+
        #geom_bar(aes(y=n, x= age, fill = READMITTED),stat="identity")+
        geom_line(aes(x = TENURE, y = percent),stat="identity",size = 0.5, color="red", group = 1) +
        scale_fill_manual(values = c( "#3dbbff","#ff813d")) +
        labs(x = "Tenure (in months)", y = "Attrition Percentage") +theme_minimal() + theme(legend.position = 'top')
      #theme(axis.text.x = element_text(angle = 75, vjust = 0.5, hjust=1))
    })
    

  

    
output$currentofferplot <- renderPlotly({
  df_employment <- data.frame(df_filter %>% group_by(CURRENT_OFFER,predicted_class) %>% count() %>%   ungroup() %>% 
                                arrange(desc(n))) 
  
  df_employment <- data.frame(df_employment %>% group_by(CURRENT_OFFER) %>% mutate(percent = n/sum(n)))
  df_employment$percent = round(df_employment$percent*100,1)
  df_employment[df_employment$predicted_class==1,]$predicted_class="Yes"
  df_employment[df_employment$predicted_class==0,]$predicted_class="No"
  
  df_employment$Attrited=as.factor(df_employment$predicted_class)
 # ggplot(df_employment[df_employment$Attrited=="No",], text=paste("Attrition Percentage:",percent))+
 #   #geom_bar(aes(y=n, x= age, fill = READMITTED),stat="identity")+
 #   geom_line(aes(x = reorder(CURRENT_OFFER, percent), y = percent),stat="identity",size = 0.5, color="steelblue", group = 1) +
 #   scale_fill_manual(values = c( "#3dbbff","#ff813d")) +
 #   labs(x = "Current offer for the customer", y = "Retention Percentage") +theme_minimal() + theme(legend.position = 'top') +
 #   theme(axis.text.x = element_text(angle = 20, vjust = 0.5, hjust=1))
  
  g <- ggplot(aes(y=percent, x=reorder(CURRENT_OFFER, percent)), data = df_employment[df_employment$Attrited=="No",]
             ) +
    geom_bar(stat="identity", fill="steelblue",aes(text = paste("Number of Customers:",n,"<br>Current Offer:",CURRENT_OFFER,"<br> Percentage of Retention:",percent,"%"))) +
    labs(y = "Retention Percentage", x = "Current Offer") +theme_minimal() +
  theme(axis.text.x = element_text(angle = 20, vjust = 0.5, hjust=1))

  ggplotly(g, tooltip = "text")  %>% layout(legend = list(title=list(text='<b> Customer Retention </b>'),x = 0.8, y = 0.2))
})


output$customerData <- DT::renderDataTable({
df_filter <- df_summary
  df_filter$NAME <- paste(df_filter$FIRST_NAME,df_filter$LAST_NAME)
  df_filter$explain_binary=ifelse(df_filter$EXPLAIN=='no', 0, 1)
  df_filter=df_filter[with(df_filter, order(-explain_binary,-predicted_probability)), ]
  #df_filter=df_filter[with(df_filter, order(-predicted_probability)), ]
  filtered_df <- select(df_filter, "CUSTOMER_ID", "NAME",  "EMAIL","CHANCES")
  
  filtered_df
}, rownames = FALSE,colnames = c("Customer ID", "Customer Name","Customer Email","Attrition Risk" ), selection = 'single', options = list(pageLength = 7),server = FALSE, callback = JS("table.on('click.dt', 'tr', 
    function() {
           Shiny.onInputChange('customer_row',table.rows(this).data().toArray() );
    });"))

  })

observeEvent(input$customer_row, {
  
  selected_recordID <- input$customer_row[1]
  sessionVars$selectedClientId <- selected_recordID
  
  updateTabItems(session,"proNav", selected = "customer")
  # "proNav",
  
})
    
    
}