# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyrig ht IBM Corp. 2021 All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

# Load Data from CSV files
library(readr)
library(scales)

readDataset <- function(fileName) {read.csv(file.path(fileName))}

df_summary <- readDataset("data/model-output-summary.csv")

df_summary=df_summary[complete.cases(df_summary), ]
names(df_summary)

segmentlist <- levels(df_summary$SEGMENT)
contractlist <- levels(df_summary$CURRENT_CONTRACT)

df_latlong <- data.frame(City=c(levels(df_summary$CITY)),lat=c(37.3230,37.3861,37.4419,37.3541,37.3688)
                         ,lon=c(-122.0322,-122.0839,-122.1430,-121.9552,-122.0363))


df_summary$CHANCES="Medium"
df_summary[df_summary$predicted_probability<0.5,]$CHANCES="Low"
df_summary[df_summary$predicted_probability>0.75,]$CHANCES="High"



levels(df_summary$CURRENT_ISSUE)

labs <- c(paste(seq(10, 79, by = 10), seq(10 + 10, 90 - 1, by = 10),
                sep = "-"))

df_summary$AGE_GROUP <-  cut(df_summary$AGE, breaks = c(seq(10, 80, by = 10)), labels = labs, right = FALSE)


#### Explanation Results
df_lime<- readDataset("data/explanation-results.csv")

df_summary$EXPLAIN <- "no"
df_summary[df_summary$CUSTOMER_ID %in% df_lime$CUSTOMER_ID,]$EXPLAIN <- "yes"
