aboutTab <- function(){
  tabItem(tabName = "about",
          shinyjs::useShinyjs(),
          fluidRow(box(width = 12,
                       h3("About this accelerator", class="text-center"),
                       htmlOutput('about_text')
                       
          )
          
          ),
          
          
          fluidRow(
            box(
              h3("License"),
              
              htmlOutput('license_text'),
              br()),
            box(
              h5("For more Industry Accelerators visit, "),
              helpText(   a("Industry Accelerator Catalog ",href="https://community.ibm.com/accelerators/?context=analytics&type=Cloud%20Pak%20for%20Data%20industry",target="_blank")
              )))
          
          
          
  )
  
}

aboutTabServer <- function(input, output, session, sessionVars){
  
  output$about_text <- renderText({
    paste("<b>Utilities Customer Attrition dashboard<b/> includes various set of visualizations to understand risk of attrition in utilities customers<br> <b>Home tab</b> contains charts and tables to display low, medium and high risk risk patients. It also consists of visualizations to understand attrition risks in different types of customers. When clicked on a a customer in a data table, the dashboard navigates to Client View.<br> <b>Client View <b/> tab provides details for individual customers clicked in the home tab. Client view tab displays customers personal and retail information. This tab includes a button to predict attrition probability for the patient. Additionaly, this probability will be explained with a chart using Explanation button on the screen. ")
  })
  
  output$license_text <- renderText({
    paste("<b>This project contains Sample Materials, provided under license.<br>Licensed Materials - Property of IBM.<br>© Copyright IBM Corp.  2021. All Rights Reserved.<br>US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.")
  })
  
  
  #output$explanation<- re
  
  
}



