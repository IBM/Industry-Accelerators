clientTab <- function(){
  tabItem(tabName = "customer",
          shinyjs::useShinyjs(),
          tags$style(HTML("
                      .html-widget.gauge svg {
                        height: 400px;
                        width: 400px;
                      }
                     
                      ")),
          fluidRow(
            h3("Customer Details", class="text-center"),
            box(width = 4, uiOutput("clientInfo1")),
            box(width = 4,  uiOutput("clientInfo2")),
            box(width = 4, uiOutput("clientInfo3"))
           
          ),
          fluidRow(
            h3("Customers Retail Information", class="text-center"),
            box(width = 4, uiOutput("clientRetailInfo1")),
            box(width = 4,  uiOutput("clientRetailInfo2")),
            box(width = 4,  uiOutput("clientRetailInfo3"))
            
          ),
          fluidRow(
            h3("Customer Attrition Prediction", class="text-center"),
            box(width=6, 
                p(
                  htmlOutput('prediction_text'),
                  br(),
                  actionButton("prediction_button", "Predict Attrition", icon("paper-plane"), style="color: #fff; background-color: #222D31; border-color: #222D31"),
                  #column(width = 4, gaugeOutput("gauge")),
                ),
                hidden(tags$div(id = "attritionpredictionbox",
                                br(),
                                gaugeOutput("gauge",width=4),
                                br(),
                                br(),
                                br(),
                                br(),
                                htmlOutput('attritionresult_text'),
                                br()))
          
      
          ),
          hidden(tags$div(id = "explanationbox",
                          box(width=6,
                              
                              p(htmlOutput('explanation_text'),
                                br(),
                                actionButton("explanation_button", "Explanation", icon("paper-plane"), style="color: #fff; background-color: #222D31; border-color: #222D31")),  
                              plotOutput("explain_plot"),
                              htmlOutput('explanation_text2')
                          )))
          )
          
          
  )}

clientTabServer <- function(input, output, session, sessionVars){
  observeEvent(sessionVars$selectedClientId,{
    shinyjs::hide(id = "attritionpredictionbox")
    
    shinyjs::hide(id="explanation_button")
    shinyjs::hide(id="explanation_text")
    shinyjs::hide(id="explanation_text2")
    shinyjs::hide(id="explain_plot")
    shinyjs::hide(id="explanationbox")
    
    i_customer_id = sessionVars$selectedClientId
    df_unseen = df_summary
    client_name <- paste(df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "FIRST_NAME"],df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "LAST_NAME"])
    client_id <- i_customer_id
    client_age <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "AGE"]
    client_segment <- str_to_title(df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "SEGMENT"])
    client_city <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "CITY"] 
    client_phone <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "PHONE_1"] 
    client_email <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "EMAIL"]
    client_gender <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "GENDER_ID"]
    
    client_employment <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "EMPLOYMENT"] 
    client_marital <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "MARITAL_STATUS"] 
    client_education <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "EDUCATION"] 
    client_tenure <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "TENURE"] 
    client_complaints <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "COMPLAINTS"] 
    client_complaints<- gsub(1, "Yes", client_complaints)
    client_complaints<- gsub(0, "No", client_complaints)
    client_energy_usage <- round(df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "ENERGY_USAGE_PER_MONTH"])
    client_energy_efficiency <- round(df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "ENERGY_EFFICIENCY"], 2)
    
    client_energy_usage <- round(df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "ENERGY_USAGE_PER_MONTH"])
    client_energy_efficiency <- round(df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "ENERGY_EFFICIENCY"], 2)
    client_contract <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "CURRENT_CONTRACT"] 
    client_issue <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "CURRENT_ISSUE"] 
    client_offer <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "CURRENT_OFFER"]
    
    client_home_owner <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "OWNS_HOME"]
    client_home_owner<- gsub(1, "Yes", client_home_owner)
    client_home_owner<- gsub(0, "No", client_home_owner)
    client_has_thermostat <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "HAS_THERMOSTAT"]
    client_has_thermostat<- gsub(1, "Yes", client_has_thermostat)
    client_has_thermostat<- gsub(0, "No", client_has_thermostat)               
    client_has_home_automation <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "HAS_HOME_AUTOMATION"]
    client_has_home_automation<- gsub(1, "Yes", client_has_home_automation)
    client_has_home_automation<- gsub(0, "No", client_has_home_automation)               
    client_smart_meter_comments <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "SMART_METER_COMMENTS"]
    client_car_owner <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "IS_CAR_OWNER"]
    client_car_owner<- gsub(1, "Yes", client_car_owner)
    client_car_owner<- gsub(0, "No", client_car_owner)     
    client_has_ev <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "HAS_EV"]
    client_has_ev<- gsub(1, "Yes", client_has_ev)
    client_has_ev<- gsub(0, "No", client_has_ev) 
    
    
    # if the customer has an electric vehicle they must be a car owner
    if (client_has_ev==1) {
      client_car_owner <- "Yes"
    }
    
    if (client_car_owner==0) {
      client_has_ev <- "NA"
    }
    
    client_pv_zoning <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "PV_ZONING"]
    client_pv_zoning<- gsub(1, "Yes", client_pv_zoning)
    client_pv_zoning<- gsub(0, "No", client_pv_zoning)               
    client_has_pv <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "HAS_PV"]
    client_has_pv<- gsub(1, "Yes", client_has_pv)
    client_has_pv<- gsub(0, "No", client_has_pv)               
    client_wind_zoning <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "WIND_ZONING"]
    client_wind_zoning<- gsub(1, "Yes", client_wind_zoning)
    client_wind_zoning<- gsub(0, "No", client_wind_zoning)               
    client_has_wind <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "HAS_WIND"]
    client_has_wind<- gsub(1, "Yes", client_has_wind)
    client_has_wind<- gsub(0, "No", client_has_wind)               
    client_car_owner <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "IS_CAR_OWNER"]
    client_car_owner<- gsub(1, "Yes", client_car_owner)
    client_car_owner<- gsub(0, "No", client_car_owner)               
    client_has_ev <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "HAS_EV"]
    client_has_ev<- gsub(1, "Yes", client_has_ev)
    client_has_ev<- gsub(0, "No", client_has_ev)     
   
    client_has_ebill <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "EBILL"]
    client_has_ebill<- gsub(1, "Yes", client_has_ebill)
    client_has_ebill<- gsub(0, "No", client_has_ebill)     
    
    # if the customer has an electric vehicle they must be a car owner
    if (client_has_ev==1) {
      client_car_owner <- "Yes"
    }
    if (client_car_owner==0) {
      client_has_ev <- "NA"
    }
    
  output$clientInfo1 <- renderUI({
    tags$ul( class = 'list-unstyled',
             tags$li(
               tags$strong('Name: '), tags$span(class = "pull-right", client_name)
             ),
             tags$li(
               tags$strong('ID: '), tags$span(class = "pull-right", client_id)
             ),
             tags$li(
               tags$strong('Gender: '), tags$span(class = "pull-right", client_gender)
             ),
             tags$li(
               tags$strong('Phone: '), tags$span(class = "pull-right", client_phone)
             ),
             tags$li(
               tags$strong('Email Address: '), tags$span(class = "pull-right", client_email)
             )
    )
  })
  
  output$clientInfo2 <- renderUI({

    tags$ul( class = 'list-unstyled',
            
             tags$li(
               tags$strong('Age: '),tags$span(class = "pull-right", client_age)
             ),
            
             tags$li(
               tags$strong('City: '), tags$span(class = "pull-right", client_city)
             ),

             tags$li(
               tags$strong('Employment Status: '), tags$span(class = "pull-right", client_employment)
             ),
             tags$li(
               tags$strong('Education: '), tags$span(class = "pull-right", client_education)
             ),
             tags$li(
               tags$strong('Marital Status: '), tags$span(class = "pull-right", client_marital)
             )
    )
  })
  
  output$clientInfo3 <- renderUI({
    

    tags$ul( class = 'list-unstyled',
             
             tags$li(
               tags$strong('Segment: '), tags$span(class = "pull-right", client_segment)
             ),
           
             tags$li(
               tags$strong('Tenure: '), tags$span(class = "pull-right", client_tenure, " Months")
             ),
             tags$li(
               tags$strong('Average Monthly Energy Usage: '), tags$span(class = "pull-right", client_energy_usage, "KWh")
             ),
             tags$li(
               tags$strong('Energy Efficiency: '), tags$span(class = "pull-right", client_energy_efficiency)
             ),
             
             tags$li(
               tags$strong('Previously Made Complaint: '),tags$span(class = "pull-right", client_complaints)
             )
             
    )
  })
  


  
  output$clientRetailInfo1 <- renderUI({
    

    tags$ul( class = 'list-unstyled',
             tags$li(
               tags$strong('Current Contract: '), tags$span(class = "pull-right", client_contract)
             ),
             tags$li(
               tags$strong('Current Offer: '), tags$span(class = "pull-right", client_offer)
             ),
             tags$li(
               tags$strong('Current Issue: '), tags$span(class = "pull-right", client_issue)
             ),
             tags$li(
               tags$strong('Home Owner: '), tags$span(class = "pull-right", client_home_owner)
             ),
             tags$li(
               tags$strong('   ')
             ),
             tags$li(
               tags$strong('Owns Vehicle: '), tags$span(class = "pull-right", client_car_owner)
             )
    )
  })
  
  output$clientRetailInfo3 <- renderUI({
    tags$ul( class = 'list-unstyled',
    tags$li(
      tags$strong('Smart Meter Comments: '),tags$span(class = "pull-right", client_smart_meter_comments)
    ),
    tags$li(
      tags$strong('Thermostat Installed: '), tags$span(class = "pull-right", client_has_thermostat)
    ),
    tags$li(
      tags$strong('    ')
    ),
    tags$li(
      tags$strong('Home Automation: '), tags$span(class = "pull-right", client_has_home_automation)
    ),
    tags$li(
      tags$strong('Subscribed to Electronic Bill: '), tags$span(class = "pull-right", client_has_ebill)
    )
    
  
    )
  })
  
  output$clientRetailInfo2 <- renderUI({
    tags$ul( class = 'list-unstyled',
             
             tags$li(
               tags$strong('Vehicle is Electric: '), tags$span(class = "pull-right", client_has_ev)
             ),
             tags$li(
               tags$strong('Wind Zoned: '), tags$span(class = "pull-right", client_wind_zoning)
             ),
             tags$li(
               tags$strong('Has Wind Energy: '),tags$span(class = "pull-right", client_has_wind)
             ),
             tags$li(
               tags$strong('    ')
             ),
             tags$li(
               tags$strong('PV Zoned: '), tags$span(class = "pull-right", client_pv_zoning)
             ),
             tags$li(
               tags$strong('Has PV Energy: '), tags$span(class = "pull-right", client_has_pv)
             )
    )
    
    
  })    
  output$usageyear <- renderPlot({

    df_plot=df_unseen[df_unseen$CUSTOMER_ID==i_customer_id,]
    usagecols=c( "STD_YRLY_USAGE_CUR_YEAR_MINUS_5","STD_YRLY_USAGE_CUR_YEAR_MINUS_4","STD_YRLY_USAGE_CUR_YEAR_MINUS_3","STD_YRLY_USAGE_CUR_YEAR_MINUS_2","STD_YRLY_USAGE_CUR_YEAR_MINUS_1")
    df_plot=df_plot[usagecols]
    df_plot=as.data.frame(t(as.data.frame(df_plot)))
    
    names(df_plot)="USAGE"
    Usage=c(df_plot$USAGE)
    year=c( "CURRENT_YEAR-5","CURRENT_YEAR-4","CURRENT_YEAR-3","CURRENT_YEAR-2","CURRENT_YEAR-1")
    df_year=data.frame(Usage,year)
    
    levels(df_year$year)=c( "CURRENT_YEAR-5","CURRENT_YEAR-4","CURRENT_YEAR-3","CURRENT_YEAR-2","CURRENT_YEAR-1")
    
    
    p<-
      ggplot(data=df_year, aes(x=year,y=Usage,group=1)) +
      geom_bar(data=df_year, aes(x=year,y=Usage),stat="identity",width=0.55, fill="steelblue") +
      geom_line(stat="identity") +geom_point() + theme(axis.text.x = element_text(angle = 90))+
      ylab("Usage in Kwh")
    p
  })
  
 
  
  })
  
  observeEvent(input$prediction_button,{
    shinyjs::show(id = "explanationbox")
    #shinyjs::show(id = "predictionresult_text")
    shinyjs::hide(id="explain_plot")
    
    shinyjs::show(id = "attritionpredictionbox")
    #shinyjs::show(id = "gauge")
    shinyjs::show(id = "AttritionRisk")
    
    
    i_customer_id = sessionVars$selectedClientId
    
    df_customer <- df_summary[df_summary$CUSTOMER_ID==i_customer_id,]
    df_customer$NAME <- paste(df_customer$FIRST_NAME,df_customer$LAST_NAME)
    pat_name <- df_customer$NAME
    predicted_prob=df_customer$predicted_probability*100
    predicted_prob=round(predicted_prob,1)
    output$gauge = renderGauge({
      gauge(predicted_prob, 
            symbol = '%',
            min = 0, 
            max = 100,  
            sectors = gaugeSectors(success = c(0, 10),
                                   warning = c(10, 50),
                                   danger = c(50, 100)), label = "Probability")
    })
    if(as.character(df_customer$CHANCES)=="Low"){
      licon="clipboard-check"
      lcolor="green"
    } else if(as.character(df_customer$CHANCES)=="Medium"){
      licon="th"
      lcolor="orange"
    }else{
      licon="exclamation-circle"
      lcolor="red"
    }
    output$AttritionRisk <- renderValueBox({
      
      shinydashboard::valueBox( as.character(df_customer$CHANCES),"Attrition Risk", icon = icon(licon), color =lcolor)
    })
    
    output$attritionresult_text <- renderText({
      
      paste(pat_name,"is predicted to be",as.character(df_customer$CHANCES),"attrition risk with a probability of",paste0(predicted_prob,"%"))
    })
    
    if(df_customer$EXPLAIN=="yes"){
      shinyjs::show(id="explanation_text")
      shinyjs::hide(id="explanation_text2")
      shinyjs::show(id="explanation_button")
      shinyjs::hide(id="explain_plot")
    } })
  
  observeEvent(input$explanation_button,{
    
    selectedcustnbr <- sessionVars$selectedClientId
  
    df_customer <- df_summary[df_summary$CUSTOMER_ID==selectedcustnbr,]
    df_customer$NAME <- paste(df_customer$FIRST_NAME,df_customer$LAST_NAME)
    
    shinyjs::show(id="explain_plot")
    shinyjs::show(id="explanation_text2")
    
    output$explain_plot <- renderPlot({
      
      df_explain = df_lime[df_lime$CUSTOMER_ID==selectedcustnbr,]
      df_explain$LIME_Features=droplevels(df_explain$LIME_Features)
      limefeatures=as.character(df_explain$LIME_Features)
      features=gsub('/"', "", gsub("[()]", "", as.list(unlist(strsplit(gsub("[][]", "", limefeatures), '), ')))))
      df_features=as.data.frame(features)
      df_feature_explain=data.frame(do.call("rbind", strsplit(as.character(df_features$features), "',")))
      
      names(df_feature_explain)=c("feature","weights")
      df_feature_explain$Impact_for_Prediction= ifelse(as.numeric(as.character(df_feature_explain$weights)) > 0,"Positive", "Negative")
      df_feature_explain$feature=gsub("'","",df_feature_explain$feature)
      df_feature_explain$weights = as.numeric(as.character(df_feature_explain$weights))
      df_feature_explain=df_feature_explain[order(df_feature_explain$weights),]
      df_feature_explain$feature=str_to_title(df_feature_explain$feature)
      
      ggplot(df_feature_explain, aes(x=factor(stringr::str_wrap(df_feature_explain$feature, 70), levels = df_feature_explain$feature), y=weights, label=weights),text = paste("Feature Name:",feature)) +
        geom_bar(stat='identity', aes(fill=Impact_for_Prediction), width=.5) +
        scale_fill_manual(name="Impact",
                          labels = c("Negative", "Positive"),
                          values = c("#e5bcf7","#7f00ba")) +
        labs(title= "Feature Importance") + xlab("Features")+ ylab("Importance") +
        theme(legend.position="bottom")+
        coord_flip() 
      
      #ggplotly(g, tooltip = "text") 
      
      
    })
    
  })
}