Filter_df <- FINAL_DF[!FINAL_DF$PropertyId %in% c(6741,6742),]
f1=Filter_df[Filter_df$MapZone=="Zone 1",]
outline1 <- f1[chull(f1$lon, f1$lat),]

f2=Filter_df[Filter_df$MapZone=="Zone 2",]
outline2 <- f2[chull(f2$lon, f2$lat),]

f3=Filter_df[Filter_df$MapZone=="Zone 3",]
outline3 <- f3[chull(f3$lon, f3$lat),]

f4=Filter_df[Filter_df$MapZone=="Zone 4",]
outline4 <- f4[chull(f4$lon, f4$lat),]

f5=Filter_df[Filter_df$MapZone=="Zone 5",]
outline5 <- f5[chull(f5$lon, f5$lat),]

f6=Filter_df[Filter_df$MapZone=="Zone 6",]
outline6 <- f6[chull(f6$lon, f6$lat),]

# f0=Filter_df[Filter_df$Zone=="Zone 0",]
# outline0 <- f0[chull(f0$lon, f0$lat),]
# 
#
f7=Filter_df[Filter_df$Zone!="No Zone",]
# outline7 <- f7[chull(f7$lon, f7$lat),]
f8=Filter_df[Filter_df$Zone=="No Zone",]






bins <- c(0,0.2,0.4,0.6,0.8,1)
pal <- colorNumeric(c("steelblue","orange", "red"),domain = FINAL_DF$value)


map <- leaflet(data = Filter_df) %>%
  setView(lat =  29.79562421,
          lng = -93.23496583,
          zoom = 11) %>%
  
  addTiles() %>%
  
 # addCircles(data = f8,~lon, ~lat, ~20,  group = "Impact Level",color="steelblue",popup = ~paste("Impact Score:",as.character(value))) %>%
  addCircles(data = Filter_df,~lon, ~lat, ~20,  group = "Impact Level",color=~pal(value),layerId = ~PropertyId,popup = ~paste("Impact Score:",as.character(value)) ) %>%
  addPolygons(data = outline1, lng = ~lon, lat = ~lat,
              fillColor = ~pal(mean(f1$value)), weight = 2, color = ~pal(mean(f1$value)), group = "Impact Regions",layerId = ~MapZone, opacity = 0.9,label = "Zone 1", highlight = highlightOptions(weight = 3,bringToFront = TRUE,sendToBack = TRUE)) %>%
  addPolygons(data = outline2, lng = ~lon, lat = ~lat,
              fillColor = ~pal(mean(f2$value)), weight = 2, color = ~pal(mean(f2$value)), group = "Impact Regions",layerId = ~MapZone, opacity = 0.9,label = "Zone 2", highlight = highlightOptions(weight = 3,bringToFront = TRUE,sendToBack = TRUE)) %>%
  addPolygons(data = outline3, lng = ~lon, lat = ~lat,
              fillColor = ~pal(mean(f3$value)), weight = 2, color = ~pal(mean(f3$value)), group = "Impact Regions",layerId = ~MapZone, opacity = 0.9,label = "Zone 3", highlight = highlightOptions(weight = 3,bringToFront = TRUE,sendToBack = TRUE)) %>%
  addPolygons(data = outline4, lng = ~lon, lat = ~lat,
              fillColor = ~pal(mean(f4$value)), weight = 2, color = ~pal(mean(f4$value)), group = "Impact Regions",layerId = ~MapZone, opacity = 0.9,label = "Zone 4", highlight = highlightOptions(weight = 3,bringToFront = TRUE,sendToBack = TRUE)) %>%
  addPolygons(data = outline5, lng = ~lon, lat = ~lat,
              fillColor = ~pal(mean(f5$value)), weight = 2, color = ~pal(mean(f5$value)), group = "Impact Regions",layerId = ~MapZone, opacity = 0.9,label = "Zone 5", highlight = highlightOptions(weight = 3,bringToFront = TRUE,sendToBack = TRUE)) %>%
  addPolygons(data = outline6, lng = ~lon, lat = ~lat,
              fillColor = ~pal(mean(f6$value)), weight = 2, color = ~pal(mean(f6$value)), group = "Impact Regions",layerId = ~MapZone, opacity = 0.9,label = "Zone 6", highlight = highlightOptions(weight = 3,bringToFront = TRUE,sendToBack = TRUE)) %>%
  
  addPolygons(data = md1, lng = ~lon, lat = ~lat, color = "red", weight = 0.25, layerId = "outer1",
              smoothFactor = 0.5,opacity = 0.5, fillOpacity = 0.1,group = "Coastal Impact ")%>%
  addPolygons(data = md2, lng = ~lon, lat = ~lat, color = "green", weight = 0.25, layerId = "outer2",
              smoothFactor = 0.5,opacity = 0.5, fillOpacity = 0.1,group = "Coastal Impact ")%>%
  addPolygons(data = md3, lng = ~lon, lat = ~lat, color = "orange", weight = 0.25, layerId = "outer3",
              smoothFactor = 0.5,opacity = 0.5, fillOpacity = 0.1,group = "Coastal Impact ")%>%
  addPolygons(data = md4, lng = ~lon, lat = ~lat, color = "green", weight = 0.25, layerId = "outer4",
              smoothFactor = 0.5,opacity = 0.5, fillOpacity = 0.1,group = "Coastal Impact ")%>%
  addLegend(pal = pal, values = ~value, opacity = 0.5, title = "Impact Level",
            position = "bottomright",group = "Impact Regions")%>%
  #addMarkers(~lon, ~lat, clusterOptions = markerClusterOptions(),icon =  icons, popup = ~paste("Property id:",as.character(house_id),"<br>Impact Score:",as.character(value),"<br>Property Value:",as.character(Property.Value.new),"$","<br>Insurance Claim:",as.character(Insurance_Claim_Amount),"$"), label = ~paste("House ID:",as.character(house_id)), 
  #           group = "Property Clusters",  labelOptions = labelOptions(noHide = T,opacity = 0.7))%>%
  addLayersControl(
    baseGroups = c("Impact Regions","Impact Level","Property Clusters"),
    overlayGroups = c("Coastal Impact "),
    options = layersControlOptions(collapsed = FALSE)
  ) 
map





Filter_df2=FINAL_DF

FINAL_DF$severity <- ifelse(FINAL_DF$value>0.5, "High", "Medium")
FINAL_DF$severity <- ifelse(FINAL_DF$value<0.3, "Low", FINAL_DF$severity)


Filter_df2$Percentage_of_Claim_amount <- Filter_df2$Estimated.Claim.amount/Filter_df2$Claim_amount*100
Filter_df2$Property_Damage_Amount = round(Filter_df2$Property_Damage_Amount,0)


  