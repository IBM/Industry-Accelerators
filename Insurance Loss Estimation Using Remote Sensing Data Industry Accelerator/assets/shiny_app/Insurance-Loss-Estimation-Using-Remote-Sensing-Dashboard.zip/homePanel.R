library(DT)


homePanel <- function() {
  # Put diagnosis code into a vector
  

  # creates a tab
  tabPanel(
    
    
    
    "Remote sensing",
    value = "homePanel",tags$head(
      tags$style(type = "text/css", "html, body {width:100%; height:100%}")
     
     
    ),

    
    panel(      setBackgroundColor(
      color = c("#F7FBFF", "#2171B5"),
      gradient = "linear",
      direction = "bottom"
    ),
    
    
    
    # header for the map
    h2("Insurance Loss Estimation Using Remote Sensing Data", class="text-center"),
    shinyjs::useShinyjs(),
    useShinydashboard(),
    
    
    fluidPage(
    fluidRow(panel(
      
      #
      
      
      #First Panel
      div(id = "mapinfo",
          column(8,
                 
                 br(),
                 
                 column(2,
                        
                        
                        checkboxGroupInput("buildingtypeInput", "Choose Property Type(s):",
                                           choices = as.character(unique(FINAL_DF$PropertyType)),
                                           selected = as.character(unique(FINAL_DF$PropertyType)),
                        ),
                        sliderInput("damagelevel", "Select Impact Score Range", min = 0, 
                                    max = 1, value = c(0, 1)),
                        br(),
                        br(),
                        br(),
                        valueBoxOutput("zoneselection"),
                        br(),
                        valueBoxOutput("numhouses"),
                        br(),
                        valueBoxOutput("numimpactedproperties"),
                        br(),
                        valueBoxOutput("averagedamege"),
                        
                        br(),
                        valueBoxOutput("averagepropertyvalue")
                 ),
                 
                 column(6,
                        leafletOutput("houseLocPlot", width = "850px", height = "550px"),
                        br(),
                        br(),
                        DTOutput('featuretable',width = "850px"))
                 
          ) ),
      
      #First Panel
      div( id = "generalinfo",
           column(4,
                  h4("Remote Sensing Satellite Images", class="text-center"),
                  radioButtons("selectimage","Before/After the Storm Event",choices=c("Before Event","After Event"),
                               selected= "Before Event", inline = TRUE, ),
                  uiOutput('afterevent_image'),
                  tags$style('div#afterevent_image:hover {
                  transform: scale(1.5);
                  transform-origin: top left;
                  }'),
                  br(),
                  br(),
                  br(),
                  plotOutput("pieInsurance", height="350px", width="450px"),
                  br(),
                  br(),
                  plotOutput('damagelevelsnhouses', height="350px", width="450px")
                  
                  
           ))
      
    )) )
    
    
    # End of Div
    
    
    
    
    )
    
  ) 
  #tabpanel
}






# Reactive server variables store (pervades across all sessions)
#serverVariables = reactiveValues(deployments = list())

homeServer <- function(input, output, session, sessionVars) {
  
  observeEvent(input$selectimage,{
    
    print(input$selectimage)
    if(input$selectimage=="Before Event"){
      src_img = 'profiles/event_before-min.png'
    }else{
      src_img = 'profiles/event_after-min.png'
      
    }
    
    output$afterevent_image <- renderUI({
      tags$img(src =  src_img, width = 400, align = "center")
    })
    
  } )
  
  
  
  
  proxy = dataTableProxy('featuretable')
  
  
  
  
  
  #print(input$houseLocPlot_marker_click)
  
  observe({
    
    
    
    
    
    selected_building <- input$buildingtypeInput
    
    selected_damagelevel <- input$damagelevel
    
    
    Filter_df <- dplyr::filter(FINAL_DF, (FINAL_DF$PropertyType %in% selected_building)& (FINAL_DF$value>=selected_damagelevel[1]) & (FINAL_DF$value<=selected_damagelevel[2]))
    Filter_df1 <- Filter_df
    displaytext="All"
    shapeclick <- input$houseLocPlot_shape_click
    print(shapeclick)
    print(input$houseLocPlot_click)
    if ((!is.null(shapeclick))&(!is.null(input$houseLocPlot_click))){
      if (paste(input$houseLocPlot_shape_click$lat,input$houseLocPlot_shape_click$lng)==paste(input$houseLocPlot_click$lat,input$houseLocPlot_click$lng)){
        
        Filter_df1 <- Filter_df[Filter_df$MapZone==shapeclick$id,] 
        displaytext=shapeclick$id 
        
        
      }
    } 
    

    
    if(nrow(Filter_df1)==0){
      Filter_df1=Filter_df
      displaytext="All"
    }
    #print(paste(input$houseLocPlot_shape_click$lat,input$houseLocPlot_shape_click$lng))
    #
    #print(paste(input$houseLocPlot_click$lat,input$houseLocPlot_click$lng))
    
    
    
    
    output$numhouses <- renderValueBox({
      
      shinydashboard::valueBox(
        p("No. of Properties", style = "font-size: 15px; text-align: center;"),
        p(paste0(format(nrow(Filter_df1),big.mark = ',')), style = "font-size: 30px; text-align: center;"), 
        color = "light-blue", width = 25
      )
    })
    

    impacted_df <- Filter_df1[Filter_df1$Impact_Score>0,]
    
    output$numimpactedproperties <- renderValueBox({
      
      shinydashboard::valueBox(
        p("Impacted Properties", style = "font-size: 15px; text-align: center;"),
        p(paste0(format(nrow(impacted_df),big.mark = ',')), style = "font-size: 30px; text-align: center;"), 
        color = "light-blue", width = 25
      )
    })
    
    
    
    mean_damage_score <- round(mean(Filter_df1$value),2)
    print(mean_damage_score)
    if(mean_damage_score>0.65){
      boxclour="red"
    }else if(mean_damage_score<0.4){
      boxclour="green"
    } else{
      boxclour="orange"
    }
    
    output$zoneselection <- renderValueBox({
      shinydashboard::valueBox(
        p("Selected Impact Zone", style = "font-size: 14px; text-align: center;"),
        p(displaytext, style = "font-size: 30px; text-align: center;"), 
        color = boxclour, width = 25
      )
    })
    
    output$averagedamege <- renderValueBox({
      shinydashboard::valueBox(
        p("Avg. Impact Score", style = "font-size: 15px; text-align: center;"),
        p(paste0(format(mean_damage_score,big.mark = ',')), style = "font-size: 30px; text-align: center;"), 
        color = boxclour, width = 25
      )
    })
    
    mean_property_value <- round(mean(Filter_df1$Property.Value),2)
    output$averagepropertyvalue <- renderValueBox({
      shinydashboard::valueBox(
        p("Avg. Property Value", style = "font-size: 15px; text-align: center;"),
        p(paste(paste0(format(mean_property_value,big.mark = ','),"$")), style = "font-size: 30px; text-align: center;"), 
        color = "green", width = 25
      )
    })
    
    
    icons <- awesomeIcons(
      icon = 'ios-close',
      iconColor = 'black',
      library = 'ion',
      markerColor = "yellow"
      
    )
    icons2 <- awesomeIcons(
      icon = 'ios-close',iconColor = 'blue',library = 'ion',markerColor = Filter_df$color
    )
    
    
    
    Filter_df <- Filter_df[!Filter_df$PropertyId %in% c(6741,6742),]
    f1=Filter_df[Filter_df$MapZone=="Zone 1",]
    outline1 <- f1[chull(f1$lon, f1$lat),]
    
    f2=Filter_df[Filter_df$MapZone=="Zone 2",]
    outline2 <- f2[chull(f2$lon, f2$lat),]
    
    f3=Filter_df[Filter_df$MapZone=="Zone 3",]
    outline3 <- f3[chull(f3$lon, f3$lat),]
    
    f4=Filter_df[Filter_df$MapZone=="Zone 4",]
    outline4 <- f4[chull(f4$lon, f4$lat),]
    
    f5=Filter_df[Filter_df$MapZone=="Zone 5",]
    outline5 <- f5[chull(f5$lon, f5$lat),]
    
    f6=Filter_df[Filter_df$MapZone=="Zone 6",]
    outline6 <- f6[chull(f6$lon, f6$lat),]
    
    # f0=Filter_df[Filter_df$Zone=="Zone 0",]
    # outline0 <- f0[chull(f0$lon, f0$lat),]
    # 
    #
    f7=Filter_df[Filter_df$Zone!="No Zone",]
    # outline7 <- f7[chull(f7$lon, f7$lat),]
    f8=Filter_df[Filter_df$Zone=="No Zone",]
    
    
    
    bins <- c(0,0.2,0.4,0.6,0.8,1)
    pal <- colorNumeric(c("steelblue","orange", "red"),domain = FINAL_DF$value)
    
    map <- leaflet(data = Filter_df) %>%
      setView(lat =  29.79562421,
              lng = -93.23496583,
              zoom = 11) %>%
      addTiles() %>%
      #addCircles(data = f8,~lon, ~lat, ~10,  group = "Impact Location",color="steelblue",popup = ~paste("Impact Score:",as.character(value))) %>%
      addCircles(data = Filter_df,~lon, ~lat, ~20,  group = "Impact Location",color=~pal(value),popup = ~paste("Impact Score:",as.character(value)) ) %>%
      addPolygons(data = md1, lng = ~lon, lat = ~lat, color = "red", weight = 0.25, layerId = "outer1",
                  smoothFactor = 0.5,opacity = 0.5, fillOpacity = 0.1,group = "Risk Zones")%>%
      addPolygons(data = md2, lng = ~lon, lat = ~lat, color = "steelblue", weight = 0.25, layerId = "outer2",
                  smoothFactor = 0.5,opacity = 0.5, fillOpacity = 0.1,group = "Risk Zones")%>%
      addPolygons(data = md3, lng = ~lon, lat = ~lat, color = "orange", weight = 0.25, layerId = "outer3",
                  smoothFactor = 0.5,opacity = 0.5, fillOpacity = 0.1,group = "Risk Zones")%>%
      addPolygons(data = md4, lng = ~lon, lat = ~lat, color = "steelblue", weight = 0.25, layerId = "outer4",
                  smoothFactor = 0.5,opacity = 0.5, fillOpacity = 0.1,group = "Risk Zones")%>%
      addPolygons(data = outline1, lng = ~lon, lat = ~lat,
                  fillColor = ~pal(mean(f1$value)), weight = 2, color = ~pal(mean(f1$value)), group = "Impact Zones",layerId = ~MapZone, opacity = 0.9,label = "Zone 1", highlight = highlightOptions(weight = 3,bringToFront = TRUE,sendToBack = TRUE)) %>%
      addPolygons(data = outline2, lng = ~lon, lat = ~lat,
                  fillColor = ~pal(mean(f2$value)), weight = 2, color = ~pal(mean(f2$value)), group = "Impact Zones",layerId = ~MapZone, opacity = 0.9,label = "Zone 2", highlight = highlightOptions(weight = 3,bringToFront = TRUE,sendToBack = TRUE)) %>%
      addPolygons(data = outline3, lng = ~lon, lat = ~lat,
                  fillColor = ~pal(mean(f3$value)), weight = 2, color = ~pal(mean(f3$value)), group = "Impact Zones",layerId = ~MapZone, opacity = 0.9,label = "Zone 3", highlight = highlightOptions(weight = 3,bringToFront = TRUE,sendToBack = TRUE)) %>%
      addPolygons(data = outline4, lng = ~lon, lat = ~lat,
                  fillColor = ~pal(mean(f4$value)), weight = 2, color = ~pal(mean(f4$value)), group = "Impact Zones",layerId = ~MapZone, opacity = 0.9,label = "Zone 4", highlight = highlightOptions(weight = 3,bringToFront = TRUE,sendToBack = TRUE)) %>%
      addPolygons(data = outline5, lng = ~lon, lat = ~lat,
                  fillColor = ~pal(mean(f5$value)), weight = 2, color = ~pal(mean(f5$value)), group = "Impact Zones",layerId = ~MapZone, opacity = 0.9,label = "Zone 5", highlight = highlightOptions(weight = 3,bringToFront = TRUE,sendToBack = TRUE)) %>%
      addPolygons(data = outline6, lng = ~lon, lat = ~lat,
                  fillColor = ~pal(mean(f6$value)), weight = 2, color = ~pal(mean(f6$value)), group = "Impact Zones",layerId = ~MapZone, opacity = 0.9,label = "Zone 6", highlight = highlightOptions(weight = 3,bringToFront = TRUE,sendToBack = TRUE)) %>%
      addLegend(pal = pal, values = ~value, opacity = 0.5, title = "Impact Level",
                position = "bottomright",group = "Impact Zones")%>%
      addMarkers(~lon, ~lat, clusterOptions = markerClusterOptions(),icon =  icons, popup = ~paste("Property id:",as.character(house_id),"<br>Impact Score:",as.character(value),"<br>Property Value:",as.character(Property.Value),"$","<br>Property_Damage_Amount:",as.character(Property_Damage_Amount),"$"), label = ~paste("House ID:",as.character(house_id)), 
                 group = "Property Clusters",  labelOptions = labelOptions(noHide = T,opacity = 0.7))%>%
      addLayersControl(
        baseGroups = c("Impact Zones","Impact Location","Property Clusters"),
        overlayGroups = c("Risk Zones"),
        position = "bottomleft",
        options = layersControlOptions(collapsed = FALSE)
      ) 
    
    
    if (!is.null(shapeclick)){
      map <- map %>% hideGroup("Risk Zones")}
    
    
    output$houseLocPlot <- renderLeaflet({
      map
      
      
    })
    
    
    
    
    
    
    output$featuretable <- renderDT({
      Filter_df1$Estimated.Claim.amount =round(Filter_df1$Estimated.Claim.amount,1)
      Filter_df1$SumInsuredLimit =round(Filter_df1$SumInsuredLimit,1)
      
      Filter_df1 <- Filter_df1[order(-Filter_df1$Estimated.Claim.amount),]
      Filter_df1$Distance_to_Nearest_Impact_Zone <- round(Filter_df1$Distance_to_Nearest_Impact_Zone,1)
      Filter_df1$Property_Damage_Amount <- round(Filter_df1$Property_Damage_Amount,1)
      Filter_df1$withinimpactzone <- ifelse(Filter_df1$Distance_to_Nearest_Impact_Zone>0, "No", "Yes")
      df_table<-Filter_df1[c("house_id","PropertyType","withinimpactzone" ,"value", "Distance_to_Nearest_Impact_Zone","Property_Damage_Amount","Property.Value" ,"SumInsuredLimit" ,"Estimated.Claim.amount")]
      df_table
    }, rownames = FALSE,colnames = c("Property ID","Property Type" ,"Within Impact Zone?","Impact Score","Impact Zone Distance(m)","Property Damage Amount($)","Property Value($)" ,"Sum Insured Limit($)","Estimated Claim amount($)"),  selection = 'single', server = FALSE, options = list(pageLength = 6)
    )
    
    

    
    output$pieInsurance <- renderPlot({

      df_insurer <- Filter_df1 %>% 
        group_by(Insurance.Product) %>% 
        count() %>% 
        ungroup() %>% 
        mutate(per=`n`/sum(`n`)) %>% 
        arrange(desc(Insurance.Product))
      
      df_insurer$label <- scales::percent(df_insurer$per)
      
      ggplot(data=df_insurer)+
        geom_bar(aes(x="", y=per, fill=Insurance.Product), stat="identity", width = 1)+
        coord_polar("y", start=0)+
        theme_void()+
        geom_text(aes(x=1, y = cumsum(per) - per/2, label=label)) +
        ggtitle("Properties with different Insurance Products") +
        scale_fill_brewer(palette="Blues")+theme_void()
      
      
      
    })
    
    
    
    breaks <- c(0,0.20,0.40,0.60,0.80,1.0)
    # specify interval/bin labels
    gtags <- c("[0-0.20)","[0.20-0.40)", "[0.40-0.60)", "[0.60-0.80)","[0.80-1.0)")
    # bucketing values into bins
    group_tags <- cut(Filter_df1$value, 
                      breaks=breaks, 
                      include.lowest=TRUE, 
                      right=FALSE, 
                      labels=gtags)
    # inspect bins
    
    df_damageinZones<- as.data.frame(summary(group_tags))
    
    names(df_damageinZones) <-c("No.of.Houses")
    df_damageinZones$Damage_score_range <- rownames(df_damageinZones)
    
    output$damagelevelsnhouses <- renderPlot({
      
      
      #ggplot(data=df_damageinZones) +  aes(x=Damage_score_range, y=No.of.Houses,
      #                                     fill=No.of.Houses) + 
      #  geom_bar(stat="identity", width = 0.4, fill = "#55a9e6") +
      #  geom_text(aes(label=No.of.Houses), vjust = -0.2) +
      #  labs(x="Impact Score Level", y="Properties with impact score level", title="No. of properties with impact score levels") +
      #  ggtitle("Impact Levels and No of Properties") +
      #  theme(axis.text.x = element_text(vjust=0.5) )+
      #  theme(legend.position="none") + coord_flip()
      #
      Filter_df3=Filter_df1
      Filter_df3$Impact_Score <- ifelse(Filter_df3$value>0.5, ">0.5", "0.3 - 0.5")
      Filter_df3$Impact_Score <- ifelse(Filter_df3$value<0.3, "<0.3", Filter_df3$Impact_Score)
      levels(FINAL_DF$Impact_Score) = c(">0.5", "0.3 - 0.5", "<0.3")
      
      
      qplot(Estimated.Claim.amount, data=Filter_df3, geom="density", fill=Impact_Score, alpha=I(.5),
            main="Distribution of Estimated Claim Amount", xlab="Estimated Claim Amount($)",
            ylab="Density") +
        scale_fill_brewer(palette="Dark2") +
        theme_bw()
      
      
    })
    Filter_df2=Filter_df1[Filter_df1$house_id!=2480,]
    Filter_df2$Percentage_of_Claim_amount <- Filter_df2$Estimated.Claim.amount/Filter_df2$Claim_amount*100
    
    output$damagescoreimpact <- renderPlot({
      
      
      ggplot(data=Filter_df2) + 
        aes(x=value, y=Percentage_of_Claim_amount,  color=Previous_claims) +
        geom_point(alpha=0.9,size=3) +
        labs(x="Impact Score", y="Percentage of Claim Amount($)") +
        ggtitle("Estimating Percentage of Claim amount using Impact Score") 
      
      
    })
    
    
    
    
    
    
    
  })  # End of Observe 
  
  
  #  observeEvent(input$houseLocPlot_click,{
  #    data$clickedMarker <- NULL
  #    
  #    print(paste("Outside shape click",data$clickedMarker))
  #})
  
  
  
  
  
  
  
}