library(shiny)
library(ggplot2)

readDataset <- function(fileName) { read.csv(file.path(fileName)) }

list.files("Insurance-Loss-Estimation-Using-Remote-Sensing-Dashboard")
#model_DF <- readDataset("model_output_summary.csv")

model_DF <- readDataset("/home/rstudio/project-objectstorage/model_output_summary.csv")

df_MapZones <- fromJSON("MapZones.json") %>% as.data.frame

FINAL_DF <- merge(model_DF,df_MapZones,by=c("PropertyId","lat","lon"))


FINAL_DF$value <- FINAL_DF$Impact_Score
FINAL_DF$Sum.Insured.Limit <- FINAL_DF$SumInsuredLimit
FINAL_DF$house_id <- FINAL_DF$PropertyId
FINAL_DF$Claim_amount <- FINAL_DF$Property_Damage_Amount
FINAL_DF$Estimated.Claim.amount <- FINAL_DF$Estimated_Claim_Amount 

FINAL_DF$value <- round(FINAL_DF$value,2)
FINAL_DF$color <- ifelse(FINAL_DF$value>0.5, "Red", "Orange")
FINAL_DF$color <- ifelse(FINAL_DF$value<0.3, "Green", FINAL_DF$color)

FINAL_DF$severity <- ifelse(FINAL_DF$value>0.5, "High", "Medium")
FINAL_DF$severity <- ifelse(FINAL_DF$value<0.3, "Low", FINAL_DF$severity)
FINAL_DF$City <-"Cameron"
FINAL_DF$Zone <-FINAL_DF$Impact_Zone
names(FINAL_DF)




l_clientIDs <- c(1101, 3105, 1100, 4084, 1105,1580,1114)

# if the pre-defined customer ID's aren't in the unseen data select a random customer
i <- 1
for (clientID in l_clientIDs) {
  if (!(clientID %in% as.numeric(unlist(FINAL_DF["house_id"])))) {
    l_clientIDs[i] <- sample(FINAL_DF[, "house_id"], 1)
    i <- i + 1
  } 
}



clients <- list(
  list(Insurance_ID="253396", image="h1.jpg", clientId=l_clientIDs[1]),
  list(Insurance_ID="277013", image="h2.jpg", clientId=l_clientIDs[2]),
  list(Insurance_ID="314248", image="h3.jpg", clientId=l_clientIDs[3]),
  list(Insurance_ID="293293", image="h4.jpg", clientId=l_clientIDs[4]),
  list(Insurance_ID="263868", image="h5.jpg", clientId=l_clientIDs[5]),
  list(Insurance_ID="315777", image="h6.jpg", clientId=l_clientIDs[6]),
  list(Insurance_ID="313170", image="h7.jpg", clientId=l_clientIDs[7])
)

cols_to_use_score=c('Distance_to_Nearest_Impact_Zone','Property.Value','Property.Replacement.Value','Impact_Score','PropertySize','SumInsuredLimit','Property_Damage_Amount','Years.Since.Constructed','Basement.area','Previous_claims','Insurance.Product','Extended.Coverage','Construction.material','Construction.type','Protection_Class')
cols_to_use_score2=c('Distance_to_Nearest_Impact_Zone','Property Value','Property Replacement Value',
                     'Impact_Score',
                     'PropertySize',
                     'SumInsuredLimit',
                     'Property_Damage_Amount',
                     'Years Since Constructed',
                     'Basement area',
                     'Previous_claims',
                     'Insurance Product',
                     'Extended Coverage',
                     'Construction material',
                     'Construction type',
                     'Protection_Class')




CoastalLARiskZones <- fromJSON("CoastalRiskZones.json") %>% as.data.frame
blocks = CoastalLARiskZones$coordinates


m1 <- matrix(as.numeric(strsplit(blocks,",")[[1]]),ncol=2,byrow=TRUE)
md1 <- data.frame(m1)
names(md1) <- c("lon","lat")

m2 <- matrix(as.numeric(strsplit(blocks,",")[[2]]),ncol=2,byrow=TRUE)
md2 <- data.frame(m2)
names(md2) <- c("lon","lat")

m3 <- matrix(as.numeric(strsplit(blocks,",")[[3]]),ncol=2,byrow=TRUE)
md3 <- data.frame(m3)
names(md3) <- c("lon","lat")

m4 <- matrix(as.numeric(strsplit(blocks,",")[[4]]),ncol=2,byrow=TRUE)
md4 <- data.frame(m4)
names(md4) <- c("lon","lat")



