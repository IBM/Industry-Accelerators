# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

scoringPanel <- function() {
  tabPanel(
    "Simulation Tool",
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 90% !important;
                      }
                      .html-widget.gauge svg {
                        height: 300px;
                        width: 600px;
                      }
                      "))
    ),
    shinyjs::useShinyjs(), 
    
    fluidRow(
      h2("Simulation Tool"),
      panel(
        h4("Use this tool to modify any of the input variables in the form below. After changes are made click on the button to return the Estimated Claim Amount."),
        h4("Ensure that you are connected to CPD by entering API details in the Property View Tab.")),
      column(8,
             h3("User Inputs"),
             panel(
               h3("Property Damage Information"),
               fluidRow(
                 column(3,
                        selectInput("withinimpactzone", "Within Impact Zone ?", c("Yes","No"),selected="Yes" )
                 ),
                 column(3,
                        numericInput("damagelevel1", "Impact Score", value =0.6 )
                 ),
                 column(3,
                        numericInput("damage_amount", "Property Damage Amount($)", 
                                     value = 50000)
                 )
                 
               )),
             panel(
               h3("Property Information"),
               fluidRow(
                 column(3,
                        numericInput("Property_value", "Property Value($)", 
                                     value = 200000
                        )),
                 column(3,
                        numericInput("PropertySize", "Property Size", 
                                     value = 1000
                        )),
                 column(3,
                        numericInput("Replacement_Value", "Property Replacement Value($)", 
                                     value = 150000)),
                 column(3,
                        numericInput("years_construct", "Number of Years since Construction", 
                                     value = 10))
                 
               ),
               fluidRow(
                 column(3,
                        selectInput("construction_type", "Construction Type",
                                    as.character(unique(FINAL_DF$Construction.type)),
                                    selected = "Wood frame and brick")),
                 column(3,
                        selectInput("Construction_material", "Construction material",
                                    as.character(unique(FINAL_DF$Construction.material)),
                                    selected = "Wood")),
                 column(3,
                        selectInput("Protection_class", "Protection Class",
                                    as.character(unique(FINAL_DF$Protection_Class)),
                                    selected = "Flood Protection")),
                 column(3,
                        numericInput("Basement_area", "Basement Area", 
                                     value = 0 ))
               )
             ),
             panel(
               h3("Insurance Information"),
               column(3,
                      
                      
                      selectInput("exreplacementcost", "Extended Coverage",
                                  unique(FINAL_DF$Extended.Coverage),
                                  selected = 1
                      )
               ),
               column(3,
                      selectInput("insurance_product", "Insurance Product",
                                  as.character(unique(FINAL_DF$Insurance.Product)),
                                  selected = "Home owners policys"
                      )),
               column(3,
                      numericInput("SumInsuredLimit", "Sum Insured Limit($)", 
                                   value = 100000
                      )),
               
               column(3,
                      selectInput("previous_claims", "Previous Claims",
                                  unique(FINAL_DF$Previous_claims),
                                  selected = 1
                      )),
               
               
               
               
               actionButton("realTimeScoreButton", "Make Estimated Claim Amount Prediction", class = "btn-primary btn-lg btn-block", disabled = TRUE)
             )
      ),
      column(4,
             br(),
             br(),
             br(),
             
             p(
               #progressBar(
               #  id = "progbar",
               #  value = 0, total = 100,
               #  
               #  title = "Percentage of Claim Amount",
               #  display_pct = TRUE
               #),
               valueBoxOutput("estdclaim2")
             )
      )
    )
    
  )
  
}


scoringServer <- function(input, output, session, sessionVars) {
  
  # Enable buttons when inputs are provided
  observe({
    if (length(sessionVars$selectedDeployment)) {
      enable("realTimeScoreButton")
    }
    
    
    impact_value=0
    distance_impact=0
    if(input$withinimpactzone=="Yes"){
      updateNumericInput(session, "damagelevel1", label="Impact Score",value = 0.6)
      impact_value=input$withinimpactzone
      distance_impact=0
    }
    
    if(input$withinimpactzone=="No"){
      updateNumericInput(session, "damagelevel1", label="Distance to Impact Zone (m)",value = 20)
      distance_impact=input$withinimpactzone
      impact_value=0
    }
    #if(input$damagelevel1>0){
    #  updateNumericInput(session, "zonedistance", value = 0)
    #  updateSelectInput(session,"withinimpactzone",selected="Yes")}
    #
    #if(input$zonedistance>0){
    #  updateNumericInput(session, "damagelevel1", value = 0)
    #  updateSelectInput(session,"withinimpactzone",selected="No")}
  })
  
  
  
  observeEvent(input$realTimeScoreButton, {
    
    if(input$withinimpactzone=="Yes"){
      
      impact_value=input$damagelevel1
      distance_impact=0
    }
    
    if(input$withinimpactzone=="No"){
      
      distance_impact=input$damagelevel1
      impact_value=0
    }
    
    # craete the record that will be passed to the payload
    # variables such as ID, gender, name, etc need to be included in payload as they were originally included
    # but they are not used as model inputs so the values can be filled with default values here
    
    scoring_data <- data.frame(
      zonedistance=distance_impact,
      PropertyValuenew=input$Property_value,
      ReplacementValuenew=input$Replacement_Value,
      damagelevel=impact_value,
      PropertySize=input$PropertySize,
      SumInsuredLimit=input$SumInsuredLimit,
      Insurance_Claim_Amount=input$damage_amount,
      NumberofyearsConstructed=input$years_construct,
      Basementarea=input$Basement_area,
      InsuranceProduct=input$insurance_product,
      Extendedreplacementcost=input$exreplacementcost,
      Constructionmaterial=input$Construction_material,
      Constructiontype=input$construction_type,
      Previous_claims=input$previous_claims,
      Protection_Class=input$Protection_class
      
      
    )
    
    # convert into json
    real_time_json_data <- jsonlite::toJSON(scoring_data)
    print(real_time_json_data)
    # call the api and get the prediction back
    
    response <- scoreModelDeployment(sessionVars$selectedDeployment$scoring_url, scoring_data, serverVariables$token)
    
    predicted_prob <- response$predictions[[1]]$values[[1]][[1]]
    if(predicted_prob>input$damage_amount){
      predicted_prob=input$damage_amount
    }
    predicted_prob <- round(predicted_prob,2)
    prog_value2=round((predicted_prob/input$damage_amount)*100,2)
    
    #updateProgressBar(
    #  session = session,
    #  id = "progbar",
    #  
    #  value = prog_value2,total = 100
    #)
    
    # create the gauge
    output$estdclaim2 <- renderValueBox({
      shinydashboard::valueBox(
        p("Estimated Claim Amount", style = "font-size: 15px; text-align: center;"),
        p(paste(paste0(format(predicted_prob,big.mark = ','),"$")), style = "font-size: 30px; text-align: center;"), 
        color = "green", width = 25
      )
    })
    
    
    
    
  })
  
  
  
}
