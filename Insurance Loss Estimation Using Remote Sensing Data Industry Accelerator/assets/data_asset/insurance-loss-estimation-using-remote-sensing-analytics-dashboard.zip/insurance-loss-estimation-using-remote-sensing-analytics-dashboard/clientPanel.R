# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2021. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.


# function to create buttons for each client

#install.packages("echarts4r")
#library(echarts4r)
#
#e_
#e_charts() %>% 
#  e_gauge(0.5, "Efficiency",min=0,max=1, center = c("30%", "60%"), radius = "60%")  %>%  e_tooltip()

clientButton <- function(id, name, image) {
  
  tags$p(
    actionButton(paste0('client-btn-', id),
                 fluidRow(
                   column(4, 
                          tags$img(class = "pull-left", src = image, width = "60px", height = "60px")
                   ),
                   column(3,
                          #tags$h4(strong(name)),
                          tags$h6(em(paste('House ID: ', id))),
                          tags$h6(em(paste('Insurance ID: ', name)))
                   )
                 ),
                 style="width:100%"
    )
  )
}


refreshCode <- "shinyjs.refresh = function() { location.reload(); }"

clientPanel <- function() {
  
  tabPanel(
    "Property View",
    value = "clientPanel",
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 90% !important;
                      }
                      .html-widget.gauge svg {
                        height: 300px;
                        width: 600px;
                      }
                      "))
    ),
    shinyjs::useShinyjs(),
    shinyjs::extendShinyjs(text = refreshCode, functions = c("refresh")),
    
    fluidRow(
      div( id = "topActionClients",
           column(3, class = "pull-left",
                  panel(
                    span(align = "center", h2("Top Action Properties")),
                    span(align = "center", h5("Click on Property for further information or Enter customer id in the box")),
                    br(),
                    uiOutput("topClients")
                    
                  )
                  
           )
      ),
      
      div(
        id = "clientInfoPanel",
        column(9,class="pull-right",
               fluidRow(
                 fluidRow(
                   column(1
                          
                   ),
                   column(4,class="pull-left",
                          span(align = "left", h4("Property ID")),
                          
                          numericInput("houseid",
                                       h6("Enter Property ID between 1001 and 7103 or select from top action clients "), 
                                       value = 1105,min=1000,max=7103)),
                   column(4, class="pull-left",
                          span(align = "center", h3("Client Personal Information")),
                          uiOutput("clientpersonalInfo1")
                   )
                 ),
                 column(5,
                        span(align = "center", h3("Client Property Information")),
                        br(),
                        uiOutput("clientInfo2")
                        ),
                 column(1,br()),
                 column(5,
                        
                        span(align = "center", h3("Client Insurance Information")),
                        br(),
                        uiOutput("clientRetailInfo1")
                 )
               ),
               
               panel(
                 fluidRow(
                   
                   column(5,
                          span(align = "center", h3("Property Impact Score")),
                          gaugeOutput("gaugePrediction")
                          
                   )
          
                 )
               ),
               fluidRow(
                 panel(
                   h3("Client Insurance Claim Amount Prediction "),
                   br(),
                   
                   tags$div(
                     id = "authPanel",
                     column(4,
                            panel(
                              h4("Connect to IBM Cloud API"),
                              pickerInput(
                                inputId = 'username',
                                label = 'Select a Region',
                                choices = list("us-south","eu-de","eu-gb","jp_tok"),
                                options = pickerOptions(width = "auto", style = "btn-primary")
                              ),
                              passwordInput("password", "API KEY"),
                              actionButton("authBtn", "Authenticate API", class = "btn-primary btn-lg btn-block", style = "max-width:300px", disabled = TRUE),
                              tags$head(tags$style("#authError{color:red;}")),
                              verbatimTextOutput("authError")
                            ),
                            style = "max-width:360px;"
                     )
                   ),
                   hidden(
                     tags$div(
                       id = "deploymentPanel",
                       column(4,
                              panel(
                                tags$h4("Model Scoring Pipeline Deployment"),
                                pickerInput(
                                  inputId = 'deploymentSelector',
                                  label = 'Deployment Name:',
                                  choices = list(),
                                  options = pickerOptions(width = "auto", style = "btn-primary")
                                ),
                                tags$p(
                                  tags$strong("Space Name: "),
                                  textOutput(outputId = "space_name", inline = TRUE)
                                ),
                                tags$p(
                                  tags$strong("GUID: "),
                                  textOutput(outputId = "deployment_guid", inline = TRUE)
                                ),
                                
                                tags$p(
                                  tags$strong("Scoring Endpoint: "),
                                  textOutput(outputId = "scoring_url", inline = TRUE),
                                  style = "word-wrap: break-word"
                                )),
                              
                              panel(
                                actionButton("refresh", "Back to Home", class = "btn-primary btn-sm btn-block")
                              )
                       ),
                       tags$div(id = "scoreBtnSection",
                                column(4,
                                       br(),
                                       actionButton(
                                         "scoreBtn",
                                         "Predict Estimated Claim Amount",
                                         class = "btn-primary btn-lg btn-block",
                                         disabled = TRUE
                                       ),
                                       br(),
                                       h4("Input JSON:"),
                                       verbatimTextOutput("pipelineInput"),
                                       br(),
                                       tags$head(tags$style("#scoringError{color:red;}")),
                                       verbatimTextOutput("scoringError"))
                       ),
                       column(8,
                              hidden(
                                tags$div(id = "scoringResponse")
                              )
                       )
                     )
                   )
                 )
                 
               )
               
        )
      )
      
      
    )
  )
  
}


# Reactive server variables store (pervades across all sessions)
serverVariables = reactiveValues(deployments = list(), token = '')


  tryCatch({
    deploymentsResp = collectDeployments(input$username, input$password,"Insurance Claims using Remote Sensing Model Deployment")
    
    serverVariables$deployments <- deploymentsResp$deployments
    serverVariables$token = deploymentsResp$token
  }, warning = function(w) {
    print(w$message)
  }, error = function(e) {
    print(e$message)
  })


clientServer <- function(input, output, session, sessionVars) {
  observeEvent( input$refresh, {shinyjs::js$refresh()})
  
  # create the button for clients
  output$topClients <- renderUI({
    
    
    
    # List of client buttons
    lapply(clients, function(client){
      clientButton(client$clientId, client$Insurance_ID, paste0("profiles/", client$image))
    })
    
  })
  
  
  # Observation events for client buttons
  lapply(clients,
         function(client){
           x <- paste0('client-btn-', client$clientId)
           observeEvent(
             input[[x]],
             {
               new_house_id = substr(x,12,nchar(x))
               updateNumericInput(session, "houseid", value = new_house_id)
               
               
               sessionVars$selectedClientId <- client$clientId
               
               updateNumericInput(session, "houseid", value = new_house_id)
               shinyjs::toggleElement(paste0("clientInfo-",substr(x,12,nchar(x))))
               
               
               
               
               shinyjs::show(id = "clientInfoPanel")
             })
         })
  
  
  output$clientpersonalInfo1 <- renderUI({
    i_houseid=input$houseid 
    
    client_name <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Owner_Name"])
    client_id <- i_houseid
    
    client_email <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "EMAIL"])
    client_phone <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "PHONE_1"])
    client_city <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "City"])
    client_address <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Description"])
    tags$ul( class = 'list-unstyled',
             tags$li(
               tags$strong('Property ID: '), tags$span(class = "pull-right", client_id)
             ),
             tags$li(
               tags$strong('Owner Name: '), tags$span(class = "pull-right", client_name)
             ),
             
             tags$li(
               tags$strong('Owner Phone: '), tags$span(class = "pull-right", client_phone)
             ),
             tags$li(
               tags$strong('Address: '), tags$span(class = "pull-right", client_address)
             ),
             tags$li(
               tags$strong('City: '), tags$span(class = "pull-right", client_city)
             )
    )
  })
  
  output$clientInfo2 <- renderUI({
    
    i_houseid=input$houseid 
    
    
    client_housezone <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Zone"])
    #client_Insurer <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Insurer"])
    client_house_renovate <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Construction.Rennovation.date"])
    client_PropertyType <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "PropertyType"])
    client_consutruction_material <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Construction.material"])
    client_construction_type <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Construction.type"])
    client_roof_upgraded <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Year.roof.upgraded"])
    client_electric_upgraded <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Year.electric.upgraded"])
    client_property_value <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Property.Value"])
    
    
    tags$ul( class = 'list-unstyled',
             tags$li(
               tags$strong('Property Type: '), tags$span(class = "pull-right", client_PropertyType)
             ),
             
             tags$li(
               tags$strong('Property Constructed/Renovated : '), tags$span(class = "pull-right", client_house_renovate)
             ),
             tags$li(
               tags$strong('Property value: '), tags$span(class = "pull-right","$", client_property_value)
             ),
             tags$li(
               tags$strong('Construction Material: '),tags$span(class = "pull-right", client_consutruction_material)
             ),
             tags$li(
               tags$strong('Construction Type: '),tags$span(class = "pull-right", client_construction_type)
             ),
             tags$li(
               tags$strong('Electricity Upgraded on: '),tags$span(class = "pull-right", client_electric_upgraded)
             ),
             tags$li(
               tags$strong('Roof Upgraded on: '),tags$span(class = "pull-right", client_roof_upgraded)
             )
    )
  })
  
  
  
  output$clientRetailInfo1 <- renderUI({
    FINAL_DF$Claims.paid.net.of.reinsurance <- round(FINAL_DF$Claims.paid.net.of.reinsurance,2)
    FINAL_DF$SumInsuredLimit <- round(FINAL_DF$SumInsuredLimit,2)
    
    i_houseid=input$houseid 
    client_insuranceid <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Insurance_ID"])
    #client_Insurer <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Insurer"])
    FINAL_DF$Property_Damage_Amount <- round(FINAL_DF$Property_Damage_Amount,1)
    client_damage_amount_claimed <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Property_Damage_Amount"])
    client_reinsurance_net <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Claims.paid.net.of.reinsurance"])
    client_Previous_claims <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Previous_claims"])
    client_Insurance_Product <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Insurance.Product"])
    client_insurance_claimed_on <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "Calendar.Date"])
    client_suminsuredamt <- as.character(FINAL_DF[FINAL_DF["house_id"]==i_houseid, "SumInsuredLimit"])
    
    
    
    tags$ul( class = 'list-unstyled',
             
             #tags$li(
             #  tags$strong('Insurance Company: '), tags$span(class = "pull-right", client_Insurer)
             #),
             tags$li(
               tags$strong('Insurance ID: '), tags$span(class = "pull-right", client_insuranceid)
             ),
             tags$li(
               tags$strong('Insurance Product: '), tags$span(class = "pull-right", client_Insurance_Product)
             ),
             tags$li(
               tags$strong('Amount Claimed for Property Damage: '),tags$span(class = "pull-right","$", client_damage_amount_claimed)
             ),
             tags$li(
               tags$strong('    ')
             ),
             tags$li(
               tags$strong('Insurance Claimed on: '),tags$span(class = "pull-right", client_insurance_claimed_on)
             ),
             tags$li(
               tags$strong('Sum Insured Limit: '),tags$span(class = "pull-right","$", client_suminsuredamt)
             ),
             tags$li(
               tags$strong('Insurance Claims Paid Net of Reinsurance: '),tags$span(class = "pull-right","$", client_reinsurance_net)
             ),
             tags$li(
               tags$strong('Previous Claims by the Customer: '),tags$span(class = "pull-right", client_Previous_claims)
             )
    )
    
    
  })   
  
  
  
  
  
  
  output$gaugePrediction = renderGauge({
    i_houseid=input$houseid 
    
    prob <- FINAL_DF[FINAL_DF["house_id"]==i_houseid, "value"]
    
    gauge(round(prob,2), 
          #symbol = '%',
          min = 0, 
          max = 1, 
          sectors = gaugeSectors(success = c(0, 0.4),
                                 warning = c(0.4, 0.65),
                                 danger = c(0.65, 1)))
  })
  

  
  
  
  observe({
    
    # filter the csv for the selected customer and use as input for the API
    df_filtered <- FINAL_DF[FINAL_DF["PropertyId"]==input$houseid, ][cols_to_use_score]
    # remove columns that weren't in the original input dataset
    # we need to do this becuase of the csv file we're using for demo
    # in real scenario this data would come from db or raw csv
    
    json_data <- jsonlite::toJSON(df_filtered)
    
    
    
    # Reset scoring
    removeUI(selector = "#scoringResponse > *", multiple = TRUE)
    shinyjs::hide(id = "scoringResponse")
    shinyjs::show(id = "scoreBtnSection")
    output$scoringError <- renderText('')
    sessionVars$pipelineInput <- df_filtered
    output$pipelineInput <- renderText(json_data)
  })
  

  
  # Enable buttons when inputs are provided
  observe({
    toggleState("authBtn",  nchar(input$username) > 0 && nchar(input$password) > 0)
    toggleState("scoreBtn", nchar(input$endpoint) > 0 && nchar(input$token) > 0 && length(input$houseid) > 0)
  })
  

  
  # Handle CP4D API authentication button
  observeEvent(input$authBtn, {
    shinyjs::disable("authBtn")
    
    tryCatch({
      deploymentsResp = collectDeployments(input$username, input$password, "Insurance Loss Estimation Using Remote Sensing Model Deployment")
      serverVariables$deployments <- deploymentsResp$deployments
      serverVariables$token = deploymentsResp$token
    }, warning = function(w) {
      output$authError <- renderText(w$message)
    }, error = function(e) {
      output$authError <- renderText(e$message)
    })
    
    shinyjs::enable("authBtn")
    
    if(length(serverVariables$deployments) > 0) {
      updateSelectInput(session, "deploymentSelector", choices = names(serverVariables$deployments))
      shinyjs::hide(id = "authPanel")
      shinyjs::show(id = "deploymentPanel")
    }
  })
  
  # Handle model deployment dropdown switching
  observeEvent(input$deploymentSelector, {
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    output$deployment_guid <- renderText(selectedDeployment$guid)
    output$space_name <- renderText(selectedDeployment$space_name)
    
    output$scoring_url <- renderText(selectedDeployment$scoring_url)
    toggleState("scoreBtn", nchar(selectedDeployment$scoring_url) > 0 && nchar(serverVariables$token) > 0)
  })
  
  observeEvent(input$scoreBtn, {
    shinyjs::disable("scoreBtn")
    
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    sessionVars$selectedDeployment <- selectedDeployment
    
    payload <- sessionVars$pipelineInput
    
    response <- scoreModelDeployment(selectedDeployment$scoring_url, payload, serverVariables$token)
    
    if(length(response$error) > 0) {
      output$scoringError <- renderText(toString(response$error))
    } else if (length(response$predictions) > 0) {
      shinyjs::hide(id = "scoreBtnSection")
      shinyjs::show(id = "scoringResponse")
      
      predicted_settlement <- response$predictions[[1]]$values[[1]][[1]]
      if(predicted_settlement>payload$Property_Damage_Amount){
        predicted_settlement=payload$Property_Damage_Amount
      }
      prog_value=round((predicted_settlement/payload$Insurance_Claim_Amount)*100,2)
      
      insertUI(
        selector = "#scoringResponse",
        where = "beforeEnd",
        ui = panel(
          tags$head(
            tags$style(HTML("
                      .datatables {
                      width: 100% !important;
                      }
                      .html-widget.gauge svg {
                        height: 300px;
                        width: 600px;
                      }
                      "))
          ),
          h3("Estimated Claim Amount:"),
          
          p(   
            valueBoxOutput("estdclaim")
            
            
          )
        )
      )
      output$estdclaim <- renderValueBox({
        shinydashboard::valueBox(
          p("Estimated Claim Amount", style = "font-size: 15px; text-align: center;"),
          p(paste(paste0(format(predicted_settlement,big.mark = ','),"$")), style = "font-size: 30px; text-align: center;"), 
          color = "green", width = 25, icon=icon("dollar-sign")
        )
      })
      
    } else {
      output$scoringError <- renderText(response)
    }
    
    
  })
  
  
  
  
  
  
  
  
}