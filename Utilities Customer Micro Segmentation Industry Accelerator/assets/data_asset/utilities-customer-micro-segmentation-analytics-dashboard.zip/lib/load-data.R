# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# Â© Copyrig ht IBM Corp. 2019. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

# Load Data from CSV files
library(readr)
library(scales)

readDataset <- function(fileName) { read.csv(file.path(fileName)) }

input_df <- readDataset("model output summary.csv")
#input_df$NUM_Qs_ANSWERED_YES=rowSums(df_sustain[,c("PROD_ECOLOGICAL","PROD_MEAT_SUBST","PROD_FAIRTRADE","PROD_REFORM","GREEN_ENERGY","FREQUENTING_NATURE","ENVIR_CHARITY","NATURE_CHARITY")])

# get a list of unique cluster numbers and the cluster description
df_cust_engagement_cluster_desc = unique(input_df[, c("CUSTOMER_ENGAGEMENT", "CUSTOMER_ENGAGEMENT_CLUSTER_DESCRIPTION")])
l_engagement_clusters <- df_cust_engagement_cluster_desc$CUSTOMER_ENGAGEMENT_CLUSTER_DESCRIPTION
names(l_engagement_clusters) <- as.character(df_cust_engagement_cluster_desc$CUSTOMER_ENGAGEMENT)

df_lifestyle_cluster_desc = unique(input_df[, c("LIFESTYLE_CLUSTER", "LIFESTYLE_CLUSTER_DESCRIPTION")])
l_lifestyle_clusters <- df_lifestyle_cluster_desc$LIFESTYLE_CLUSTER_DESCRIPTION
names(l_lifestyle_clusters) <- as.character(df_lifestyle_cluster_desc$LIFESTYLE_CLUSTER)

##Savings potential
df_99 <- input_df
df_99$CUSTOMER_ENGAGEMENT = "ALL"
df2 <-rbind(input_df,df_99)

cols_savings=c("TOTAL_USAGE_YEAR1","TOTAL_USAGE_YEAR2","ENERGY_SAVING","COST_TO_SERVE","CUSTOMER_ENGAGEMENT"  )
df=input_df[,cols_savings]
df2=df2[,cols_savings]

num_customers=nrow(input_df)


#Sustainability

cols_sustain=c("CUSTOMER_ID","PROD_ECOLOGICAL","PROD_MEAT_SUBST","PROD_FAIRTRADE","PROD_REFORM","GREEN_ENERGY","FREQUENTING_NATURE","ENVIR_CHARITY","NATURE_CHARITY","AGE_GROUP", "NUMBER_OF_QUESTIONS_ANSWERED_YES", "INCOME_LEVEL","EDUCATION","LIFESTYLE_CLUSTER")
df_sustain=input_df[,cols_sustain]

df_sustain_99=df_sustain
df_sustain_99$LIFESTYLE_CLUSTER="ALL"
df_sustain2=rbind(df_sustain,df_sustain_99)

cols_to_display=c("CUSTOMER_ID","NUMBER_OF_QUESTIONS_ANSWERED_YES", "INCOME_LEVEL","EDUCATION","ENERGY_SAVING","COST_TO_SERVE","LIFESTYLE_CLUSTER","CUSTOMER_ENGAGEMENT")


##### Prepare data for client panel



clients <- list(
  list(name="Leo Rakes", image="6M.jpg"),
  list(name="Catalina Santos", image="9F.jpg"),
  list(name="Thomas Owens", image="23M.jpg"),
  list(name="Liliana Hunnisett", image="10F.jpg"),
  list(name="Jeffery Smith", image="5M.jpg"),
  list(name="Jesica Abrams", image="22F.jpg"),
  list(name="Carla Warnes", image="25F.jpg"),
  list(name="Paige Carson", image="1F.jpg")
 # list(name="Alex Anderson", image="2M.jpg"),
 # list(name="Ian Gray", image="3M.jpg")
  #  list(name="Jane Wilson", image="8F.jpg"),
  # list(name="Robert Taylor", image="4M.jpg")
)


client_df <- subset(input_df,(COST_TO_SERVE >180)&(ENERGY_SAVING)>35)

client_df <- client_df[order(-client_df$COST_TO_SERVE),]
client_df$COST_TO_SERVE=round(client_df$COST_TO_SERVE,0)
client_df= head(client_df,8)
clientIds = c(client_df$CUSTOMER_ID)

names(clients) <- clientIds


for(id in clientIds) {
  clients[[toString(id)]]$COST_TO_SERVE <- dollar(client_df[client_df$CUSTOMER_ID == id,][[1,'COST_TO_SERVE']])
}


####### SCORE
result_lifestyle=data.frame(df_sustain %>%
                              group_by(LIFESTYLE_CLUSTER) %>%
                              summarize(Count = n()) )

result_lifestyle$LIFESTYLE_CLUSTER=factor(c("HIGH","MEDIUM","LOW"),levels=c("HIGH","MEDIUM","LOW"))
result_lifestyle$Count =c(317,361,322)

result_savings_potenttial=data.frame(df %>%
                                       group_by(CUSTOMER_ENGAGEMENT) %>%
                                       summarize(Count = n()) )




result_savings_potenttial$CUSTOMER_ENGAGEMENT=
  c("High energy saving and high Cost to serve",
    "High energy saving and Low Cost to serve",
    "Low energy saving and High Cost to serve",
    "Medium energy saving and Low Cost to serve",
    "Low energy saving and Low Cost to serve",
    "Medium energy saving and High Cost to serve"
  )




############ Sustainability JSON for r2d3
get_count_sustain=data.frame(df_sustain %>%
                               group_by(LIFESTYLE_CLUSTER) %>%
                               summarise(Size = n()) )

d_sustain=list()
d_sustain$CLUSTER="ALL"

for (row in 1:nrow(get_count_sustain)) {
  l1 <- get_count_sustain[row, "LIFESTYLE_CLUSTER"]
  l2  <- get_count_sustain[row, "Size"]
  d_sustain$children[[row]]=list(CLUSTER=l1,size=l2)
}

##########Savings potential json for r2d3
get_count_savings=data.frame(df %>%
                               group_by(CUSTOMER_ENGAGEMENT) %>%
                               summarise(Size = n()) )

d_savings=list()
d_savings$CLUSTER="ALL"

for (row in 1:nrow(get_count_savings)) {
  l1 <- get_count_savings[row, "CUSTOMER_ENGAGEMENT"]
  l2  <- get_count_savings[row, "Size"]
  d_savings$children[[row]]=list(CLUSTER=l1,size=l2)
}

