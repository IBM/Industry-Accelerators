# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# ÃÂ© Copyright IBM Corp. 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

clientButton <- function(id, name, image, COST_TO_SERVE, segment = NULL) {
  tags$p(
    actionButton(paste0('client-btn-', id),
                 fluidRow(
                   column(4, 
                          tags$img(class = "pull-left", src = image, width = "60px", height = "60px")
                   ),
                   column(3,
                          tags$h4(strong(name)),
                          tags$h6(em(paste('Customer ID: ', id))),
                          
                          
                   )
                 ),
                 style="width:100%"
    )#,
    #clientInfo(id)
  )
}


clientInfo <- function(id) {
  hidden(
    tags$ul(id= paste0("clientInfo-",id), class = 'list-unstyled',
            tags$li(
              tags$strong('Income Level: '), tags$span(class = "pull-right", client_df[client_df$CUSTOMER_ID == id,"INCOME_LEVEL"])
            ),
            tags$li(
              tags$strong('Education: '),tags$span(class = "pull-right", client_df[client_df$CUSTOMER_ID == id,"EDUCATION"])
            ),
            tags$li(
              tags$strong('Energy Saving: '), tags$span(class = "pull-right", client_df[client_df$CUSTOMER_ID == id,"ENERGY_SAVING"])
            )
    ))
}

clientPanel <- function() {
  
  tabPanel(
    "Client View",
    value = "clientPanel",
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 100% !important;
                      }
                      .html-widget.gauge svg {
                        height: 300px;
                        width: 600px;
                      }
                      "))
    ),
    shinyjs::useShinyjs(),
    shinyjs::extendShinyjs(text = refreshCode, functions = c("refresh")),
    
    fluidRow(
      div( id = "topActionClients",
           column(4, class = "pull-left", panel(
             span(align = "center", h2("TOP ACTION CUSTOMERS")),
             span(align = "center", h5("Click on Customer for features")),
             br(), 
             uiOutput("segmentClients")
           ))
      ),
      
      
      column(8, 
             panel(
               
               fluidRow(column(6,class = "pull-left",
                               h4("Customer ID"),
                               numericInput("customerid", 
                                            
                                            h6("Enter Customer ID between 1 and 1000 or select from top action clients "), 
                                            value = 1,min=1,max=1000))),
               fluidRow(
                 column(6,
                        h4("Personal Information", class="text-center"),
                        hr(),
                        uiOutput("clientDetails1")), 
                 column(6,
                        h4("Customer Engagement Information", class="text-center"),
                        hr(),
                        uiOutput("clientDetails2")
                 )
               ),
               fluidRow(
                 br(),
                 h4(" Lifestyle Survey Questions", class="text-center"),
                 hr(),
                 
                 column(6,
                      
                        uiOutput("clientDetails3")), 
                 column(6,
                        
                        
                        uiOutput("clientDetails4")
                 )
               ),
               
               
               
               
               
             ),
             
             panel(tags$div(
               h3("Utilities Customer Micro Segmentation model "),
               br(),
               id = "authPanel",
               column(5,
                      panel(
                        h4("Connect to Cloud Pak for Data API"),
                        textInput("hostname", "CPD Hostname"),
                        textInput("username", "CPD Username"),
                        passwordInput("password", "CPD Password"),
                        actionButton("authBtn", "Authenticate API", class = "btn-primary btn-lg btn-block", style = "max-width:300px", disabled = TRUE),
                        tags$head(tags$style("#authError{color:red;}")),
                        verbatimTextOutput("authError")
                      ),
                      style = "max-width:360px;"
               )
             ),
             hidden(
               tags$div(
                 id = "deploymentPanel",
                 column(6,
                        panel(
                          tags$h4("Model Scoring Pipeline Deployment"),
                          pickerInput(
                            inputId = 'deploymentSelector',
                            label = 'Deployment Name:',
                            choices = list(),
                            options = pickerOptions(width = "auto", style = "btn-primary")
                          ),
                          tags$p(
                            tags$strong("Space Name: "),
                            textOutput(outputId = "space_name", inline = TRUE)
                          ),
                          tags$p(
                            tags$strong("GUID: "),
                            textOutput(outputId = "deployment_guid", inline = TRUE)
                          ),
                          #  tags$p(
                          #    tags$strong("Tags: "),
                          #    textOutput(outputId = "deployment_tags", inline = TRUE)
                          #  ),
                          tags$p(
                            tags$strong("Scoring Endpoint: "),
                            textOutput(outputId = "scoring_url", inline = TRUE),
                            style = "word-wrap: break-word"
                          )),
                        panel(
                          actionButton(
                            "reauthenticateBtn",
                            "Re-Authenticate",
                            class = "btn-primary btn-lg btn-block"
                          ) 
                        )
                 ),
                 tags$div(id = "scoreBtnSection",
                          column(6,
                                 br(),
                                 actionButton(
                                   "scoreBtn",
                                   "Micro-Segment",
                                   class = "btn-primary btn-lg btn-block",
                                   disabled = TRUE
                                 ),
                                 br(),
                                 h4("Input JSON:"),
                                 verbatimTextOutput("pipelineInput"),
                                 br(),
                                 tags$head(tags$style("#scoringError{color:red;}")),
                                 verbatimTextOutput("scoringError"))
                 ),
                 fluidRow(column(6,
                                 hidden(
                                   tags$div(id = "scoringResponse")
                                 )
                 )
                 ))
             ))
             
      )
    )
    
    
  )
  
}


# Reactive server variables store (pervades across all sessions)
serverVariables = reactiveValues(deployments = list(), token = '')

if(nchar(Sys.getenv('CP4D_HOSTNAME')) > 0 && nchar(Sys.getenv('CP4D_USERNAME')) > 0 && nchar(Sys.getenv('CP4D_PASSWORD')) > 0) {
  tryCatch({
    deploymentsResp = collectDeployments(Sys.getenv('CP4D_HOSTNAME'), Sys.getenv('CP4D_USERNAME'), Sys.getenv('CP4D_PASSWORD'), "utilities_customer_micro_segmentation_scoring_pipeline_function_deployment_tag")
    serverVariables$deployments <- deploymentsResp$deployments
    serverVariables$token = deploymentsResp$token
  }, warning = function(w) {
    print(w$message)
  }, error = function(e) {
    print(e$message)
  })
}

clientServer <- function(input, output, session, sessionVars) {
  
  #default top client Actions
  output$segmentClients <- renderUI({
    
    # List of client buttons
    lapply(clientIds, function(id){
      client <- clients[[toString(id)]]
      sessionVars$selectedClientId <- id
      
      clientButton(id, client$name, paste0("profiles/", client$image), client$COST_TO_SERVE)
    })
  })
  output$clientDetails1 <- renderUI({
    
    client_age = as.character(input_df[input_df$CUSTOMER_ID==input$customerid,][[1,"AGE_GROUP"]])
    client_income = as.character(input_df[input_df$CUSTOMER_ID==input$customerid,][[1,"INCOME_LEVEL"]])
    client_education = as.character(input_df[input_df$CUSTOMER_ID==input$customerid,][[1,"EDUCATION"]])
    
    tags$ul( class = 'list-unstyled',
             
             tags$li(
               tags$strong('ID: '), tags$span(class = "pull-right", input$customerid)
             ),
             tags$li(
               tags$strong('Income: '),tags$span(class = "pull-right", client_income)
             ),
             tags$li(
               tags$strong('Education: '), tags$span(class = "pull-right", client_education)
             ),
             br()
    )
  })
  
  output$clientDetails2 <- renderUI({
    
    client_usage1 = round(input_df[input_df$CUSTOMER_ID==input$customerid,][[1,"TOTAL_USAGE_YEAR1"]],0)
    
    client_usage2 = round(input_df[input_df$CUSTOMER_ID==input$customerid,][[1,"TOTAL_USAGE_YEAR2"]],0)
    Change_in_usage = paste(round(input_df[input_df$CUSTOMER_ID==input$customerid,][[1,"ENERGY_SAVING"]],1),"%")
    client_cost_to_serve = dollar(round(input_df[input_df$CUSTOMER_ID==input$customerid,][[1,"COST_TO_SERVE"]],1))
    
    tags$ul( class = 'list-unstyled',
             
             tags$li(
               tags$strong('Energy Usage Year 1: '), tags$span(class = "pull-right", paste(client_usage1,"Kwh"))
             ),
             tags$li(
               tags$strong('Energy Usage Year 2: '),tags$span(class = "pull-right", paste(client_usage2,"Kwh"))
             ),
             tags$li(
               tags$strong('Percentage Change in Usage: '), tags$span(class = "pull-right", Change_in_usage)
             ),
             
             tags$li(
               tags$strong('Cost to Serve: '), tags$span(class = "pull-right", client_cost_to_serve)
             )
    )
  })
  
  
  output$clientDetails3 <- renderUI({
    
    survey_cols=c("PROD_ECOLOGICAL","PROD_FAIRTRADE","PROD_REFORM","NATURE_CHARITY")
    df_survey=input_df[,survey_cols]
    df_survey[ df_survey == 0] <- "No"
    df_survey[ df_survey == 1] <- "Yes"
    df_survey$CUSTOMER_ID=input_df$CUSTOMER_ID
    
    ecological=df_survey[df_survey$CUSTOMER_ID==input$customerid,][[1,"PROD_ECOLOGICAL"]]
    fairtrade=df_survey[df_survey$CUSTOMER_ID==input$customerid,][[1,"PROD_FAIRTRADE"]]
    prod_reform=df_survey[df_survey$CUSTOMER_ID==input$customerid,][[1,"PROD_REFORM"]]
    nature_charity=df_survey[df_survey$CUSTOMER_ID==input$customerid,][[1,"NATURE_CHARITY"]]
    
    
    tags$ul( class = 'list-unstyled',
             
             tags$li(
               tags$strong('Did customer purchase an ecological product?: '), tags$span(class = "pull-right", ecological)
             ),
             tags$li(
               tags$strong('Did customer purchase a fairtrade product?: '),tags$span(class = "pull-right", fairtrade)
             ),
             tags$li(
               tags$strong('Did customer purchase an ethically sourced product?: '), tags$span(class = "pull-right", prod_reform)
             ),

             
             tags$li(
               tags$strong('Does customer make donations to a charity dedicated to preserving nature?: '), tags$span(class = "pull-right", nature_charity)
             )
    )
  })

  output$clientDetails4 <- renderUI({
    
    survey_cols=c("PROD_MEAT_SUBST","GREEN_ENERGY","ENVIR_CHARITY","FREQUENTING_NATURE")
    df_survey=input_df[,survey_cols]
    df_survey[ df_survey == 0] <- "No"
    df_survey[ df_survey == 1] <- "Yes"
    df_survey$CUSTOMER_ID=input_df$CUSTOMER_ID
    
    meat_sub=df_survey[df_survey$CUSTOMER_ID==input$customerid,][[1,"PROD_MEAT_SUBST"]]
    green_energy=df_survey[df_survey$CUSTOMER_ID==input$customerid,][[1,"GREEN_ENERGY"]]
    env_charity=df_survey[df_survey$CUSTOMER_ID==input$customerid,][[1,"ENVIR_CHARITY"]]
    freq_nature=df_survey[df_survey$CUSTOMER_ID==input$customerid,][[1,"FREQUENTING_NATURE"]]
    
    
    tags$ul( class = 'list-unstyled',
             
             tags$li(
               tags$strong('Did customer purchase a meat substitute?: '), tags$span(class = "pull-right", meat_sub)
             ),
             tags$li(
               tags$strong('Does customer believe our utility should offer green energy?: '),tags$span(class = "pull-right", green_energy)
             ),
             
             tags$li(
               tags$strong('Does customer spend time enjoying the outdoors?: '), tags$span(class = "pull-right", freq_nature)
             ),
             tags$li(
               tags$strong('Does customer make donations to a charity dedicated to promoting awareness of environmental issues?: '), tags$span(class = "pull-right", env_charity)
             ),
    )
  })
  
  #refresh page
  observeEvent( input$refresh, {shinyjs::js$refresh()})
  
  #toggle client informations
  observe({
    clientIds <- client_df[["CUSTOMER_ID"]]
    input_btn <- paste0("client-btn-",clientIds)
    lapply(input_btn, function(btn){
      observeEvent(
        input[[btn]],
        {
          #sessionVars$selectedClientId <- id
          
          new_customer_id = substr(btn,12,nchar(btn))
          updateNumericInput(session, "customerid", value = new_customer_id)
          
          shinyjs::toggleElement(paste0("clientInfo-",substr(btn,12,nchar(btn))))
        }
      )
    })
  }, label= "clientButtonObserver", priority = 10)
  
  observe({
    
    shinyjs::enable("scoreBtn")
    
    
    selectedCustomerID <- sessionVars$selectedClientId
    selectedCustomerID <- input$customerid
    
    # Set default hostname for CP4D API
    observeEvent(session$clientData$url_hostname, {
      updateTextInput(session, "hostname", value = session$clientData$url_hostname)
    })
    
    # Reset scoring
    removeUI(selector = "#scoringResponse > *", multiple = TRUE)
    shinyjs::hide(id = "scoringResponse")
    shinyjs::show(id = "scoreBtnSection")
    output$scoringError <- renderText('')
    sessionVars$pipelineInput <- list(values = list(selectedCustomerID))
    output$pipelineInput <- renderText(toJSON(sessionVars$pipelineInput, indent = 2))
    
  })
  
  # Enable buttons when inputs are provided
  observe({
    toggleState("authBtn", nchar(input$hostname) > 0 && nchar(input$username) > 0 && nchar(input$password) > 0)
    toggleState("scoreBtn", nchar(input$endpoint) > 0 && nchar(input$token) > 0 && length(input$allCustomers_rows_selected) > 0)
  })
  
  # Handle ICP4D API authentication button
  observeEvent(input$authBtn, {
    shinyjs::disable("authBtn")
    
    tryCatch({
      deploymentsResp = collectDeployments(input$hostname, input$username, input$password, "utilities_customer_micro_segmentation_scoring_pipeline_function_deployment_tag")
      serverVariables$deployments <- deploymentsResp$deployments
      serverVariables$token = deploymentsResp$token
    }, warning = function(w) {
      output$authError <- renderText(w$message)
    }, error = function(e) {
      output$authError <- renderText(e$message)
    })
    
    shinyjs::enable("authBtn")

    if(length(serverVariables$deployments) > 0) {
      updateSelectInput(session, "deploymentSelector", choices = names(serverVariables$deployments))
      shinyjs::hide(id = "authPanel")
      shinyjs::show(id = "deploymentPanel")
    }
  })
  
  # Handle model deployment dropdown switching
  observeEvent(input$deploymentSelector, {
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    output$deployment_guid <- renderText(selectedDeployment$guid)
    output$space_name <- renderText(selectedDeployment$space_name)
    output$deployment_tags <- renderText(selectedDeployment$tags)
    output$scoring_url <- renderText(selectedDeployment$scoring_url)
    toggleState("scoreBtn", nchar(selectedDeployment$scoring_url) > 0 && nchar(serverVariables$token) > 0)
  })
  
  observeEvent(input$scoreBtn, {
    shinyjs::disable("scoreBtn")
    
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    sessionVars$selectedDeployment <- selectedDeployment
    
    payload <- sessionVars$pipelineInput
    
    response <- scoreModelDeployment(selectedDeployment$scoring_url, payload, serverVariables$token)
    
    if(length(response$error) > 0) {
      output$scoringError <- renderText(toString(response$error))
    } else if (length(response$predictions) > 0) {
      shinyjs::hide(id = "scoreBtnSection")
      shinyjs::show(id = "scoringResponse")
      
      #predicted_prob <- response$predictions[[1]]$values$predictions[[1]]$values[[1]][[2]][[2]]
      
      insertUI(
        selector = "#scoringResponse",
        where = "beforeEnd",
        ui = panel(
          
          h3("Micro segments:"),
          htmlOutput("resultshow")
          #p(
          #  #textOutput("resultshow"),
          #  
          #  br(),
          #  p(plotlyOutput("showresults1",height="250px", width="600px"),
          #    
          #    plotlyOutput("showresults2"))
          #  
          #) 
          
          
        ),
        
      )
      
      output$resultshow <- renderText({
        lifestyle_cluster=response$predictions[[1]]$values$lifestlye[1]
        savings_cluster=response$predictions[[1]]$values$customer_engagement[1]
        
        lifestyle_st <- l_lifestyle_clusters[as.character(lifestyle_cluster)]
        savings_st <- l_engagement_clusters[as.character(savings_cluster)]
        
        str1 <- paste("Lifestyle Segment:","<b>", lifestyle_st, "</b>")
        
        str2 <- paste("<br>Customer Engagement Segment:","<b>", savings_st, "</b>")
        paste(str1,str2)
        
        
      })
      
      
      
    } else {
      output$scoringError <- renderText(response)
    }
    
  })
  output$pipelineInput <- renderText(rjson::toJSON(response$predictions[[1]]$values, indent = 2))
  observeEvent(input$reauthenticateBtn, {
    shinyjs::show(id = "scoreBtnSection")
    removeUI(selector = "#scoringResponse > *", multiple = TRUE)
    shinyjs::show(id = "authPanel")
    shinyjs::hide(id = "deploymentPanel")
    shinyjs::enable("scoreBtn")
  })
  
}



