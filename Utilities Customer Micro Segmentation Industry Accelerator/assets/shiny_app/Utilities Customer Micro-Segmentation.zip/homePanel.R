# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# Â© Copyright IBM Corp. 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

create_savings_data <- function(input_df,cols_savings,bar_clicked_sustain,bar_clicked_savings) {
  df_s1=input_df[,cols_savings]
  if((length(bar_clicked_sustain) == 0)|| (bar_clicked_sustain=="ALL")){
    df_s1=input_df[,cols_savings]
  }else {
    df_s1=subset(input_df, LIFESTYLE_CLUSTER == bar_clicked_sustain) 
    df_s1=df_s1[,cols_savings]
    
  }
  
  if((length(bar_clicked_savings) == 0)|| (bar_clicked_savings=="ALL")){
    plot_df <- df_s1
  }else {
    plot_df <- subset(df_s1, CUSTOMER_ENGAGEMENT == bar_clicked_savings)}
  
  
  
  return(plot_df)
  
}

create_sustain_data <- function(input_df,cols_sustain,bar_clicked_sustain,bar_clicked_savings) {
  
  df_s2=input_df[,cols_sustain]
  if((length(bar_clicked_savings) == 0)|| (bar_clicked_savings=="ALL")){
    df_s2=input_df[,cols_sustain]
  }else {
    df_s2=subset(input_df, CUSTOMER_ENGAGEMENT == bar_clicked_savings) 
    df_s2=df_s2[,cols_sustain]
    
  }
  
  if((length(bar_clicked_sustain) == 0)|| (bar_clicked_sustain=="ALL")){
    plot_df <- df_s2
  }else {
    plot_df <- subset(df_s2, LIFESTYLE_CLUSTER == bar_clicked_sustain)}
  
  
  
  
  
  return(plot_df)
}



getmode_results <- function(d_f){
  temp_df=d_f
  temp_df$LIFESTYLE_CLUSTER=4
  d_f=rbind(d_f,temp_df)
  
  catCols= c()
  k=1
  for(i in 1:ncol(d_f)){
    if(class(d_f[,i])=="factor"){
      catCols[k]=colnames(d_f)[i]
      k=k+
        1
    }
  }
  
  new_df=c()
  
  i=1
  k=1
  while(i <= length(unique(d_f$LIFESTYLE_CLUSTER))){
    
    f<-subset(d_f, LIFESTYLE_CLUSTER==i)
    
    for(j in 1:ncol(f)){
      if(class(f[,j])=="factor"){
        new_df[k] = getmode(f[,j])
        k=k+1
      }
    }
    if(i==1){
      mode_results = new_df
    }
    else{
      mode_results = rbind(mode_results, new_df)
    }
    k=1
    
    i=i+1
  }
  
  mode_results = data.frame(mode_results)
  colnames(mode_results)=catCols
  return(mode_results)
}

getmode <- function(v) {
  v = as.vector(v)
  uniqv <- unique(v)
  if(length(unique(tabulate(match(v, uniqv))))==1){
    return(v)
  }
  else{
    return(uniqv[which.max(tabulate(match(v, uniqv)))])
  }
}




getMinMax <-function(data,cluster)
{
  colMax <- function(data) sapply(data, max, na.rm = TRUE)
  colMin <- function(data) sapply(data, min, na.rm = TRUE)
  
  num_df <- select_if(data, is.numeric)
  num_df$X=NULL
  
  num_df$CUSTOMER_ENGAGEMENT=data$CUSTOMER_ENGAGEMENT
  temp_df <- subset(num_df, CUSTOMER_ENGAGEMENT==cluster)  
  temp_df$CUSTOMER_ENGAGEMENT=NULL
  
  new_df = array(0,dim=c(3,ncol(temp_df)))
  new_df[1,]=colMax(temp_df)
  new_df[2,]=colMin(temp_df)
  new_df[3,]=colMeans(temp_df)
  
  final =data.frame(new_df)
  names(final)=names(temp_df)
  rownames(final)<-c("Maximum","Minimum","Average")
  colnames(final) <- c("Latest Year Energy Usage", "Previous Year Energy Usage", "% Change in Energy Usage", "Cost to Serve ($)")
  
  return(final) 
}
refreshCode <- "shinyjs.refresh = function() { location.reload(); }"


homePanel <- function() {
  
  tabPanel(
    "Model Insights",
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 100% !important;
                      }
                      "))
    ),
    shinyjs::useShinyjs(),
    shinyjs::extendShinyjs(text = refreshCode, functions = c("refresh")),
    
    fluidRow(
      div(id = "Customer Segments",align="center",
          column (4, panel(
            h2("Customer Engagement Segments "),
            htmlOutput("selected_savings"),
            d3Output("d3_Savings"), align = "center"
          ), #panel
          panel(
            h2("Lifestyle Segments"), align = "center",
            htmlOutput("selected_sustain"),
            d3Output("d3_sustain"), align = "center"
            
          )
          
          )
      ),#end of div bubbles
      
      
      div(id = "Segment ",align = "right",
          
          column (4, 
                  div(id = "Plots",
                      panel(h2("Customer Engagement Features"),align = "center",
                            br(),
                            htmlOutput("selected_savings1"),
                            br(),
                            plotOutput('Energy_saving_density', height="250px", width="400px"),
                            br(), 
                            plotOutput('cost_to_serve_Plot', height="250px", width="400px"),
                            br(),
                            plotOutput('energy_saving_Plot', height="250px", width="400px"),
                            
                            
                            
                      )  
                      
                      
                  )#div
                  
                  
          )
          
      ),
      div(id = "Segment ",align = "right",
          
          column (4, panel(h2("Lifestyle  Features"),align = "center",
                           #textOutput("selected"),
                           br(),
                           htmlOutput("selected_sustain1"),
                           br(),
                           plotOutput('NumbQuestionsPlot', height="250px", width="400px"),
                           br(),
                           plotOutput('EducationPlot', height="250px", width="400px"),
                           br(),
                           plotOutput('IncomelevelPlot', height="250px", width="400px")
          )
          )
      ),
      
      
      div(id = "Stats ",
          column(6,
                 h2("Customer Engagement Stats"), align="center",
                 br(),
                 tableOutput('statTable')
          )
      ),
      
      
      # panel
      
      uiOutput("segmentTable"),
      
    ),
    fluidRow(    div(id = "customer ",
                     h3("Customers in selected segments"),
                     br(),
                     column(12,panel(
                       div(id = "Customer table ",
                           DTOutput('featuretable')))#, height="250px", width="400px"),
                     )
    ))
    
    
    
  )
  
  
}


homeServer <- function(input, output, session, sessionVars) {
  
  #refresh page
  observeEvent( input$refresh, {shinyjs::js$refresh()})
  
  
  
  
  
  output$d3_sustain <- renderD3({
    r2d3(data = d_sustain, d3_version = 4, script = "circlepacking.js")
  })
  
  output$d3_Savings <- renderD3({
    r2d3(
      data =d_savings, d3_version = 4, 
      script = "circlepacking_savings.js"
    )
  })
  
  output$selected_savings <- renderText({
    if((input$bar_clicked_savings=="ALL")||(length(input$bar_clicked_savings) == 0)){
      savings_segment="All Segments"
      paste("<b>",savings_segment, "</b>")
    }else{
      # describe the selected cluster
      savings_cluster_desc <- l_engagement_clusters[as.character(input$bar_clicked_savings)]
      
      savings_segment=req(input$bar_clicked_savings)
      
      paste(savings_segment, " : <b>", savings_cluster_desc, "</b>")
    }
  })  
  
  output$selected_savings1 <- renderText({
    if((input$bar_clicked_savings=="ALL")||(length(input$bar_clicked_savings) == 0)){
      savings_cluster_desc="All Segments"
      
    }
    else {
      savings_cluster_desc <- l_engagement_clusters[as.character(input$bar_clicked_savings)]
    }
    
    paste("<b>", savings_cluster_desc, "</b>")
    
  }) 
  
  
  output$selected_sustain <- renderText({
    if((input$bar_clicked_sustain=="ALL")||(length(input$bar_clicked_sustain) == 0)){
      sustain_segment="All Segments"
      paste("<b>",sustain_segment, "</b>")
    } else {
      sus_cluster_desc <- l_lifestyle_clusters[as.character(input$bar_clicked_sustain)]
      
      sustain_segment=req(input$bar_clicked_sustain)
      
      paste(sustain_segment, " : <b>", sus_cluster_desc, "</b>")
    }
    
  })  
  output$selected_sustain1 <- renderText({
    if((input$bar_clicked_sustain=="ALL")||(length(input$bar_clicked_sustain) == 0)){
      sus_cluster_desc="All Segments"
      
    }
    else {
      sus_cluster_desc <- l_lifestyle_clusters[as.character(input$bar_clicked_sustain)]
    }
    
    paste( " <b>", sus_cluster_desc, "</b>")
    
    
  })  
  
  output$selected <- renderText({
    bar_number_sustain <-  req(input$bar_clicked_sustain)
    
    bar_number_savings <- req(input$bar_clicked_savings)
    print(bar_number_savings)
    
    
    if (bar_number_savings > 0) paste("Current Lifestyle segment: ", toString(bar_number_sustain),"Current Customer Engagement segment: ", toString(bar_number_savings))
    
    
  })
  
  output$features <- renderUI({
    if((input$bar_clicked_sustain=="ALL")||(length(input$bar_clicked_sustain) == 0)){
      bar_click_sust=4}
    else{
      bar_click_sust=input$bar_clicked_sustain
    }
    
    temp_df <- topFeatures[4,]
    if(length(input$bar_clicked_sustain) != 0 ) {
      
      temp_df <- topFeatures[strtoi(bar_click_sust),]
    }else{
      temp_df <- topFeatures[4,]
    }
    
    str2 <- paste("")
    
    for(i in 1:ncol(temp_df)){
      
      str1 <- paste("<font color=\"#000000\"><b>",str_replace_all(colnames(temp_df)[i], "[^[:alnum:]]", " ")," : </b></font>","<font color=\"#FF0000\"><b>",temp_df[1,i],"<br /></b></font>")
      str2 <- paste(str2, str1)
    }
    HTML(paste(str2 , sep = '<br/>'))
  })
  
  output$statTable <- renderTable({
    if((is.null(input$bar_clicked_savings)==TRUE)||(input$bar_clicked_savings=="ALL") )
    {
      
      MinMax_df <- getMinMax(df2,"ALL")
    }
    else{
      
      MinMax_df <- getMinMax(df2,input$bar_clicked_savings)
      
    }
    
  }, rownames = TRUE)
  
  output$Energy_saving_density <- renderPlot({
    
    feat1<-create_savings_data(input_df,cols_savings,input$bar_clicked_sustain,input$bar_clicked_savings)
    
    
    plot1 <- ggplot(feat1, aes(x=ENERGY_SAVING))+
      geom_density(color="steelblue", fill="steelblue")+
      labs(x="% Change in Energy Consumption Latest Year", y="") + xlim(-60, 60) + 
      ggtitle("Distribution of Energy Savings") +
      theme_minimal() +
      theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )
    plot1
    
    
  })
  
  
  output$cost_to_serve_Plot <- renderPlot({
    
    
    feat2<-create_savings_data(input_df,cols_savings,input$bar_clicked_sustain,input$bar_clicked_savings)
    plot2 <- ggplot(feat2, aes(x=COST_TO_SERVE))+
      geom_density(color="steelblue", fill="steelblue")+
      labs(x="Cost to Serve ($)", y = "") + xlim(0, 200) + 
      ggtitle("Distribution of Cost to Serve") +
      theme_minimal() +
      theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )
    
    plot2
  })
  
  output$energy_saving_Plot <- renderPlot({
    feat3<-create_savings_data(input_df,cols_savings,input$bar_clicked_sustain,input$bar_clicked_savings)
    
    feat3 <- feat3[,c("TOTAL_USAGE_YEAR1", "TOTAL_USAGE_YEAR2")] 
    
    feat3=colMeans(feat3)
    Usage=as.data.frame(feat3)
    
    plot3 <- ggplot(Usage, aes(x=rownames(Usage),y=feat3)) + 
      geom_bar(aes(x=rownames(Usage),y=feat3),stat = "identity", fill="steelblue",width=0.4)+
      labs(x="Average Annual Energy Usage ", y = "Kwh")+
      ggtitle("Year on Year Average Energy Usage") +
      theme_minimal() +
      theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )
    # theme(axis.title.x = element_text(size = 10))
    
    
    plot3
    
  })
  
  
  
  output$NumbQuestionsPlot <- renderPlot({
    
    plot_df <- create_sustain_data(input_df,cols_sustain,input$bar_clicked_sustain,input$bar_clicked_savings)
    
    
    
    feat4 <- plot_df %>%
      group_by(NUMBER_OF_QUESTIONS_ANSWERED_YES) %>%
      dplyr::select(NUMBER_OF_QUESTIONS_ANSWERED_YES) %>%
      summarize(Count = n()) %>%
      arrange(desc(Count))
    
    feat4 <- as.data.frame(feat4)
    temp_df=data.frame(NUMBER_OF_QUESTIONS_ANSWERED_YES=c(0,1,2,3,4,5,6,7),Count=c(0,0,0,0,0,0,0,0))
    feature4 <- rbind(feat4,temp_df)
    
    feature4 <- feature4 %>%
      group_by(NUMBER_OF_QUESTIONS_ANSWERED_YES) %>%
      summarise(Count = sum(Count)) 
    
    
    feature4$NUMBER_OF_QUESTIONS_ANSWERED_YES <- factor(feature4$NUMBER_OF_QUESTIONS_ANSWERED_YES, levels=c(0,1,2,3,4,5,6,7))
    
    ggplot(data=feature4) +  aes(x=NUMBER_OF_QUESTIONS_ANSWERED_YES, 
                                 y=Count) + 
      geom_bar(stat="identity", width = 0.4, fill = "#73acc6") +
      coord_flip()+
      labs(x="", y="Count") +
      ggtitle("Number of Questions Answered Yes") +
      theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )+
      theme(legend.position="none") 
    
    
  })
  
  output$EducationPlot <- renderPlot({
    
    plot_df <- create_sustain_data(input_df,cols_sustain,input$bar_clicked_sustain,input$bar_clicked_savings)
    
    
    feat5 <- plot_df %>%
      group_by(EDUCATION) %>%
      dplyr::select(EDUCATION) %>%
      summarize(Count = n()) %>%
      arrange(desc(Count))
    
    
    feat5 <- as.data.frame(feat5)
    temp_df=data.frame(EDUCATION=c("Less than 9th grade","Some high school","High school graduate","Some college","Associate degree","Bachelor's degree","Bachelor's degree or more", "Master's degree","Doctoral degree"),Count=c(0,0,0,0,0,0,0,0,0))
    feature5 <- rbind(feat5,temp_df)
    
    feature5 <- feature5 %>%
      group_by(EDUCATION) %>%
      summarise(Count = sum(Count)) 
    
    
    feature5$EDUCATION <- factor(feature5$EDUCATION, levels=c("Less than 9th grade","Some high school","High school graduate","Some college","Associate degree","Bachelor's degree","Bachelor's degree or more", "Master's degree","Doctoral degree"))
    
    
    
    
    ggplot(data=feature5) +  aes(x=EDUCATION, y=Count,
                                 fill=EDUCATION) + 
      geom_bar(stat="identity", width = 0.4, fill = "#73acc6") +
      coord_flip()+
      labs(x=" Education", y="Count") +
      ggtitle("Education Level") +
      theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )+
      theme(legend.position="none")
    
    
  })
  
  output$IncomelevelPlot <- renderPlot({
    
    plot_df <- create_sustain_data(input_df,cols_sustain,input$bar_clicked_sustain,input$bar_clicked_savings)
    
    
    feat6 <- plot_df %>%
      group_by(INCOME_LEVEL) %>%
      dplyr::select(INCOME_LEVEL) %>%
      summarize(Count = n()) %>%
      arrange(desc(Count))
    
    
    
    feat6 <- as.data.frame(feat6)
    temp_df=data.frame(INCOME_LEVEL=c("0-40,000","40,000-55,000","55,000-75,000","75,000-100,000","Above 100,000"),Count=c(0,0,0,0,0))
    feature6 <- rbind(feat6,temp_df)
    
    feature6 <- feature6 %>%
      group_by(INCOME_LEVEL) %>%
      summarise(Count = sum(Count)) 
    
    
    feature6$INCOME_LEVEL <- factor(feature6$INCOME_LEVEL, levels=c("0-40,000","40,000-55,000","55,000-75,000","75,000-100,000","Above 100,000"))
    
    ggplot(data=feature6) +  aes(x=INCOME_LEVEL, y=Count,
                                 fill=INCOME_LEVEL) + 
      geom_bar(stat="identity", width = 0.4, fill = "#73acc6") +
      coord_flip()+
      labs(x=" Income Level", y="Count", title="Income Level") +
      ggtitle("Income Level") +
      theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )+
      theme(legend.position="none")
    
    
  })
  
  output$featuretable <- renderDT({
    
    if(length(input$bar_clicked_savings) != 0){
      bar_clicked_savings=input$bar_clicked_savings
    }else{
      bar_clicked_savings="ALL"
      
    }
    
    if(length(input$bar_clicked_sustain) != 0){
      bar_clicked_sustain=input$bar_clicked_sustain
    }else{
      bar_clicked_sustain="ALL"
      
    }
    
    if((bar_clicked_sustain=="ALL")&&( bar_clicked_savings=="ALL")){
      plot_df <- input_df
    }else if((bar_clicked_sustain=="ALL")&&( bar_clicked_savings!="ALL")){
      plot_df <- subset(input_df,CUSTOMER_ENGAGEMENT==bar_clicked_savings)
    }else if((bar_clicked_sustain!="ALL")&&( bar_clicked_savings=="ALL")){
      plot_df <- subset(input_df,LIFESTYLE_CLUSTER==bar_clicked_sustain)
    }else{
      plot_df <- subset(input_df,(LIFESTYLE_CLUSTER==bar_clicked_sustain)&(CUSTOMER_ENGAGEMENT==bar_clicked_savings))
      
    }
    rownames(input_df)
    filtered_df <- plot_df
    filtered_df$ENERGY_SAVING <- round(filtered_df$ENERGY_SAVING,1)
    filtered_df[,cols_to_display]
    
    
  }, rownames = FALSE,colnames = c('Customer ID', 'Num Questions Answered YES', 'Income Level', 'Education','% Change in Annual Energy Usage','Cost to Serve ($)','Lifestyle Segment','Engagement Segment'),  selection = 'single', server = FALSE, options = list(pageLength = 5)
  )
  
  
  
}

