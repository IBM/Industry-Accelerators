# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2019, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

clientButton <- function(id, name, trigger, image, netWorth, split) {
  tags$p(
    actionButton(paste0('client-btn-', id),
                 fluidRow(
                   column(4, offset=1, 
                          tags$img(src = image, width = "100px", height = "100px", class="img-circle img-responsive")
                   ),
                   column(6,
                          tags$h3(class="text-center",name),
                          tags$h4(class="text-center", paste('Trigger: ', trigger))
                   )),
                 style="width:100%"
    )
  )
}

homePanel <- function() {
  
  tabPanel(
    "Dashboard",
    tags$head(
      tags$style(HTML("
        .datatables {
          width: 100% !important;
        }
      "))
    ),
    shinyjs::useShinyjs(),
    
    fluidRow(
      column(5, panel(
        tags$h2("Top Action Clients"),
        tags$br(),
        lapply(clientIds, function(id){
          client <- clients[[toString(id)]]
          clientButton(id, client$name, client$trigger, 
                       paste0("profiles/", client$image), client$netWorth, client$split)
        })
      ),
      panel(
        h2("Recent Life Events"),
        br(),
        panel(class = "panel-heading text-center", 
            p(span(class="pull-left",strong("Client name")), span(strong("Event")), span(class="pull-right", strong("Likelihood")))      
          ),
        lapply(1:dim(lfeEv)[1], function(index) {
          event <- lfeEv[index,]
          #date <- format(event$EVENT_DATE, format = "%b %d, %Y")
          panel(
            #column(3,
              #img(src = paste0("profiles/", event$CUSTOMER_IMAGE), width = "100px", height = "100px", class="img-circle img-responsive")
           # ),
            column(3,
              br(),
              h4(class = "text-center", event$CLIENT_NAME)      
            ),
            column(5, offset = 2,
              br(),
              p(strong(event$LIFE_EVENT))
             
            ),
            column(2, class = "pull-right",
              br(),
              p(strong(event$LIKELIHOOD))
            )
          )
        })
      )),
      column(7, 
         panel(
           h2("Revenue Opportunities"),
           br(),
           lapply(1:dim(revOpp)[1], function(index) {
             opportunity <- revOpp[index,]
             panel(
               column(6,
                      h3(class = "text-center", opportunity$OPPORTUNITY)      
               ),
               column(4, offset = 2, class = "pull-right",
                      br(),
                      p(span( style = "color:#0099CC", strong(opportunity$CLIENT, " clients")),
                        if(!is.na(opportunity$NEW_CLIENT)) {
                          span(class="pull-right", style = "color:#007E33",strong("*",opportunity$NEW_CLIENT, " clients added"))
                        })
                      
               )
             )
           })
         ),
         panel(
           tags$h2("Market News"),
           tags$br(),
           apply(news, 1, function(article){
             panel(
               h4(article[6]),
               p(paste0(substring(article[7], 0, 400), '...')),
               a(article[5], icon("external-link"), href = article[5], target = "_blank")
             )
           })
         )
      )
    )
  )
}

# Transform events for display on dashboard
# displayEvents <- tail(events, 1000)
# displayEvents <- displayEvents[sample(nrow(displayEvents), 100),]
# displayEvents <- displayEvents[seq(dim(displayEvents)[1],1),]
# displayEvents <- merge(event_types, displayEvents, by="EVENT_TYPE_ID")
# displayEvents <- displayEvents[,c("CUSTOMER_ID", "EVENT_DATE", "NAME", "CATEGORY")]

# Get the Life Events of the known customers
knownCustomer <- customer %>% filter(CUSTOMER_ID %in% clientIds)
allLifeEvents <- merge(events, event_types, by="EVENT_TYPE_ID")
allLifeEvents <- allLifeEvents[allLifeEvents$CATEGORY == "Life",]
knownCustomerEvents <- allLifeEvents %>% filter(CUSTOMER_ID %in% clientIds)
knownCustomerEvents <- merge(knownCustomerEvents, knownCustomer, by="CUSTOMER_ID")
knownCustomerEvents <- knownCustomerEvents[,c("CUSTOMER_ID", "EVENT_DATE","NAME", "CATEGORY", "STATUS")]
knownCustomerEvents <- knownCustomerEvents[knownCustomerEvents$STATUS == "Active",]
knownCustomerEvents <- knownCustomerEvents %>% count(CUSTOMER_ID, EVENT_DATE, NAME, CATEGORY, STATUS)
clientInfo <- cbind(clientIds, data.frame(matrix(unlist(clients), nrow=5, byrow=T),stringsAsFactors=FALSE))
names(clientInfo) <- c("CUSTOMER_ID", "CUSTOMER_NAME", "CUSTOMER_IMAGE", "CUSTOMER_TRIGGER", "CUSTOMER_INCOME","CUSTOMER_NETWORTH", "SPLIT")
knownCustomerEvents <- merge(clientInfo, knownCustomerEvents, by="CUSTOMER_ID")
knownCustomerEvents <- knownCustomerEvents[order(as.Date(knownCustomerEvents$EVENT_DATE, format="%Y-%m-%d"), decreasing = TRUE),]

# Get the Opportunities (Pursuit) of the known customer
knownCustomerPursuit <- knownCustomer[,c("CUSTOMER_ID", "PURSUIT")] %>% count(PURSUIT)

# Static data for Revenue Opportunities
Opp <- c("Financial Planning", "Retirement Planning", "Securities-Based Loan", "Mortgage")
client <- c(12,8,7,3)
addedClient <- c(5,4,2,NA)
revOpp <- data.frame(OPPORTUNITY = Opp, CLIENT = client, NEW_CLIENT = addedClient)

# Static data for Life Events
clientName <- c("Elizabeth Soccoro", "Mike Smith", "Don Marcos", "Wilson Ma", "April Fan", "Peter Jose")
lifeEvent <- c("Birth of a child", "Marriage", "New home purchase", "New job", "Relocation", "Retirement")
likelihood <- c("High","High","High","Med","Med","Med")
lfeEv <- data.frame(CLIENT_NAME = clientName, LIFE_EVENT = lifeEvent, LIKELIHOOD = likelihood)


revenueOppsData <- data.frame(eventType = c("Financial Planning", "Retirement Planning", "Securities-Base Loan", "Mortgage"),
                              value = c(12, 8, 7, 3)) %>% mutate(
    percentage = value / sum(value),
    hover_text = paste0(eventType, ": ", round(100 * percentage, 1), "%")
  )
revenueOppsPlot <- ggplot(revenueOppsData, aes(y = value, fill = eventType)) +
  geom_bar(
    aes(x = 1),
    stat = "identity",
    show.legend = TRUE
  ) + 
  scale_fill_manual(values = c("House Sell" = "purple", "Equity Buy" = "skyblue", 
                               "New Sec Account Open" = "yellow", "Other" = "blue")) +
  coord_polar(theta = "y") +
  theme_void() +
  theme(legend.title=element_text(size=16), 
        legend.text=element_text(size=12))
revenueOppsPlot <- revenueOppsPlot + guides(fill=guide_legend(title="Opportunities"))

homeServer <- function(input, output, session, sessionVars) {
  
  # Table displays for Life Event Prediction Dashboard
  #output$recentEvents <- renderDT(displayEvents, rownames = FALSE, style = 'bootstrap')
  
  # Observation events for client buttons
  lapply(paste0('client-btn-', clientIds),
         function(x){
           observeEvent(
             input[[x]],
             {
               id <- as.numeric(sub("client-btn-", "", x))
               sessionVars$selectedClientId <- id
               updateTabsetPanel(session, "lfeNav", selected = "clientPanel")
             }
           )
         })
  
  # Render pie chart of revenue opportunities
  output$revenueOppsPie <- renderPlot(revenueOppsPlot, width="auto", height="auto")
}
