# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2019. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.


clientButton <- function(id, name, image, income) {
  tags$p(
    actionButton(paste0('client-btn-', id),
                 fluidRow(
                   column(3, 
                          tags$img(src = image, width = "60px", height = "60px")
                   ),
                   column(9, align = "right",
                          tags$h6(name),
                          tags$h6(paste('Customer ID: ', id)),
                          tags$h6(paste('Income: ', income))
                          
                   )
                 ),
                 style="width:100%"
    )
  )
}


homePanel <- function() {
  
  tabPanel(
    "Dashboard",
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 100% !important;
                      }
                      "))
      ),
    shinyjs::useShinyjs(),
    
    
    fluidRow(
      
      
      div(id = "Plots",
          column(12, panel(
            h2("DYNAMIC FEATURES OF CUSTOMER SEGMENTS"),align = "center", br(),
            
            column(3, ggiraphOutput("pursuitPlot", width = "400px", height = "400px")),
            column(3, ggiraphOutput("behavePlot", width = "400px", height = "400px")),
            column(3, ggiraphOutput("spendPlot", width = "400px", height = "400px")),
            column(3, ggiraphOutput("marketPlot", width = "400px", height = "400px"))
            #column(3, h6("Graph 5"), ggiraphOutput("cusBehavePlot", width = "400px", height = "400px"))
            # column(2, h6("Graph 6"))
          )         
          )
      ),
      
      
      
      
      div(id = "topActionClients",
          column(2, panel(
            h3("Top Action Clients"),
            br(),
            
            # List of client buttons
            lapply(clientIds, function(id){
              client <- clients[[toString(id)]]
              clientButton(id, client$name, paste0("profiles/", client$image), client$income)
            })
            
          ))),
      
      div(id = "Customer Segments",
          column (6,panel(
            h2("CURRENT CUSTOMER SEGMENTS "),
            
            ggiraphOutput("segmentsPlot", width = "700px", height = "500px")
            #plotOutput("segmentsPlot", width = "700px", height = "700px",click = "plotclick")
          ) #panel
          ) # column
      ),#end of div bubbles
      
      
      div(id = "Segment ",align = "right",
          column (4,panel(
            h2("TOP SEGMENT STATS "),
            br(),
            
            column(12, radioButtons("radio", label = h4("Choose Segment for top stats"),
                                    choices = sort(data$CLUSTERS+1),
                                    inline = TRUE,selected = 1)
            ),
            column(12, h4("Most likely features of the segment"), htmlOutput("features")
                   
            )
            
            
          )#panel
          ) # column
      ),#end of div stats
      
      
      
      
      
      div(id = "rightPanel",
          column(8, 
                 panel(
                   
                   h2("Customer Segmentation"),
                   br(),
                   
                   tags$div(
                     id = "authPanel",
                     column(6,
                            panel(
                              h4("Connect to ICP for Data API"),
                              br(),
                              textInput("hostname", "ICP4D Hostname"),
                              textInput("username", "ICP4D Username"),
                              passwordInput("password", "ICP4D Password"),
                              actionButton("authBtn", "Authenticate API", class = "btn-primary btn-lg btn-block", style = "max-width:300px", disabled = TRUE),
                              tags$head(tags$style("#authError{color:red;}")),
                              verbatimTextOutput("authError")
                            ),
                            style = "max-width:360px;"
                     )
                   ),
                   
                   hidden(
                     tags$div(
                       id = "deploymentPanel",
                       
                       panel(
                         
                         fluidRow(
                           column(6,
                                  tags$div(id = "scoreBtnSection",
                                           h4("Input JSON:"),
                                           verbatimTextOutput("pipelineInput"),
                                           br(),
                                           actionButton(
                                             "scoreBtn",
                                             "Segment Customers",
                                             class = "btn-primary btn-lg btn-block",
                                             disabled = TRUE
                                           ),
                                           tags$head(tags$style("#scoringError{color:red;}")),
                                           verbatimTextOutput("scoringError")
                                  )),
                           column(6,
                                  
                                  tags$h4("Model Scoring Pipeline Deployment"),
                                  pickerInput(
                                    inputId = 'deploymentSelector',
                                    label = 'Deployment Name:',
                                    choices = list(),
                                    options = pickerOptions(width = "auto", style = "btn-primary")
                                  ),
                                  tags$p(
                                    tags$strong("Scoring URL: "),
                                    textOutput(outputId = "scoring_url", inline = TRUE),
                                    style = "word-wrap: break-word"
                                  ),
                                  tags$p(
                                    tags$strong("Project Release: "),
                                    textOutput(outputId = "release_name", inline = TRUE)
                                  ),
                                  tags$p(
                                    tags$strong("Script Name: "),
                                    textOutput(outputId = "script_name", inline = TRUE)
                                  ),
                                  tags$p(
                                    tags$strong("Engine: "),
                                    textOutput(outputId = "runtime", inline = TRUE)
                                  )
                           )
                         )))),
                   tags$div(id = "scoringResponse")
                 )
          ))),
    div(id = "clientAssignments")
      )
  }



#BUBBLEPLOT

getmode <- function(v) {
  v = as.vector(v)
  uniqv <- unique(v)
  if(length(unique(tabulate(match(v, uniqv))))==1){
    return(v)
  }
  else{
    return(uniqv[which.max(tabulate(match(v, uniqv)))])
  }
}

getmode_results <- function(d_f){
  
  
  #class(d_f[,2])=="factor"
  
  #length(unique(df$CLUSTERS))
  #ncol(df)
  #Finding categorical column names
  
  catCols= c()
  k=1
  for(i in 1:ncol(d_f)){
    if(class(d_f[,i])=="factor"){
      catCols[k]=colnames(d_f)[i]
      k=k+1
    }
  }
  #catCols
  new_df=c()
  #i=5
  
  i=length(unique(d_f$CLUSTERS))
  k=1
  while(i >= 0){
    #print(i)
    f<-subset(d_f, CLUSTERS==i)
    
    for(j in 1:ncol(f)){
      if(class(f[,j])=="factor"){
        new_df[k] = getmode(f[,j])
        k=k+1
      }
    }
    if(i==length(unique(d_f$CLUSTERS))){
      mode_results = new_df
    }
    mode_results = rbind(mode_results, new_df)
    k=1
    i=i-1
    
  }
  
  mode_results = data.frame(mode_results)
  colnames(mode_results)=catCols
  return(mode_results)
}

df <- cluster_df
df$X1 <- NULL


topFeatures <- getmode_results(df)

data1 <- head(df %>%
                group_by(CLUSTERS) %>%
                dplyr::select(CLUSTERS) %>%
                summarize(Count = n()) %>%
                arrange(desc(Count)))


# Generate the layout. This function return a dataframe with one line per bubble. 
# It gives its center (x and y) and its radius, proportional of the value
packing <- circleProgressiveLayout(data1$Count, sizetype='area')

# We can add these packing information to the initial data frame
data = cbind(data1, packing)
group=paste("Segment", data$CLUSTERS+1)
# Check that radius is proportional to value. We don't want a linear relationship, since it is the AREA that must be proportionnal to the value
plot(data$radius, data$Count)

# The next step is to go from one center + a radius to the coordinates of a circle that
# is drawn by a multitude of straight lines.
dat.gg <- circleLayoutVertices(packing, npoints=50)


segments <- ggplot() + 
  
  # Make the bubbles
  geom_polygon(data = dat.gg, aes(x, y, group = id, fill=as.factor(id)), colour = "black", alpha = 0.9) +
  
  # Add text in the center of each bubble + control its size
  geom_text(size = 5,data = data, aes(x, y, size=Count, label = group)) +
  scale_size_continuous(range = c(1,4)) +
  
  # General theme:
  theme_void() +  theme(legend.position="none") +
  coord_equal()


#----------------END OF PLOT 1


# server variables (reactive)
serverVariables = reactiveValues()

pipelineInput <- list(cust_ids = as.list(clientIds), dataset_name = 'customer_full_summary_latest.csv', sc_end_date = '2018-09-30')

homeServer <- function(input, output, session, sessionVars) {
  
  
  output$rbselect <- renderText({paste(input$radio)}) #radio button
  # top features
  
  output$features <- renderUI({
    temp_df <- topFeatures[input$radio,]
    
    str2 <- paste("")
    
    for(i in 1:ncol(temp_df)){
      str1 <- paste("<font color=\"#000000\"><b>",colnames(temp_df)[i]," : </b></font>","<font color=\"#FA8072\"><b>",temp_df[1,i],"<br /></b></font>")
      str2 <- paste(str2, str1)
    }
    HTML(paste(str2 , sep = '<br/>'))
  })
  
  output$segmentsPlot <- renderggiraph(ggiraph(ggobj = segments, width_svg=7, height_svg=7))  
  
  output$pursuitPlot <- renderggiraph({ plot_df <- subset(df, CLUSTERS+1 == (input$radio))
  
  feat1 <- plot_df %>%
    group_by(CUSTOMER_PURSUIT) %>%
    dplyr::select(CUSTOMER_PURSUIT) %>%
    summarize(Count = n()) %>%
    arrange(desc(Count))
  
  plot1 <- ggplot(data=feat1) + aes(x=reorder(feat1$CUSTOMER_PURSUIT, - feat1$Count), y=feat1$Count,
                                    fill=feat1$CUSTOMER_PURSUIT) +
    geom_bar(stat="identity", width = 0.4) +
    coord_flip()+
    labs(x=" Choice of Pursuit", y="Count", title="Customer Financial Pursuit") +
    theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )+
    theme(legend.position="none")
  
  ggiraph(ggobj = plot1, width_svg=4, height_svg=4)
  
  })
  
  output$behavePlot <- renderggiraph({plot_df <- subset(df, CLUSTERS+1 == input$radio)
  
  feat2 <- plot_df %>%
    group_by(CUSTOMER_CUSTOMER_BEHAVIOR) %>%
    dplyr::select(CUSTOMER_CUSTOMER_BEHAVIOR) %>%
    summarize(Count = n()) %>%
    arrange(desc(Count))
  
  plot2 <- ggplot(data=feat2) + aes(x=reorder(feat2$CUSTOMER_CUSTOMER_BEHAVIOR, - feat2$Count), y=feat2$Count,
                                    fill=feat2$CUSTOMER_CUSTOMER_BEHAVIOR) +
    geom_bar(stat="identity", width = 0.4) +
    coord_flip()+
    labs(x=" Type of Behavior", y="Count", title="Customer Behaviour Analysis") +
    theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )+
    theme(legend.position="none")
  
  
  ggiraph(ggobj = plot2, width_svg=4, height_svg=4)
  
  })
  
  output$spendPlot <-  renderggiraph({plot_df <- subset(df, CLUSTERS+1 == input$radio)
  
  feat3 <- plot_df %>%
    group_by(CUSTOMER_SUMMARY_TOP_SPENDING_CATEGORY) %>%
    dplyr::select(CUSTOMER_SUMMARY_TOP_SPENDING_CATEGORY) %>%
    summarize(Count = n()) %>%
    arrange(desc(Count))
  
  plot3 <- ggplot(data=feat3) + aes(x=reorder(feat3$CUSTOMER_SUMMARY_TOP_SPENDING_CATEGORY, - feat3$Count), y=feat3$Count,
                                    fill=feat3$CUSTOMER_SUMMARY_TOP_SPENDING_CATEGORY) +
    geom_bar(stat="identity", width = 0.4) +
    coord_flip()+
    labs(x=" Customer Expenses", y="Count", title="Top Customer Expenditure") +
    theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )+
    theme(legend.position="none")
  
  
  ggiraph(ggobj = plot3, width_svg=4, height_svg=4)
  
  })
  output$marketPlot <-  renderggiraph({plot_df <- subset(df, CLUSTERS+1 == input$radio)
  
  feat4 <- plot_df %>%
    group_by(CUSTOMER_MARKET_GROUP) %>%
    dplyr::select(CUSTOMER_MARKET_GROUP) %>%
    summarize(Count = n()) %>%
    arrange(desc(Count))
  
  plot4 <- ggplot(data=feat4) + aes(x=reorder(feat4$CUSTOMER_MARKET_GROUP, - feat4$Count), y=feat4$Count,
                                    fill=feat4$CUSTOMER_MARKET_GROUP) +
    geom_bar(stat="identity", width = 0.4) +
    coord_flip()+
    labs(x=" Group Type", y="Count", title="Customer Market Group") +
    theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )+
    theme(legend.position="none")
  
  
  ggiraph(ggobj = plot4, width_svg=4, height_svg=4)
  
  })
  
  
  sessionVariables = reactiveValues()
  
  # Set default hostname for ICP4D API
  observeEvent(session$clientData$url_hostname, {
    updateTextInput(session, "hostname", value = session$clientData$url_hostname)
  })
  
  # Enable buttons when inputs are provided
  observe({
    toggleState("authBtn", nchar(input$hostname) > 0 && nchar(input$username) > 0 && nchar(input$password) > 0)
    toggleState("scoreBtn", nchar(input$endpoint) > 0 && nchar(input$token) > 0 && length(input$allCustomers_rows_selected) > 0)
  })
  
  # Handle ICP4D API authentication button
  observeEvent(input$authBtn, {
    shinyjs::disable("authBtn")
    
    tryCatch({
      serverVariables$deployments <- collectDeployments(input$hostname, input$username, input$password, "Segmentation_Scoring_Pipeline.py")
    }, warning = function(w) {
      output$authError <- renderText(w$message)
    }, error = function(e) {
      output$authError <- renderText(e$message)
    })
    
    shinyjs::enable("authBtn")
  })
  
  observe({
    if(length(serverVariables$deployments) > 0) {
      updateSelectInput(session, "deploymentSelector", choices = names(serverVariables$deployments))
      shinyjs::hide(id = "authPanel")
      shinyjs::show(id = "deploymentPanel")
    }
  })
  
  # Handle model deployment dropdown switching
  observeEvent(input$deploymentSelector, {
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    output$release_name <- renderText(selectedDeployment$release_name)
    output$scoring_url <- renderText(selectedDeployment$scoring_url)
    output$script_name <- renderText(selectedDeployment$deployment_asset_name)
    output$runtime <- renderText(selectedDeployment$runtime_definition_name)
    toggleState("scoreBtn", nchar(selectedDeployment$deployment_url) > 0 && nchar(selectedDeployment$deployment_token) > 0)
  })
  
  # Handle model deployment scoring button
  observeEvent(input$scoreBtn, {
    shinyjs::disable("scoreBtn")
    
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    
    response <- scoreModelDeployment(selectedDeployment$scoring_url, selectedDeployment$deployment_token, pipelineInput)
    
    if(length(response$error) > 0) {
      output$scoringError <- renderText(toString(response$error))
    }
    else if(length(response$result) > 0) {
      shinyjs::hide(id = "deploymentPanel")
      
      sessionVariables$clusterMapping <- response$result$assigments
      clusterFeatures <- response$result$features
      
      names(sessionVariables$clusterMapping) <- pipelineInput$cust_ids
      
      # Generate table of cluster mapping
      df <- data.frame(clusterID=t(t(sessionVariables$clusterMapping)))
      names(df) <- c("Segment ID")
      clusterMappingTable <- tibble::rownames_to_column(df, "Customer ID") %>%
        mutate_all(as.integer)
      
      # Generate tables of cluster features
      sessionVariables$featureTables <- list()
      for(clusterID in names(clusterFeatures)) {
        cluster <- clusterFeatures[[clusterID]]
        clusterTable <- list()
        for(feature in names(cluster)) {
          newFeatureName <- sub("CUSTOMER_", "", feature)
          newFeatureName <- sub("SUMMARY_", "", newFeatureName)
          clusterTable[[feature]] <- list(feature=newFeatureName, min=cluster[[feature]]$min, max=cluster[[feature]]$max)
        }
        sessionVariables$featureTables[[clusterID]] <- do.call(rbind.data.frame, clusterTable) %>%
          mutate_at(vars(min, max), funs(ifelse(grepl("NUMBER|MONTHS",feature), as.integer(.), dollar(.)))) %>%
          mutate(feature=sub("NUMBER_OF_|TOTAL_AMOUNT_OF_", "", feature))
        names(sessionVariables$featureTables[[clusterID]]) <- c("Feature", "Min", "Max")
      }
      
      insertUI(
        selector = "#scoringResponse",
        where = "beforeEnd",
        ui = panel(
          h3("Segment Assignments:"),
          br(),
          div(id = "assignTableContainer",
              fluidRow(
                column(4,
                       tableOutput("clusterMapping")
                ),
                column(8,
                       actionBttn("vizAssign", "Visualize Segments"),
                       br(),br(),
                       h3("Segment Features:"),
                       lapply(names(sessionVariables$featureTables), function(id){
                         div(
                           h4(paste("Segment",id), style="text-align:center"),
                           tableOutput(paste0("features-",id))
                         )
                       })
                )
              )
          )
        )
      )
      
      lapply(names(sessionVariables$featureTables), function(id){
        output[[paste0("features-",id)]] <- renderTable(sessionVariables$featureTables[[id]], bordered = TRUE)
      })
      
      output$clusterMapping <- renderTable(clusterMappingTable, bordered = TRUE)
      
    } else {
      output$scoringError <- renderText(response)
    }
    
    shinyjs::enable("scoreBtn")
  })
  
  observeEvent(input$vizAssign, {
    
    clusters = list()
    for(custID in names(sessionVariables$clusterMapping)){
      clusterID <- sessionVariables$clusterMapping[custID]
      clusters[[toString(clusterID)]] <- c(clusters[[toString(clusterID)]], custID)
    }
    
    removeUI("#topActionClients")
    shinyjs::hide(id = "rightPanel")
    
    insertUI(
      selector = "#clientAssignments",
      where = "beforeEnd",
      ui = panel(
        h2("Top Action Clients"),
        br(),
        h3("Client Segments:"),
        fluidRow(
          lapply(names(clusters), function(clusterID) { 
            column(4, 
                   panel(
                     h3(paste("Segment",clusterID), style = "text-align:center"),
                     tableOutput(paste0("features2-",clusterID)),
                     lapply(clusters[[clusterID]], function(custID) {
                       client <- clients[[custID]]
                       clientButton(id, client$name,paste0("profiles/", client$image), client$income)
                     })
                   )
            )
          })
        )
      )
    )
    
    lapply(names(sessionVariables$featureTables), function(id){
      output[[paste0("features2-",id)]] <- renderTable(sessionVariables$featureTables[[id]], bordered = TRUE, width = "100%")
    })
    
  })
  
  output$pipelineInput <- renderText(toJSON(pipelineInput, indent = 2))
  
}
