# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.


# function to create buttons for each client

#install.packages("echarts4r")
#library(echarts4r)
#
#e_
#e_charts() %>% 
#  e_gauge(0.5, "Efficiency",min=0,max=1, center = c("30%", "60%"), radius = "60%")  %>%  e_tooltip()

clientButton <- function(id, name, contract, image) {
  
  tags$p(
    actionButton(paste0('client-btn-', id),
                 fluidRow(
                   column(4, 
                          tags$img(class = "pull-left", src = image, width = "60px", height = "60px")
                   ),
                   column(3,
                          tags$h4(strong(name)),
                          tags$h6(em(paste('Customer ID: ', id))),
                          tags$h6(em(paste('Contract: ', contract)))
                   )
                 ),
                 style="width:100%"
    )
  )
}



clientPanel <- function() {
  
  tabPanel(
    "Client View",
    value = "clientPanel",
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 90% !important;
                      }
                      .html-widget.gauge svg {
                        height: 300px;
                        width: 600px;
                      }
                      "))
    ),
    shinyjs::useShinyjs(),
    
    fluidRow(
      div( id = "topActionClients",
           column(3, class = "pull-left",
                  panel(
                    span(align = "center", h2("Top Action Clients")),
                    span(align = "center", h5("Click on Client for further information or Enter customer id in the box")),
                    br(),
                    uiOutput("topClients"),
                    
                  )
                  
           )
      ),
      
      tags$div(
        id = "clientInfoPanel",
        column(9,class="pull-right",
               fluidRow(
                 fluidRow(
                   column(1,
                          
                   ),
                   column(6,class="pull-left",
                          span(align = "left", h4("Customer ID")),
                          
                          numericInput("customerid", 
                                       
                                       h6("Enter Customer ID between 1 and 75000 or select from top action clients "), 
                                       value = 1,min=1,max=75000))
                 ),
                 column(4,
                        panel(
                          
                          span(align = "center", h3("Client Information")),
                          br(),
                          uiOutput("clientInfo1"),
                          uiOutput("clientInfo2")),
                        
                 ),
                 column(1,
                        br()),
                 column(4,
                        panel(
                          span(align = "center", h3("Client Retail Information")),
                          br(),
                          uiOutput("clientRetailInfo1"),
                          uiOutput("clientRetailInfo2"))
                 )
               ),
               fluidRow(
                 column(5,
                        panel(
                          h3("Clients last 5 years usage"),
                          br(),
                          plotOutput("usageyear")
                        )
                 ),
                   tags$div(
                     id = "predictionPanel",
                     column(5,
                            panel(
                              tags$h3("Client Attrition Prediction "),
                              br(),
                              br(),
                              br(),
                              br(),
                              
                              
                              
                              p(
                                gaugeOutput("gaugePrediction")
                              )
                              ,br(),
                              br(),
                              br()
                              
                            )))
                 
                 
                 
                 
               )
        )
      )
      
      
    )
  )
  
}


# Reactive server variables store (pervades across all sessions)
serverVariables = reactiveValues(deployments = list(), token = '')

if(nchar(Sys.getenv('CP4D_HOSTNAME')) > 0 && nchar(Sys.getenv('CP4D_USERNAME')) > 0 && nchar(Sys.getenv('CP4D_PASSWORD')) > 0) {
  tryCatch({
    deploymentsResp = collectDeployments(Sys.getenv('CP4D_HOSTNAME'), Sys.getenv('CP4D_USERNAME'), Sys.getenv('CP4D_PASSWORD'), "WOS-INTERNAL","Utilities Customer Attrition Model Deployment")
    
    serverVariables$deployments <- deploymentsResp$deployments
    serverVariables$token = deploymentsResp$token
  }, warning = function(w) {
    print(w$message)
  }, error = function(e) {
    print(e$message)
  })
}

clientServer <- function(input, output, session, sessionVars) {

  
  # create the button for clients
  output$topClients <- renderUI({
    
    
    
    # List of client buttons
    lapply(clients, function(client){
      client_contract <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "CURRENT_CONTRACT"]
      clientButton(client$clientId, client$name, client_contract, paste0("profiles/", client$image))
    })
    
  })
  
  
  # Observation events for client buttons
  lapply(clients,
         function(client){
           x <- paste0('client-btn-', client$clientId)
           observeEvent(
             input[[x]],
             {
               new_customer_id = substr(x,12,nchar(x))
               updateNumericInput(session, "customerid", value = new_customer_id)
               
               
               sessionVars$selectedClientId <- client$clientId
               
               updateNumericInput(session, "customerid", value = new_customer_id)
               shinyjs::toggleElement(paste0("clientInfo-",substr(x,12,nchar(x))))
               
               

               
               shinyjs::show(id = "clientInfoPanel")
             })
         })
  
  
  
  output$clientInfo1 <- renderUI({
    i_customer_id=input$customerid
    client_name <- paste(df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "FIRST_NAME"],df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "LAST_NAME"])
    client_id <- i_customer_id
    client_age <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "AGE"]
    client_segment <- str_to_title(df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "SEGMENT"])
    client_city <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "CITY"] 
    tags$ul( class = 'list-unstyled',
             tags$li(
               tags$strong('Name: '), tags$span(class = "pull-right", client_name)
             ),
             tags$li(
               tags$strong('ID: '), tags$span(class = "pull-right", client_id)
             ),
             tags$li(
               tags$strong('Segment: '), tags$span(class = "pull-right", client_segment)
             ),
             tags$li(
               tags$strong('Age: '),tags$span(class = "pull-right", client_age)
             ),
             tags$li(
               tags$strong('City: '), tags$span(class = "pull-right", client_city)
             )
    )
  })
  
  output$clientInfo2 <- renderUI({
    
    i_customer_id=input$customerid
    client_employment <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "EMPLOYMENT"] 
    client_tenure <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "TENURE"] 
    client_complaints <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "COMPLAINTS"] 
    client_complaints<- gsub(1, "Yes", client_complaints)
    client_complaints<- gsub(0, "No", client_complaints)
    client_energy_usage <- round(df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "ENERGY_USAGE_PER_MONTH"])
    client_energy_efficiency <- round(df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "ENERGY_EFFICIENCY"], 2)
    
    tags$ul( class = 'list-unstyled',
             tags$li(
               tags$strong('Employment Status: '), tags$span(class = "pull-right", client_employment)
             ),
             tags$li(
               tags$strong('Tenure: '), tags$span(class = "pull-right", client_tenure, " Months")
             ),
             tags$li(
               tags$strong('Previously Made Complaint: '),tags$span(class = "pull-right", client_complaints)
             ),
             tags$li(
               tags$strong('Average Monthly Energy Usage: '), tags$span(class = "pull-right", client_energy_usage, "KWh")
             ),
             tags$li(
               tags$strong('Energy Efficiency: '), tags$span(class = "pull-right", client_energy_efficiency)
             )
    )
  })
  
  
  output$clientRetailInfo1 <- renderUI({
    i_customer_id=input$customerid
    client_home_owner <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "OWNS_HOME"]
    client_home_owner<- gsub(1, "Yes", client_home_owner)
    client_home_owner<- gsub(0, "No", client_home_owner)
    client_has_thermostat <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "HAS_THERMOSTAT"]
    client_has_thermostat<- gsub(1, "Yes", client_has_thermostat)
    client_has_thermostat<- gsub(0, "No", client_has_thermostat)               
    client_has_home_automation <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "HAS_HOME_AUTOMATION"]
    client_has_home_automation<- gsub(1, "Yes", client_has_home_automation)
    client_has_home_automation<- gsub(0, "No", client_has_home_automation)               
    client_smart_meter_comments <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "SMART_METER_COMMENTS"]
    client_car_owner <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "IS_CAR_OWNER"]
    client_car_owner<- gsub(1, "Yes", client_car_owner)
    client_car_owner<- gsub(0, "No", client_car_owner)     
    client_has_ev <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "HAS_EV"]
    client_has_ev<- gsub(1, "Yes", client_has_ev)
    client_has_ev<- gsub(0, "No", client_has_ev) 
    
    
    # if the customer has an electric vehicle they must be a car owner
    if (client_has_ev==1) {
      client_car_owner <- "Yes"
    }
    
    if (client_car_owner==0) {
      client_has_ev <- "NA"
    }
    
    tags$ul( class = 'list-unstyled',
             tags$li(
               tags$strong('Home Owner: '), tags$span(class = "pull-right", client_home_owner)
             ),
             tags$li(
               tags$strong('Smart Meter Comments: '),tags$span(class = "pull-right", client_smart_meter_comments)
             ),
             tags$li(
               tags$strong('Thermostat Installed: '), tags$span(class = "pull-right", client_has_thermostat)
             ),
             tags$li(
               tags$strong('Home Automation: '), tags$span(class = "pull-right", client_has_home_automation)
             ),
             tags$li(
               tags$strong('   ')
             ),
             tags$li(
               tags$strong('Owns Vehicle: '), tags$span(class = "pull-right", client_car_owner)
             )
    )
  })
  
  output$usageyear <- renderPlot({
    i_customer_id=input$customerid
    df_plot=df_unseen[df_unseen$CUSTOMER_ID==i_customer_id,]
    usagecols=c( "STD_YRLY_USAGE_CUR_YEAR_MINUS_5","STD_YRLY_USAGE_CUR_YEAR_MINUS_4","STD_YRLY_USAGE_CUR_YEAR_MINUS_3","STD_YRLY_USAGE_CUR_YEAR_MINUS_2","STD_YRLY_USAGE_CUR_YEAR_MINUS_1")
    df_plot=df_plot[usagecols]
    df_plot=as.data.frame(t(as.data.frame(df_plot)))
    
    names(df_plot)="USAGE"
    Usage=c(df_plot$USAGE)
    year=c( "CURRENT_YEAR-5","CURRENT_YEAR-4","CURRENT_YEAR-3","CURRENT_YEAR-2","CURRENT_YEAR-1")
    df_year=data.frame(Usage,year)
    
    levels(df_year$year)=c( "CURRENT_YEAR-5","CURRENT_YEAR-4","CURRENT_YEAR-3","CURRENT_YEAR-2","CURRENT_YEAR-1")
    
    
    p<-
      ggplot(data=df_year, aes(x=year,y=Usage,group=1)) +
      geom_bar(data=df_year, aes(x=year,y=Usage),stat="identity",width=0.55, fill="steelblue") +
      geom_line(stat="identity") +geom_point() + theme(axis.text.x = element_text(angle = 90))+
      ylab("Usage in Kwh")
    p
    
    
    
    
    
  })
  
  output$clientRetailInfo2 <- renderUI({
    i_customer_id=input$customerid
    client_pv_zoning <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "PV_ZONING"]
    client_pv_zoning<- gsub(1, "Yes", client_pv_zoning)
    client_pv_zoning<- gsub(0, "No", client_pv_zoning)               
    client_has_pv <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "HAS_PV"]
    client_has_pv<- gsub(1, "Yes", client_has_pv)
    client_has_pv<- gsub(0, "No", client_has_pv)               
    client_wind_zoning <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "WIND_ZONING"]
    client_wind_zoning<- gsub(1, "Yes", client_wind_zoning)
    client_wind_zoning<- gsub(0, "No", client_wind_zoning)               
    client_has_wind <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "HAS_WIND"]
    client_has_wind<- gsub(1, "Yes", client_has_wind)
    client_has_wind<- gsub(0, "No", client_has_wind)               
    client_car_owner <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "IS_CAR_OWNER"]
    client_car_owner<- gsub(1, "Yes", client_car_owner)
    client_car_owner<- gsub(0, "No", client_car_owner)               
    client_has_ev <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "HAS_EV"]
    client_has_ev<- gsub(1, "Yes", client_has_ev)
    client_has_ev<- gsub(0, "No", client_has_ev)     
    
    # if the customer has an electric vehicle they must be a car owner
    if (client_has_ev==1) {
      client_car_owner <- "Yes"
    }
    if (client_car_owner==0) {
      client_has_ev <- "NA"
    }
    
    
    tags$ul( class = 'list-unstyled',
             
             tags$li(
               tags$strong('Vehicle is Electric: '), tags$span(class = "pull-right", client_has_ev)
             ),
             tags$li(
               tags$strong('Wind Zoned: '), tags$span(class = "pull-right", client_wind_zoning)
             ),
             tags$li(
               tags$strong('Has Wind Energy: '),tags$span(class = "pull-right", client_has_wind)
             ),
             tags$li(
               tags$strong('    ')
             ),
             tags$li(
               tags$strong('PV Zoned: '), tags$span(class = "pull-right", client_pv_zoning)
             ),
             tags$li(
               tags$strong('Has PV Energy: '), tags$span(class = "pull-right", client_has_pv)
             )
    )
    
    
  })    
  output$gaugePrediction = renderGauge({
    i_customer_id=input$customerid
    
    prob <- df_unseen[df_unseen["CUSTOMER_ID"]==i_customer_id, "predicted_probability"]
    
    gauge(round(prob*100), 
          symbol = '%',
          min = 0, 
          max = 100, 
          sectors = gaugeSectors(success = c(0, 30),
                                 warning = c(30, 70),
                                 danger = c(70, 100)))
  })
  
#  observeEvent(input$customerid, {  
#    shinyjs::hide(id = "predictionPanel")
#    shinyjs::show(id = "prediction")
#    shinyjs::enable("predictionBtn")
#    
#  })     
  

  
}




