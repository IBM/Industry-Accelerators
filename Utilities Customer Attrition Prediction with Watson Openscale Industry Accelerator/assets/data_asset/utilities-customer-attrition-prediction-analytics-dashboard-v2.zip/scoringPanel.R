# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

scoringPanel <- function() {
  tabPanel(
    "Simulation Tool",
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 90% !important;
                      }
                      .html-widget.gauge svg {
                        height: 300px;
                        width: 600px;
                      }
                      "))
    ),
    shinyjs::useShinyjs(), 
    
    fluidRow(
      h2("Simulation Tool"),
      h4("Use this tool to modify any of the input variables in the form below. After changes are made click on the button to return the attrition probability."),
      h4("Ensure that you are connected to CPD by entering API details in the Client Tab."),
      column(8,
             h3("User Inputs"),
             panel(
               h3("Client Retail Information"),
               splitLayout(cellWidths = c("25%", "25%", "25%", "25%"),
                           selectInput("owns_home", "Owns Home?",
                                       c("No" = 0,
                                         "Yes" = 1),
                                       selected = 1
                           ),
                           selectInput("smart_meter_comments", "Comments on Smart Meter",
                                       as.character(unique(df$SMART_METER_COMMENTS)),
                                       selected = "Positive"
                           ),
                           selectInput("has_thermostat", "Has Thermostat?",
                                       c("No" = 0,
                                         "Yes" = 1),
                                       selected = 1
                           ),
                           selectInput("has_home_automation", "Has Home Automation?",
                                       c("No" = 0,
                                         "Yes" = 1),
                                       selected = 1
                           )
               ), 
               splitLayout(cellWidths = c("25%", "25%", "25%", "25%"),
                           selectInput("wind_zoning", "In Wind Zone?",
                                       c("No" = 0,
                                         "Yes" = 1),
                                       selected = 1
                           ),
                           selectInput("has_wind", "Has Wind Energy?",
                                       c("No" = 0,
                                         "Yes" = 1),
                                       selected = 0
                           ),
                           selectInput("pv_zoning", "In PV Zone?",
                                       c("No" = 0,
                                         "Yes" = 1),
                                       selected = 1
                           ),
                           selectInput("has_pv", "Has PV Energy?",
                                       c("No" = 0,
                                         "Yes" = 1),
                                       selected = 0
                           )
               ),               
               splitLayout(cellWidths = c("25%", "25%"),
                           selectInput("is_car_owner", "Car Owner?",
                                       c("No" = 0,
                                         "Yes" = 1),
                                       selected = 1
                           ),
                           selectInput("has_ev", "Has Electric Vehicle?",
                                       c("No" = 0,
                                         "Yes" = 1),
                                       selected = 0
                           )
               )               
             ),
             panel(
               h3("Client Information"),
               splitLayout(cellWidths = c("25%", "25%", "25%", "25%"),
                           
                           numericInput("age", "Customer Age", 
                                        value = 34
                           ),
                           selectInput("gender", "Gender",
                                       as.character(unique(df$GENDER)),
                                       selected = "M"
                           ),
                           numericInput("tenure", "Tenure (Months)", 
                                        value = 11
                           ),
                           selectInput("marital_status", "Marital Status",
                                       as.character(unique(df$MARITAL_STATUS)),
                                       selected = "U"
                           ),
                           selectInput("segment", "Customer Segment",
                                       as.character(unique(df$SEGMENT)),
                                       selected = "GOLD"
                           )
               ),
               splitLayout(cellWidths = c("25%", "25%", "25%"),
                           selectInput("city", "City",
                                       as.character(unique(df$CITY)),
                                       selected = "Mountain View"
                           ),         
                           selectInput("education", "Education",
                                       as.character(unique(df$EDUCATION)),
                                       selected = "Bachelor's degree"
                           ),
                           selectInput("employment", "Employment",
                                       as.character(unique(df$EMPLOYMENT)),
                                       selected = "Employed full-time"
                           )
               ) 
             ),
             panel(
               h3("Energy Usage"),
               splitLayout(cellWidths = c("25%", "25%", "25%", "25%"),
                           numericInput("energy_usage", "Monthly Energy Usage", 
                                        value = 4970
                           ),
                           numericInput("energy_efficieny", "Energy Efficiency", 
                                        value = 0.35
                           ),
                           numericInput("cur_year_usage_minus_1", "Current Year Minus 1 Usage", 
                                        value = 50000
                           ),               
                           numericInput("cur_year_median_usage_minus_1", "Current Year Minus 1 Median Usage", 
                                        value = 20500
                           )
               )
             ),
             panel(
               h3("Client Contract and Offer Details"),
               splitLayout(cellWidths = c("25%", "25%", "25%", "25%"),
                           selectInput("current_offer", "Current Offer",
                                       as.character(unique(df$CURRENT_OFFER)),
                                       selected = "Other"
                           ),                 
                           selectInput("current_contract", "Current Contract",
                                       as.character(unique(df$CURRENT_CONTRACT)),
                                       selected = "Dynamic Pricing 240 minute plan"
                           ),   
                           selectInput("current_issue", "Current Issue",
                                       as.character(unique(df$CURRENT_ISSUE)),
                                       selected = "Billing Issue"
                           ),
                           selectInput("registered_alerts", "Is Registered for Alerts?",
                                       c("No" = 0,
                                         "Yes" = 1),
                                       selected = 0
                           )
               ),
               splitLayout(cellWidths = c("25%", "25%", "25%"),
                           selectInput("made_complaint", "Has Previously Made a Complaint?",
                                       c("No" = 0,
                                         "Yes" = 1),
                                       selected = 1
                           ),
                           selectInput("ebill", "Gets Ebill",
                                       c("No" = 0,
                                         "Yes" = 1),
                                       selected = 0
                           ),
                           selectInput("in_warranty", "In Warranty",
                                       c("No" = 0,
                                         "Yes" = 1),
                                       selected = 1
                           )
               ),
               actionButton("realTimeScoreButton", "Make Attrition Prediction", class = "btn-primary btn-lg btn-block", disabled = TRUE)
             )
      ),
      column(4,
             h2("Attrition Probability"),
             gaugeOutput("realTimeScoringGauge")
      )
    )
    
  )
  
}


scoringServer <- function(input, output, session, sessionVars) {
  
  # Enable buttons when inputs are provided
  observe({
    if (length(sessionVars$debiasedurl)) {
      enable("realTimeScoreButton")
    }
  })
  
  observeEvent(input$realTimeScoreButton, {
    
    # craete the record that will be passed to the payload
    # variables such as ID, gender, name, etc need to be included in payload as they were originally included
    # but they are not used as model inputs so the values can be filled with default values here
    scoring_data <- data.frame(
      CUSTOMER_ID = 1000000,
      FIRST_NAME = "First",
      LAST_NAME = "name",
      PHONE_1 = "12232323",
      EMAIL = "test@email.com",
      AGE = input$age,
      ENERGY_USAGE_PER_MONTH = input$energy_usage,
      ENERGY_EFFICIENCY = input$energy_efficieny,
      IS_REGISTERED_FOR_ALERTS = input$registered_alerts,
      OWNS_HOME = input$owns_home,
      COMPLAINTS = input$made_complaint,
      HAS_THERMOSTAT = input$has_thermostat, 
      HAS_HOME_AUTOMATION = input$has_home_automation,
      PV_ZONING = input$pv_zoning,
      WIND_ZONING = input$wind_zoning,
      SMART_METER_COMMENTS = input$smart_meter_comments,
      IS_CAR_OWNER = input$is_car_owner,
      HAS_EV = input$has_ev,
      HAS_PV = input$has_pv,
      HAS_WIND = input$has_wind,
      TENURE = input$tenure,
      EBILL = input$ebill,
      IN_WARRANTY = input$in_warranty,
      CITY = input$city,
      CURRENT_OFFER = input$current_offer,
      CURRENT_CONTRACT = input$current_contract,
      CURRENT_ISSUE = input$current_issue,
      MARITAL_STATUS = input$marital_status,
      EDUCATION = input$education,
      SEGMENT = input$segment,
      EMPLOYMENT = input$employment,
      STD_YRLY_USAGE_CUR_YEAR_MINUS_1 = input$cur_year_usage_minus_1,
      STD_YRLY_USAGE_CUR_YEAR_MINUS_2 = 0,
      STD_YRLY_USAGE_CUR_YEAR_MINUS_3 = 0,
      STD_YRLY_USAGE_CUR_YEAR_MINUS_4 = 0,
      STD_YRLY_USAGE_CUR_YEAR_MINUS_5 = 0,
      STD_YRLY_USAGE_CUR_YEAR_MINUS_6 = 0,
      STD_YRLY_USAGE_CUR_YEAR_MINUS_7 = 0,
      MEDIAN_YRLY_USAGE_CUR_YEAR_MINUS_1 = input$cur_year_median_usage_minus_1,
      GENDER_ID=input$gender
    )
    
    scoring_data <- scoring_data[cols_to_use_score]
    
    # convert into json
    real_time_json_data <- unname(scoring_data)

    # call the api and get the prediction back
    response <- scoreDebiasedModel(sessionVars$debiasedurl, scoring_data, serverVariables$token)
    
    predicted_prob <- response$predictions[[1]]$values[[1]][[2]][[2]]
    debiased_fields=length(cols_to_use_score)+2
    predicted_prob=response$values[[1]][[debiased_fields]][[2]]
    
    # create the gauge
    output$realTimeScoringGauge = renderGauge({
      gauge(round(predicted_prob*100), 
            symbol = '%',
            min = 0, 
            max = 100, 
            sectors = gaugeSectors(success = c(0, 30),
                                   warning = c(30, 70),
                                   danger = c(70, 100)))
    })

    
  })
  
  
  
}



