# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyrig ht IBM Corp. 2019. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

# Load Data from CSV files
library(readr)
library(scales)

set.seed(0)
readDataset <- function(fileName) {read.csv(file.path(fileName), stringsAsFactors = FALSE)}
#names(df)

df <- readDataset("model output summary.csv")
#df=head(df,5000)

#df[df$SEGMENT=="",]$SEGMENT="GOLD"
df=df[complete.cases(df), ]

# split the data between the seen and unseen
# seen data has the actual target variable as well as the predictions - used for model insights
# the unseen data has predictions from the training notebook but no actuals - for demo purposes only - we are reusing the valiation and test data

#df$predicted_class <- df$predicted
#df$actual <- df$ATTRITION_STATUS
df_unseen <- df#[df['dataset']=='Unseen', ]
#df <- df[df['dataset']=='Seen', ]



# the ordering hasn't been preserved
df <- df[order(-df$predicted_probability),]
#df_unseen <- df_unseen[order(-df_unseen$predicted_probability),]

l_clientIDs <- c(2, 3637, 190, 637, 20,519,352)

# if the pre-defined customer ID's aren't in the unseen data select a random customer
i <- 1
for (clientID in l_clientIDs) {
    if (!(clientID %in% as.numeric(unlist(df_unseen["CUSTOMER_ID"])))) {
      l_clientIDs[i] <- sample(df_unseen[, "CUSTOMER_ID"], 1)
      i <- i + 1
    } 
}



clients <- list(
  list(name="Ima Labadie", image="1F.jpg", clientId=l_clientIDs[1]),
  list(name="Mavis Green", image="2M.jpg", clientId=l_clientIDs[2]),
  list(name="Dorothy Stracke", image="3M.jpg", clientId=l_clientIDs[3]),
  list(name="Gardner Block", image="7F.jpg", clientId=l_clientIDs[4]),
  list(name="Jesse Grady", image="4M.jpg", clientId=l_clientIDs[5]),
  list(name="Karson Fisher", image="6M.jpg", clientId=l_clientIDs[6]),
  list(name="Christian Powlowski", image="8F.jpg", clientId=l_clientIDs[7])
)




cols_to_use_score <- c("GENDER_ID", "AGE", "ENERGY_USAGE_PER_MONTH", "ENERGY_EFFICIENCY", "IS_REGISTERED_FOR_ALERTS", "OWNS_HOME", "COMPLAINTS", "HAS_THERMOSTAT", "HAS_HOME_AUTOMATION", "PV_ZONING", "WIND_ZONING", "SMART_METER_COMMENTS", "IS_CAR_OWNER", "HAS_EV", "HAS_PV", "HAS_WIND", "TENURE", "EBILL", "IN_WARRANTY", "CITY", "CURRENT_OFFER", "CURRENT_CONTRACT", "CURRENT_ISSUE", "MARITAL_STATUS", "EDUCATION", "SEGMENT", "EMPLOYMENT", "STD_YRLY_USAGE_CUR_YEAR_MINUS_1", "MEDIAN_YRLY_USAGE_CUR_YEAR_MINUS_1")
