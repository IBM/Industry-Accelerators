# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyrig ht IBM Corp. 2019. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

# Load Data from CSV files
library(readr)
library(scales)

set.seed(0)

readDataset <- function(fileName) {read.csv(file.path(fileName), stringsAsFactors = FALSE)}

df <-  readDataset("/home/rstudio/project-objectstorage/model output summary.csv")

# make a new column for customer name, join first name and surname
# before we pass the last dataframe to the api for scoring we need to remove this column
df$NAME <- paste(df$FIRST_NAME,df$LAST_NAME)

# split the data between the seen and unseen
# seen data has the actual target variable as well as the predictions - used for model insights
# the unseen data has predictions from the training notebook but no actuals - for demo purposes only - we are reusing the valiation and test data

df_unseen <- df[df['dataset']=='Unseen', ]
df <- df[df['dataset']=='Seen', ]

# the ordering hasn't been preserved
df <- df[order(-df$predicted_probability),]
df_unseen <- df_unseen[order(-df_unseen$predicted_probability),]

l_clientIDs <- c(63019, 64899, 47120, 1994, 28497)

# if the pre-defined customer ID's aren't in the unseen data select a random customer
i <- 1
for (clientID in l_clientIDs) {
    if (!(clientID %in% as.numeric(unlist(df_unseen["CUSTOMER_ID"])))) {
      l_clientIDs[i] <- sample(df_unseen[, "CUSTOMER_ID"], 1)
      i <- i + 1
    } 
}


clients <- list(
  list(name="Paige Carson", image="1F.jpg", clientId=l_clientIDs[1]),
  list(name="Alex Anderson", image="2M.jpg", clientId=l_clientIDs[2]),
  list(name="Ian Gray", image="3M.jpg", clientId=l_clientIDs[3]),
  list(name="Jane Wilson", image="7F.jpg", clientId=l_clientIDs[4]),
  list(name="Robert Taylor", image="4M.jpg", clientId=l_clientIDs[5])
)

df_unseen$FIRST_NAME[df_unseen["CUSTOMER_ID"]==l_clientIDs[1]] <- "Paige"
df_unseen$LAST_NAME[df_unseen["CUSTOMER_ID"]==l_clientIDs[1]] <- "Carson"
df_unseen$FIRST_NAME[df_unseen["CUSTOMER_ID"]==l_clientIDs[2]] <- "Alex"
df_unseen$LAST_NAME[df_unseen["CUSTOMER_ID"]==l_clientIDs[2]] <- "Anderson"
df_unseen$FIRST_NAME[df_unseen["CUSTOMER_ID"]==l_clientIDs[3]] <- "Ian"
df_unseen$LAST_NAME[df_unseen["CUSTOMER_ID"]==l_clientIDs[3]] <- "Gray"
df_unseen$FIRST_NAME[df_unseen["CUSTOMER_ID"]==l_clientIDs[4]] <- "Jane"
df_unseen$LAST_NAME[df_unseen["CUSTOMER_ID"]==l_clientIDs[4]] <- "Wilson"
df_unseen$FIRST_NAME[df_unseen["CUSTOMER_ID"]==l_clientIDs[5]] <- "Robert"
df_unseen$LAST_NAME[df_unseen["CUSTOMER_ID"]==l_clientIDs[5]] <- "Taylor"

# create the multiplier for each month
# use this along with average monthly energy usage column to create the moonthly usage
cust_energy_usage_seasonality <- list(
c(1.151365743, 0.957302041, 1.011734543, 1.016467804, 0.918252638, 0.913519377, 0.976235085, 0.868553397, 0.919435953, 1.010551228, 1.075633567, 1.180948624),
c(1.0675, 1.06375, 1.11, 0.99875, 0.885, 0.94625, 0.8825, 0.88125, 1, 1.00375, 0.9475,  1.21375),
c(1.045916294, 1.12393336, 0.988622511, 0.876472978, 0.992279561, 0.836245429, 0.999593661, 0.876472978, 0.889882162, 1.027631044, 1.106867127, 1.236082893),
c(1.165707361, 1.089366859, 0.986367767, 0.939109361, 0.903968494, 0.925780067, 0.935474099, 0.993638291, 0.948803393, 0.935474099, 1.095425629, 1.08088458),
c(1.004108628, 1.150816715, 0.986070749, 0.980058122, 0.951197515, 0.977653071, 0.859805592, 0.918729332, 0.968032869, 0.999298527, 1.030564185, 1.173664696)
)

monthly_energy_usage <- list()

i <- 1
for (clientID in l_clientIDs) {
  avg_monthly_energy_usage <- df_unseen$ENERGY_USAGE_PER_MONTH[df_unseen["CUSTOMER_ID"]==clientID]
  temp_list <- lapply(cust_energy_usage_seasonality[i], "*", avg_monthly_energy_usage)
  monthly_energy_usage[i] <- temp_list
  i <- i+1
  
}
names(monthly_energy_usage) <- l_clientIDs

months <- c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
historical_years <- c(2018, 2017, 2016, 2015, 2014, 2013, 2012)