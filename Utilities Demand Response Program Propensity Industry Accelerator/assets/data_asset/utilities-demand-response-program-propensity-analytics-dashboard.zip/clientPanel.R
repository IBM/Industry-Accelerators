# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.


# function to create buttons for each client
clientButton <- function(id, name, image) {
  
  tags$p(
    actionButton(paste0('client-btn-', id),
                 fluidRow(
                   column(4, 
                          tags$img(class = "pull-left", src = image, width = "60px", height = "60px")
                   ),
                   column(3,
                          tags$h4(strong(name)),
                          tags$h6(em(paste('Customer ID: ', id)))
                   )
                 ),
                 style="width:100%"
    )
  )
}



clientPanel <- function() {

  tabPanel(
      "Client View",
      value = "clientPanel",
      tags$head(
        tags$style(HTML("
                      .datatables {
                      width: 100% !important;
                      }
                      .html-widget.gauge svg {
                        height: 300px;
                        width: 600px;
                      }
                      "))
      ),
      shinyjs::useShinyjs(),
    
        fluidRow(
          div( id = "topActionClients",
          column(3, class = "pull-left",
                 panel(
                   span(align = "center", h2("Top Action Clients")),
                   span(align = "center", h5("Click on Client for further information")),
                   br(),
                   uiOutput("topClients")
                 )
          )
          ),
          hidden(
            tags$div(
              id = "clientInfoPanel",
                  column(6,
                    panel(
                      span(align = "center", h2("Client Information")),
                      br(),
                      column(6,
                        uiOutput("clientInfo1")
                      ),
                      column(6,
                        uiOutput("clientInfo2")
                      )
                    )
                  ),
                    fluidRow(
                      column(4,
                         panel(
                           span(align = "center", h2("Latest Year Monthly Energy Usage")),
                           plotOutput("monthlyUsage")
                         )
                      ),
                      column(4,
                         panel(
                           span(align = "center", h2("Historical Annual Energy Usage")),
                           plotOutput("historicalUsage")
                         )
                      )
                    )
            )
          )
        ),
        fluidRow(
          panel(
            h3("Client Demand Response (DR) Enrollment Propensity Prediction"),
            br(),
            
            tags$div(
              id = "authPanel",
              column(4,
                     panel(
                       h4("Connect to Cloud Pak for Data API"),
                       textInput("hostname", "CPD Hostname"),
                       textInput("username", "CPD Username"),
                       passwordInput("password", "CPD Password"),
                       actionButton("authBtn", "Authenticate API", class = "btn-primary btn-lg btn-block", style = "max-width:300px", disabled = TRUE),
                       tags$head(tags$style("#authError{color:red;}")),
                       verbatimTextOutput("authError")
                     ),
                     style = "max-width:360px;"
              )
            ),
            hidden(
              tags$div(
                id = "deploymentPanel",
                column(4,
                       panel(
                         tags$h4("Model Scoring Pipeline Deployment"),
                         pickerInput(
                           inputId = 'deploymentSelector',
                           label = 'Deployment Name:',
                           choices = list(),
                           options = pickerOptions(width = "auto", style = "btn-primary")
                         ),
                         tags$p(
                           tags$strong("Space Name: "),
                           textOutput(outputId = "space_name", inline = TRUE)
                         ),
                         tags$p(
                           tags$strong("GUID: "),
                           textOutput(outputId = "deployment_guid", inline = TRUE)
                         ),
                         tags$p(
                           tags$strong("Tags: "),
                           textOutput(outputId = "deployment_tags", inline = TRUE)
                         ),
                         tags$p(
                           tags$strong("Scoring Endpoint: "),
                           textOutput(outputId = "scoring_url", inline = TRUE),
                           style = "word-wrap: break-word"
                         )),
                       
                       panel(
                         actionButton(
                           "reauthenticateBtn",
                           "Re-Authenticate",
                           class = "btn-primary btn-lg btn-block"
                         ) 
                       )    
                ),
                tags$div(id = "scoreBtnSection",
                         column(4,
                                br(),
                                actionButton(
                                  "scoreBtn",
                                  "Predict Client DR Enrollment Propensity",
                                  class = "btn-primary btn-lg btn-block",
                                  disabled = TRUE
                                ),
                                br(),
                                h4("Input JSON:"),
                                verbatimTextOutput("pipelineInput"),
                                br(),
                                tags$head(tags$style("#scoringError{color:red;}")),
                                verbatimTextOutput("scoringError"))
                ),
                column(8,
                       hidden(
                         tags$div(id = "scoringResponse")
                       )
                )
              )
            )
          )
        
        )
  )
  
}


# Reactive server variables store (pervades across all sessions)
serverVariables = reactiveValues(deployments = list(), token = '')

if(nchar(Sys.getenv('CP4D_HOSTNAME')) > 0 && nchar(Sys.getenv('CP4D_USERNAME')) > 0 && nchar(Sys.getenv('CP4D_PASSWORD')) > 0) {
  tryCatch({
    deploymentsResp = collectDeployments(Sys.getenv('CP4D_HOSTNAME'), Sys.getenv('CP4D_USERNAME'), Sys.getenv('CP4D_PASSWORD'), "demand_response_propensity_scoring_pipeline_function_deployment_tag")
    serverVariables$deployments <- deploymentsResp$deployments
    serverVariables$token = deploymentsResp$token
  }, warning = function(w) {
    print(w$message)
  }, error = function(e) {
    print(e$message)
  })
}

clientServer <- function(input, output, session, sessionVars) {

  
  # Observation events for client buttons
   lapply(clients,
         function(client){
           x <- paste0('client-btn-', client$clientId)
           observeEvent(
             input[[x]],
             {
               shinyjs::enable("scoreBtn")
               shinyjs::show(id = "clientInfoPanel")
               
               sessionVars$selectedClientId <- client$clientId
               client_name <- client$name
               client_id <- client$clientId
               client_segment <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "SEGMENT"]
               client_cltv <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "CLTV"] 
               client_city <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "CITY"] 
               client_tenure <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "TENURE"] 
               client_energy_usage <- round(df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "ENERGY_USAGE_PER_MONTH"])
               client_energy_efficiency <- round(df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "ENERGY_EFFICIENCY"], 2)
               client_home_owner <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "OWNS_HOME"]
               client_home_owner<- gsub(1, "Yes", client_home_owner)
               client_home_owner<- gsub(0, "No", client_home_owner)
               client_usage_cur_year_minus_1 <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "STD_YRLY_USAGE_CUR_YEAR_MINUS_1"]
               client_usage_cur_year_minus_2 <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "STD_YRLY_USAGE_CUR_YEAR_MINUS_2"]
               client_usage_cur_year_minus_3 <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "STD_YRLY_USAGE_CUR_YEAR_MINUS_3"]
               client_usage_cur_year_minus_4 <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "STD_YRLY_USAGE_CUR_YEAR_MINUS_4"]
               client_usage_cur_year_minus_5 <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "STD_YRLY_USAGE_CUR_YEAR_MINUS_5"]
               client_usage_cur_year_minus_6 <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "STD_YRLY_USAGE_CUR_YEAR_MINUS_6"]
               client_usage_cur_year_minus_7 <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "STD_YRLY_USAGE_CUR_YEAR_MINUS_7"]
               client_hostorical_usage = c(client_usage_cur_year_minus_1, client_usage_cur_year_minus_2, client_usage_cur_year_minus_3, 
                                           client_usage_cur_year_minus_4, client_usage_cur_year_minus_5, client_usage_cur_year_minus_6,
                                           client_usage_cur_year_minus_7)
               
               output$clientInfo1 <- renderUI({
                 
                 tags$ul( class = 'list-unstyled',
                          tags$li(
                            tags$strong('Name: '), tags$span(class = "pull-right", client_name)
                          ),
                          tags$li(
                            tags$strong('ID: '), tags$span(class = "pull-right", client_id)
                          ),
                          tags$li(
                            tags$strong('Segment: '), tags$span(class = "pull-right", client_segment)
                          ),
                          tags$li(
                            tags$strong('City: '), tags$span(class = "pull-right", client_city)
                          ),
                          tags$li(
                            tags$strong('Lifetime Value: '), tags$span(class = "pull-right", client_cltv)
                          )
                 )
               })
               
               output$clientInfo2 <- renderUI({
                 tags$ul( class = 'list-unstyled',
                          tags$li(
                            tags$strong('Tenure: '), tags$span(class = "pull-right", client_tenure, " Months")
                          ),
                          tags$li(
                            tags$strong('Home Owner: '),tags$span(class = "pull-right", client_home_owner)
                          ),
                          tags$li(
                            tags$strong('Average Monthly Energy Usage: '), tags$span(class = "pull-right", client_energy_usage, "KWh")
                          ),
                          tags$li(
                            tags$strong('Energy Efficiency: '), tags$span(class = "pull-right", client_energy_efficiency)
                          )
                 )
               })

               df_client_monthly_usage <- data.frame(months, monthly_energy_usage[as.character(client$clientId)])
               names(df_client_monthly_usage) <- c("month", "energy_usage")
               # do this to maintain month order
               df_client_monthly_usage$month <- factor(df_client_monthly_usage$month, levels = months)
               
               output$monthlyUsage <- renderPlot({
                   ggplot(df_client_monthly_usage, aes(x=month)) + 
                   geom_line(aes(y=energy_usage), color="red", group=1) +
                   theme_minimal() + 
                   expand_limits(x = 0, y = 0) +
                   labs(x = "Month", y = "Energy Usage (kWh)") 
               })
               
               df_client_hostorical_annual_usage <- data.frame(historical_years, client_hostorical_usage)
               names(df_client_hostorical_annual_usage) <- c("year", "energy_usage")

               output$historicalUsage <- renderPlot({
                 ggplot(df_client_hostorical_annual_usage, aes(x=year, y=energy_usage)) + 
                   geom_bar(stat="identity", fill="blue",width=0.7) + 
                   scale_x_reverse(breaks = seq(2018, 2012, by = -1)) + 
                   theme_minimal() + 
                   labs(x = "Year", y = "Annual Energy Usage (kWh)") 
               })
               
               
             }
           )
         })
  

  # create the button for clients
  output$topClients <- renderUI({
    
    # List of client buttons
    lapply(clients, function(client){
      clientButton(client$clientId, client$name, paste0("profiles/", client$image))
    })
    
  })

  observe({
    # filter the csv for the selected customer and use as input for the API
    df_filtered <- df_unseen[df_unseen["CUSTOMER_ID"]==sessionVars$selectedClientId, ]
    # remove columns that weren't in the original input dataset
    # we need to do this becuase of the csv file we're using for demo
    # in real scenario this data would come from db or raw csv
    df_filtered$actual <- NULL
    df_filtered$predicted_probability <- NULL	
    df_filtered$Bin <- NULL	
    df_filtered$predicted_class <- NULL
    df_filtered$dataset <- NULL
    df_filtered$NAME <- NULL

    json_data <- jsonlite::toJSON(df_filtered)

    # Reset scoring
    removeUI(selector = "#scoringResponse > *", multiple = TRUE)
    shinyjs::hide(id = "scoringResponse")
    shinyjs::show(id = "scoreBtnSection")
    output$scoringError <- renderText('')
    sessionVars$pipelineInput <- json_data
    output$pipelineInput <- renderText(json_data)
  })
  
  # Set default hostname for CP4D API
  observeEvent(session$clientData$url_hostname, {
    updateTextInput(session, "hostname", value = session$clientData$url_hostname)
  })
  
    # Enable buttons when inputs are provided
  observe({
    toggleState("authBtn", nchar(input$hostname) > 0 && nchar(input$username) > 0 && nchar(input$password) > 0)
    toggleState("scoreBtn", nchar(input$endpoint) > 0 && nchar(input$token) > 0 && length(input$allCustomers_rows_selected) > 0)
  })
  
  # Handle CP4D API authentication button
  observeEvent(input$authBtn, {
    shinyjs::disable("authBtn")
    
    tryCatch({
      deploymentsResp = collectDeployments(input$hostname, input$username, input$password, "demand_response_propensity_scoring_pipeline_function_deployment_tag")
      serverVariables$deployments <- deploymentsResp$deployments
      serverVariables$token = deploymentsResp$token
    }, warning = function(w) {
      output$authError <- renderText(w$message)
    }, error = function(e) {
      output$authError <- renderText(e$message)
    })
    
    shinyjs::enable("authBtn")

    if(length(serverVariables$deployments) > 0) {
      updateSelectInput(session, "deploymentSelector", choices = names(serverVariables$deployments))
      shinyjs::hide(id = "authPanel")
      shinyjs::show(id = "deploymentPanel")
    }
  })
  
  # Handle model deployment dropdown switching
  observeEvent(input$deploymentSelector, {
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    output$deployment_guid <- renderText(selectedDeployment$guid)
    output$space_name <- renderText(selectedDeployment$space_name)
    output$deployment_tags <- renderText(selectedDeployment$tags)
    output$scoring_url <- renderText(selectedDeployment$scoring_url)
    toggleState("scoreBtn", nchar(selectedDeployment$scoring_url) > 0 && nchar(serverVariables$token) > 0)
  })
  
  observeEvent(input$scoreBtn, {
    shinyjs::disable("scoreBtn")
    
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    sessionVars$selectedDeployment <- selectedDeployment
    
    payload <- sessionVars$pipelineInput
    
    response <- scoreModelDeployment(selectedDeployment$scoring_url, payload, serverVariables$token)
    
    if(length(response$error) > 0) {
      output$scoringError <- renderText(toString(response$error))
    } else if (length(response$predictions) > 0) {
      shinyjs::hide(id = "scoreBtnSection")
      shinyjs::show(id = "scoringResponse")
      
      predicted_prob <- response$predictions[[1]]$values$predictions[[1]]$values[[1]][[2]][[2]]
     
      insertUI(
        selector = "#scoringResponse",
        where = "beforeEnd",
        ui = panel(
          tags$head(
            tags$style(HTML("
                      .datatables {
                      width: 100% !important;
                      }
                      .html-widget.gauge svg {
                        height: 300px;
                        width: 600px;
                      }
                      "))
          ),
          h3("Client Demand Response Propensity Probability:"),
          p(
            gaugeOutput("gauge")
          )
        )
      )
      
      output$gauge = renderGauge({
        gauge(round(predicted_prob*100), 
              symbol = '%',
              min = 0, 
              max = 100, 
              sectors = gaugeSectors(success = c(0, 30),
                                     warning = c(30, 70),
                                     danger = c(70, 100)))
      })
    } else {
      output$scoringError <- renderText(response)
    }

    
  })
  observeEvent(input$reauthenticateBtn, {
    shinyjs::show(id = "scoreBtnSection")
    removeUI(selector = "#scoringResponse > *", multiple = TRUE)
    shinyjs::show(id = "authPanel")
    shinyjs::hide(id = "deploymentPanel")
    shinyjs::enable("scoreBtn")
  })
  
}




