# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.


modelInsightPanel <- function() {

  
  tabPanel(
    "Model Insights",
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 90% !important;
                      }
                      .shiny-split-layout > div {
                                overflow: visible;
                      }
                      .small-box {height: 75px}
                      .fa { font-size: 40px; }
                      "))
    ),
    shinyjs::useShinyjs(),
    useShinydashboard(),
    
    fluidRow(
      column(11, 
        panel(
             valueBoxOutput("numCustomers"),
             valueBoxOutput("enrolledCustomers"),
             valueBoxOutput("percEnrolledCustomers")
        )
      )
    ),
    fluidRow(
      column(2, 
             
             panel(
               
               checkboxGroupInput("seg_checkbox", "Choose Segment(s):",
                                  choices = str_to_title(as.character(unique(df$SEGMENT))),
                                  selected = str_to_title(as.character(unique(df$SEGMENT))),
               ),
               checkboxGroupInput("city_checkbox", "Select Service Territory:",
                                  choices = as.character(unique(df$CITY)),
                                  selected = as.character(unique(df$CITY)),
               ),
               selectInput("warranty", "Is the Customer Still in Warranty?",
                           c("Either" = 99,
                             "No" = 0,
                             "Yes" = 1), selected=99
               )
             )
      ),
      column(5,
             panel(
               h2("Optimize Demand Response Customer Targeting"),
               h4("Use the cumulative gains and lift charts below to optimize customer targeting by selecting the prospects most likely to enroll and avoid contacting those with low likelihood."),
               h5("The cumulative gains chart shows the percentage of enrolled customers selected by targeting a specific percentage of total customers. Click on a red point in the chart to get a description of the result."),
               plotOutput("cumGainPlot", click = "cumGainsClick")
             ),
             panel(
               hidden(
                 tags$div(id = "gainsThresholdText",
                    h4(htmlOutput("describeCutoff"))
                 )
               ),
               h2("Lift Chart"),
               h5("The Lift chart is derived from the cumulative gains chart. It shows the ratio of the cumulative gain from the model vs random choice. "),
               plotOutput("liftPlot")
             )
      ),
      column(4,
             panel(
               h3("New Potential Contacts Ranked on their Predicted DR Enrollment Probability"),
               h5("Click on a point on the cumulative gains chart to filter only customers within the threshold"),
               dataTableOutput("showFilteredTable"),
               br(),
               downloadButton("downloadData", "Download Table")
             )
      )
    )
  )
}



insightsServer <- function(input, output, session) {
  
  

  

 
  observe({
    
    # we filter the datasets based on the user's selection
    # filter both datasets - df which is the seen data that has the actual target
    # and df_unseen, where we don't know the actual enrollment value
    selected_segment <- input$seg_checkbox
    selected_city <- input$city_checkbox
    selected_warranty <- input$warranty
    
    df_temp <- dplyr::filter(df, (df$SEGMENT %in% selected_segment) & (df$CITY %in% selected_city))
    df_temp_unseen <- dplyr::filter(df_unseen, (df_unseen$SEGMENT %in% selected_segment) & (df_unseen$CITY %in% selected_city))
  
  
    # if the user has selected to show both customer's who are and aren't in warranty
    # they input is set to 99, we don't include the complaints in the filter
    if (selected_warranty!=99) {
      df_temp <- dplyr::filter(df, (df$IN_WARRANTY %in% selected_warranty))
      df_temp_unseen <- dplyr::filter(df_unseen, (df_unseen$IN_WARRANTY %in% selected_warranty))
    }    
    
    df_temp$Bin <- ntile(as.numeric(rownames(df_temp)), 20)
    df_temp_unseen$Bin <- ntile(as.numeric(rownames(df_temp_unseen)), 20)

    # get the cumulative % of customers
    df_temp$cumulativePercCust <- (1:nrow(df_temp))/nrow(df_temp)   
    df_temp_unseen$cumulativePercCust <- (1:nrow(df_temp_unseen))/nrow(df_temp_unseen) 
  
    num_customers <- dim(df_temp)[1]
    num_predicted_enrolled <- sum(df_temp$predicted_class)
    perc_predicted_enrolled <- round((num_predicted_enrolled/num_customers)*100)
    
    df_temp_enroll_perc <- df_temp %>%
      group_by(predicted_class) %>%
      summarize(num_cust = n()) %>%
      mutate(perc_cust = num_cust/sum(num_cust))  %>%
      as.data.frame()
    
    df_temp_enroll_perc$predicted_class[df_temp_enroll_perc$predicted_class == 1] <- "Predicted to Enroll"
    df_temp_enroll_perc$predicted_class[df_temp_enroll_perc$predicted_class == 0] <- "Predicted not to Enroll"
    
    df_summary <- df_temp %>%
      group_by(Bin) %>%
      summarize(num_cust = n(), num_enrolled_cust=sum(actual)) %>%
      mutate(cumulative_perc_cust = cumsum(num_cust)/sum(num_cust))  %>%
      mutate(cumulative_perc_enrolled_cust = cumsum(num_enrolled_cust)/sum(num_enrolled_cust)) %>%
      mutate(lift = cumulative_perc_enrolled_cust / cumulative_perc_cust) %>%
      as.data.frame()
    
    df_summary <- rbind(c(0,0,0,0,0), df_summary)
  
    output$cumGainPlot <- renderPlot({
      ggplot(df_summary, aes(x=cumulative_perc_cust, y=cumulative_perc_enrolled_cust)) + 
        geom_line(color="red") + 
        geom_point(color="red") + 
        geom_segment(aes(x = 0, y = 0, xend = 1, yend = 1), color="grey") +
        theme_minimal() +
        theme(legend.position = c(0, 1)) +
        scale_x_continuous(breaks = seq(0, 1, by = 0.1)) + 
        scale_y_continuous(breaks = seq(0, 1, by = 0.1)) +
        labs(x = "Cumulative % of Customers", y = "Cumulative % of Enrolled Customers")
      
    })
    
    output$liftPlot <- renderPlot({
      ggplot(tail(df_summary, -1), aes(x=cumulative_perc_cust, y=lift)) + 
        geom_line(color="red") + 
        geom_point(color="red") + 
        geom_hline(yintercept=1, linetype = "dashed", color="black") +
        expand_limits(x = 0, y = 0) +
        theme_minimal() + 
        theme(legend.position="top") + 
        scale_x_continuous(breaks = seq(0, 1, by = 0.1)) +
        labs(x = "Cumulative % of Customers", y = "Lift")
      
    })

    output$numCustomers <- renderValueBox({
      shinydashboard::valueBox(
        tags$p(paste0(format(num_customers,big.mark = ',')), style = "font-size: 30px;"), 
        tags$p(" Customers Analyzed", style = "font-size: 15px;"),
        color = "aqua", width = 4, icon = icon("user")
      )
    })
    
    output$enrolledCustomers <- renderValueBox({
      shinydashboard::valueBox(
        tags$p(paste0(format(num_predicted_enrolled,big.mark = ',')), style = "font-size: 30px;"), 
         tags$p(" Customers Predicted to Enroll", style = "font-size: 15px;"),
        color = "green", width = 4, icon = icon("thumbs-up")
      )
    })
    
    output$percEnrolledCustomers <- renderValueBox({
      shinydashboard::valueBox(
        tags$p(paste0(perc_predicted_enrolled, "%"), style = "font-size: 30px;"), 
        tags$p(" Predicted Enrollment Rate", style = "font-size: 15px;"),
        color = "green", width = 4, icon = icon("percent")
      )
    })
    
    
    
    coords <- reactiveValues(x = NULL, y = NULL, filtered_df = NULL)
    
    # when the user selects the cutoff point, we display the unseen data that meets the probability threshold
    output$showFilteredTable <- DT::renderDataTable({
      
      list_nearest_points <- nearPoints(select(df_summary, "cumulative_perc_cust", "cumulative_perc_enrolled_cust"), input$cumGainsClick)
      x_val <- round(list_nearest_points[[1]], 2)
      y_val <- round(list_nearest_points[[2]], 2)
      
      coords$x <- x_val
      coords$y <-y_val
      
      if (length(x_val)) {
        shinyjs::show(id = "gainsThresholdText")
        filtered_df <- df_temp_unseen[df_temp_unseen["cumulativePercCust"]<=x_val, ]
        filtered_df <- select(filtered_df, "CUSTOMER_ID", "NAME", "PHONE_1", "EMAIL", "predicted_probability")
        filtered_df$predicted_probability <- filtered_df$predicted_probability * 100
        filtered_df <- filtered_df %>% mutate_if(is.numeric, round, 1)
        if (dim(filtered_df)[1] > 0) {
          filtered_df$predicted_probability <- paste0(as.character(filtered_df$predicted_probability), "%")
          filtered_df <- rename(filtered_df, 'Enrollment Probability' = 'predicted_probability')
        }
        
        coords$filtered_df <- filtered_df
        
      } else {
        filtered_df <- select(df_temp_unseen, "CUSTOMER_ID", "NAME", "PHONE_1", "EMAIL", "predicted_probability")
        filtered_df$predicted_probability <- filtered_df$predicted_probability * 100
        filtered_df <- filtered_df %>% mutate_if(is.numeric, round, 1)
        if (dim(filtered_df)[1] > 0) {
          filtered_df$predicted_probability <- paste0(as.character(filtered_df$predicted_probability), "%")
          filtered_df <- rename(filtered_df, 'Enrollment Probability' = 'predicted_probability')
        }
        }
    }, server=FALSE, options = list(pageLength = 5, autoWidth = TRUE))
    
    output$describeCutoff <- renderUI({
      str <- paste0("By targeting the top <b>", (coords$x*100), "%</b> of customers, we reach <b>", (coords$y*100), "%</b> of Demand Response prospects.")
      HTML(str)
    })

    
    output$downloadData <- downloadHandler(
      filename = function() {
        paste0("potential enrollment contacts - top ", round(coords$x * 100, 0), "% customers.csv")
      },
      content = function(file) {
        write.csv(coords$filtered_df, file, row.names = FALSE)
      }
    )
    
  })
  

}
