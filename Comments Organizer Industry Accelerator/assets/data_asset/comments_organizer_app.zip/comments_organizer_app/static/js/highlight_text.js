$('#highlighter').on('change', function() {
    $('.neg').toggleClass('add-red-color');
});

$('#highlighter').on('change', function() {
    $('.pos').toggleClass('add-green-color');
});

$('#sentence-highlighter').on('change', function() {
    $('.neg-sentence').toggleClass('add-red-color');
});

$('#sentence-highlighter').on('change', function() {
    $('.pos-sentence').toggleClass('add-green-color');
});

$(document).ready(function () {
  $("#hide").click(function(){
    $(".myDIV").hide();
  });
  $("#show").click(function(){
    $(".myDIV").show();
  });
});