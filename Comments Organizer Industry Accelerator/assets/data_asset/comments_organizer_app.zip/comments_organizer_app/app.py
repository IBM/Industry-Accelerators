
import base64
import json
import os
from collections import defaultdict
from io import BytesIO
import pandas as pd
import plotly
import plotly.graph_objs as go
from flask import Flask, render_template, request
from sklearn.feature_extraction.text import CountVectorizer
from ibm_watson_machine_learning import APIClient
from wordcloud import WordCloud
import datetime
import urllib3, requests, json
from requests.auth import HTTPBasicAuth
import ast

app = Flask(__name__)

# TODO: Enter IBM Cloud Credentials, see "Python Flask App" in README.ipynb
wml_credentials = {
    "url": "----------------------------------",
    "apikey": "--------------------------------"
}
client = APIClient(wml_credentials)

# TODO: Update Cloud Object Storage CRN link
space_name = 'comments-organizer-space'
space_tag = '-----------------------'


# Get the latest deployment space if exists or create a new one
l_space_details = []
l_space_details_created_times = []
for space_details in client.spaces.get_details()['resources']:
    if space_details['entity']['name'] == space_name:
        l_space_details.append(space_details)
        l_space_details_created_times.append(datetime.datetime.strptime(space_details['metadata']['created_at'],  '%Y-%m-%dT%H:%M:%S.%fZ'))

if not l_space_details:
    # create the space and set it as default
    space_meta_data = {
        client.spaces.ConfigurationMetaNames.NAME : space_name,
        client.spaces.ConfigurationMetaNames.STORAGE: {"resource_crn": space_tag},
    }

    stored_space_details = client.spaces.store(space_meta_data)
    print(stored_space_details)
    space_uid = stored_space_details['metadata']['id']
    client.set.default_space(space_uid)
    print('Space uid: ', space_uid)
else:
    # get the index of the latest created date from the list and use that to get the space_id
    list_latest_index = l_space_details_created_times.index(max(l_space_details_created_times))
    space_id = l_space_details[list_latest_index]['metadata']['id']
    # set this space as default space
    print('Space id: ', space_id)
    client.set.default_space(space_id)

def get_token():

    # TODO: Enter the generated access token
    auth_token = "--------"
    return auth_token


# NOTE: you must construct mltoken based on provided documentation
header = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + get_token()}


# TODO: Enter api endpoints usinf steps listed in README
clustering_endpoint_url = '------------------'
sentiment_endpoint_url = '------------------'

# Get Watson ML environment port if deploying or use localhost if running locally
port = int(os.getenv('PORT', 8000))


@app.route('/', methods=['GET', 'POST'])
def index():

    if request.method == 'POST':
        # Retrieve comments
        file_data = request.files.get('file')
        comments_file = file_data.read().decode("utf-8")
        comments_text = request.form.get('text')

        if file_data or comments_text:
            raw_comments = comments_file if file_data else comments_text

            # Group and run sentiment analysis on comments
            best_groups, negative_sentiment, neutral_sentiment, positive_sentiment = group_comments(raw_comments)

            # Create graphs
            bar_plot = create_frequency_bar_plot(split_text_by_comment(raw_comments))
            sentiment_plot = create_sentiment_bar_plot(positive_sentiment, negative_sentiment, neutral_sentiment)
            comments = split_text_by_comment(raw_comments)
            plot_url = create_word_cloud(comments)

            # Send information to html
            return render_template('index.html',
                                   comments=comments,
                                   best_groups=best_groups,
                                   negatives=negative_sentiment,
                                   positives=positive_sentiment,
                                   neutrals=neutral_sentiment,
                                   bar_plot=bar_plot,
                                   sentiment_plot=sentiment_plot,
                                   plot_url=plot_url
                                   )

    return render_template('index.html', comments=[], plot_url='')


def split_text_by_comment(comments):
    """
    :param comments: string of comments
    :return: list of comments
    """
    comments_list = comments.split('\n')
    return comments_list


def combine_clustering_and_sentiment(clustering_response, sentiment_response):
    """
    Combine clustering_response and sentiment_response

    :param clustering_response:
    :param sentiment_response:
    :return:  json serializable string in format
    {
        "comment": {
            "idx": int,
            "group": int,
            "topics": [],
            "sentiment": str,
            "sentence_sentiment": [
                {
                    "idx": int,
                    "sentiment": str
                },
            ]
        }
    }
    """
    for i in range(len(clustering_response)):
        comment = sentiment_response[i]['comment']
        comment['group'] = clustering_response[i]['comment']['group']
        comment['topics'] = clustering_response[i]['comment']['topics']

    return sentiment_response


def group_comments(comments):
    """
    Calls the APIs for clustering and sentiment analysis and formats responses to be used in index.html

    :param comments: list of comments
    :return: best_groups: list of ((group_id, topics), [(sentiment, comment), ...])
             negative_sentiments: list of negative sentiment comments and their sentence level sentiments
                                  in format [(sentence_sentiment, sentence), ...]
             neutral_sentiments: list of neutral sentiment comments and their sentence level sentiments
             positive_sentiments: list of positive sentiment comments and their sentence level sentiments
    """
    comment_texts = split_text_by_comment(comments)

    # payload must have 'values'. But optional params are number_of_terms and number_of_clusters
    # payload = {'values': comment_texts}
    payload = {client.deployments.ScoringMetaNames.INPUT_DATA: [{'values':
                                                                {"test": comment_texts}}
                                                                ]}
    
    clustering_response = requests.post(clustering_endpoint_url, json=payload, headers=header, verify=False, timeout=600)
    clustering = json.loads(clustering_response.text)
    print(clustering)
    clustering = ast.literal_eval(clustering['predictions'][0]['values'])
    print(clustering)
    sentiment_response = requests.post(sentiment_endpoint_url, json=payload, headers=header, verify=False, timeout=600)
    sentiment = json.loads(sentiment_response.text)
    sentiment = ast.literal_eval(sentiment['predictions'][0]['values'])
    print(sentiment)

    
    combined_response = combine_clustering_and_sentiment(clustering, sentiment)
    print(combined_response)
    '''
    clustering_response = json.loads(client.deployments.score(clustering_endpoint_url, payload))
    sentiment_response = json.loads(client.deployments.score(sentiment_analysis_endpoint_url, payload))
    combined_response = combine_clustering_and_sentiment(clustering_response, sentiment_response)
    '''
  
  
    # Format responses
    groups_and_sentiments = defaultdict(list)
    sentence_level_sentiments = defaultdict(list)
    for i in range(len(comment_texts)):
        comment = combined_response[i]['comment']
        topics = ', '.join(sorted(comment['topics']))
        groups_and_sentiments[(comment['group'], topics)].append((comment['sentiment'], comment_texts[i]))

        sentences = [(s['sentiment'], s['sentence']) for s in comment['sentence_sentiment']]
        sentence_level_sentiments[comment['sentiment']].append(sentences)

    best_groups = sorted(list(groups_and_sentiments.items()))
    negative_sentiments = sentence_level_sentiments['Negative']
    neutral_sentiments = sentence_level_sentiments['Neutral']
    positive_sentiments = sentence_level_sentiments['Positive']

    return best_groups, negative_sentiments, neutral_sentiments, positive_sentiments
    

def get_top_n_words(corpus, n=5):
    """
    :param corpus: list of strings
    :param n: int
    :return: list of top n most frequent words in corpus
    """
    count_vect = CountVectorizer(stop_words='english')
    matrix = count_vect.fit_transform(corpus)
    frequencies = zip(count_vect.get_feature_names(), matrix.sum(axis=0).tolist()[0])
    words_freq = sorted(frequencies, key=lambda x: -x[1])
    return words_freq[:n]


def create_frequency_bar_plot(comments, n=5):
    """

    :param comments: list of strings
    :param n: int
    :return: plot of most frequent words
    """
    common_words = get_top_n_words(comments, n)
    most_frequent_words = pd.DataFrame(common_words, columns=['word', 'count'])
    data = [
        go.Bar(
            x=most_frequent_words['word'],
            y=most_frequent_words['count']
        )
    ]

    graph = dict(
        data=data,
        layout=dict(
            title='Top 5 Most Frequent Words',
            xaxis=dict(title='Word'),
            yaxis=dict(title='Count')
        )
    )

    graphJSON = json.dumps(graph, cls=plotly.utils.PlotlyJSONEncoder)
    return graphJSON


def count_sentence_sentiments(positives, negatives, neutrals):
    """

    :param positives: list of positive comments
    :param negatives: list of negative comments
    :param neutrals: list of neutral comments
    :return: dictionary mapping sentiment to its count
    """
    sentiment_count = {'Positive': 0, 'Negative': 0, 'Neutral': 0}
    for sentiment_list in [positives, negatives, neutrals]:
        for comment in sentiment_list:
            for sentiment, sentence in comment:
                sentiment_count[sentiment] += 1

    return sentiment_count


def create_sentiment_bar_plot(positives, negatives, neutrals):
    """

    :param positives: list of positive comments
    :param negatives: list of negative comments
    :param neutrals: list of neutral comments
    :return: bar plot of sentiment analysis
    """
    sentiment_count = count_sentence_sentiments(positives, negatives, neutrals)

    data = [
        go.Bar(
            name='Overall Comment Sentiment',
            x=['Positive', 'Neutral', 'Negative'],
            y=[len(positives), len(neutrals), len(negatives)],
            marker=dict(color=['#0b6323', '#e8ae00', '#800003']),
        ),
        go.Bar(
            name='Sentence Level Sentiment',
            x=['Positive', 'Neutral', 'Negative'],
            y=[sentiment_count['Positive'], sentiment_count['Neutral'], sentiment_count['Negative']],
            marker=dict(color=['#acd4a7', '#f0e7aa', '#bd5759']),
        )
    ]

    graph = dict(
        data=data,
        layout=dict(
            title='Sentiment Breakdown',
            xaxis=dict(title='Sentiment'),
            yaxis=dict(title='Count'),
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,)
        ),
    )

    graphJSON = json.dumps(graph, cls=plotly.utils.PlotlyJSONEncoder)
    return graphJSON


def create_word_cloud(comments):
    """

    :param comments: list of comments
    :return: word cloud of comments
    """
    comments_text = ' '.join(comments)

    if comments_text.isspace() or comments_text=='':
        return ''

    img = BytesIO()

    # Note: as per WordCloud docs, STOPWORDS are automatically removed if not specified
    wc = WordCloud(background_color="white", width=500, height=300)
    wc.generate(comments_text)
    wc.to_image().save(img, 'PNG')
    img.seek(0)

    plot_url = base64.b64encode(img.getvalue()).decode('utf8')
    return plot_url


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=port, threaded=True)

