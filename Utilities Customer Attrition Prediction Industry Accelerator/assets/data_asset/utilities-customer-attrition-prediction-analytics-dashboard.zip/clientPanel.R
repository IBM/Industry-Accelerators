# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.


# function to create buttons for each client
clientButton <- function(id, name, contract, image) {
  
  tags$p(
    actionButton(paste0('client-btn-', id),
                 fluidRow(
                   column(4, 
                          tags$img(class = "pull-left", src = image, width = "60px", height = "60px")
                   ),
                   column(3,
                          tags$h4(strong(name)),
                          tags$h6(em(paste('Customer ID: ', id))),
                          tags$h6(em(paste('Contract: ', contract)))
                   )
                 ),
                 style="width:100%"
    )
  )
}



clientPanel <- function() {
  
  tabPanel(
    "Client View",
    value = "clientPanel",
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 100% !important;
                      }
                      .html-widget.gauge svg {
                        height: 300px;
                        width: 600px;
                      }
                      "))
    ),
    shinyjs::useShinyjs(),
    
    fluidRow(
      div( id = "topActionClients",
           column(3, class = "pull-left",
                  panel(
                    span(align = "center", h2("Top Action Clients")),
                    span(align = "center", h5("Click on Client for further information")),
                    br(),
                    uiOutput("topClients")
                  )
                  
           )
      ),
      hidden(
        tags$div(
          id = "clientInfoPanel",
          column(6,
                 panel(
                   span(align = "center", h2("Client Information")),
                   br(),
                   column(6,
                          uiOutput("clientInfo1")
                   ),
                   column(6,
                          uiOutput("clientInfo2")
                   )
                 ),
                 #panel(
                 #span(align = "center", h2("Client Monthly Energy Usage")),
                 #plotOutput("monthlyUsage")
                 #),
                 panel(
                   span(align = "center", h2("Client Retail Information")),
                   br(),
                   column(6,
                          uiOutput("clientRetailInfo1")
                   ),
                   column(6,
                          uiOutput("clientRetailInfo2")
                   )
                 )
          )
        )
      )
    ),
    fluidRow(
      panel(
        h3("Client Attrition Prediction "),
        br(),
        
        tags$div(
          id = "authPanel",
          column(4,
                 panel(
                   h4("Connect to Cloud Pak for Data API"),
                   textInput("hostname", "CPD Hostname"),
                   textInput("username", "CPD Username"),
                   passwordInput("password", "CPD Password"),
                   actionButton("authBtn", "Authenticate API", class = "btn-primary btn-lg btn-block", style = "max-width:300px", disabled = TRUE),
                   tags$head(tags$style("#authError{color:red;}")),
                   verbatimTextOutput("authError")
                 ),
                 style = "max-width:360px;"
          )
        ),
        hidden(
          tags$div(
            id = "deploymentPanel",
            column(4,
                   panel(
                     tags$h4("Model Scoring Pipeline Deployment"),
                     pickerInput(
                       inputId = 'deploymentSelector',
                       label = 'Deployment Name:',
                       choices = list(),
                       options = pickerOptions(width = "auto", style = "btn-primary")
                     ),
                     tags$p(
                       tags$strong("Space Name: "),
                       textOutput(outputId = "space_name", inline = TRUE)
                     ),
                     tags$p(
                       tags$strong("GUID: "),
                       textOutput(outputId = "deployment_guid", inline = TRUE)
                     ),
                     tags$p(
                       tags$strong("Tags: "),
                       textOutput(outputId = "deployment_tags", inline = TRUE)
                     ),
                     tags$p(
                       tags$strong("Scoring Endpoint: "),
                       textOutput(outputId = "scoring_url", inline = TRUE),
                       style = "word-wrap: break-word"
                     )),
                   panel(
                     actionButton(
                       "reauthenticateBtn",
                       "Re-Authenticate",
                       class = "btn-info btn-lg btn-block"
                     ) 
                   )
            ),
            tags$div(id = "scoreBtnSection",
                     column(4,
                            br(),
                            actionButton(
                              "scoreBtn",
                              "Predict Client Attrition",
                              class = "btn-primary btn-lg btn-block",
                              disabled = TRUE
                            ),
                            br(),
                            h4("Input JSON:"),
                            verbatimTextOutput("pipelineInput"),
                            br(),
                            tags$head(tags$style("#scoringError{color:red;}")),
                            verbatimTextOutput("scoringError"))
            ),
            column(8,
                   hidden(
                     tags$div(id = "scoringResponse")
                   )
            )
          )
        )
      )
      
    )
  )
  
}


# Reactive server variables store (pervades across all sessions)
serverVariables = reactiveValues(deployments = list(), token = '')

if(nchar(Sys.getenv('CP4D_HOSTNAME')) > 0 && nchar(Sys.getenv('CP4D_USERNAME')) > 0 && nchar(Sys.getenv('CP4D_PASSWORD')) > 0) {
  tryCatch({
    deploymentsResp = collectDeployments(Sys.getenv('CP4D_HOSTNAME'), Sys.getenv('CP4D_USERNAME'), Sys.getenv('CP4D_PASSWORD'), "attrition_scoring_pipeline_function_deployment")
    serverVariables$deployments <- deploymentsResp$deployments
    serverVariables$token = deploymentsResp$token
  }, warning = function(w) {
    print(w$message)
  }, error = function(e) {
    print(e$message)
  })
}

clientServer <- function(input, output, session, sessionVars) {
  
  
  # Observation events for client buttons
  lapply(clients,
         function(client){
           x <- paste0('client-btn-', client$clientId)
           observeEvent(
             input[[x]],
             {
               shinyjs::enable("scoreBtn")
               shinyjs::show(id = "clientInfoPanel")
               
               sessionVars$selectedClientId <- client$clientId
               client_name <- client$name
               client_id <- client$clientId
               client_age <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "AGE"]
               client_segment <- str_to_title(df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "SEGMENT"])
               client_employment <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "EMPLOYMENT"] 
               client_city <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "CITY"] 
               client_tenure <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "TENURE"] 
               client_complaints <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "COMPLAINTS"] 
               client_complaints<- gsub(1, "Yes", client_complaints)
               client_complaints<- gsub(0, "No", client_complaints)
               client_energy_usage <- round(df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "ENERGY_USAGE_PER_MONTH"])
               client_energy_efficiency <- round(df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "ENERGY_EFFICIENCY"], 2)
               client_home_owner <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "OWNS_HOME"]
               client_home_owner<- gsub(1, "Yes", client_home_owner)
               client_home_owner<- gsub(0, "No", client_home_owner)
               client_has_thermostat <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "HAS_THERMOSTAT"]
               client_has_thermostat<- gsub(1, "Yes", client_has_thermostat)
               client_has_thermostat<- gsub(0, "No", client_has_thermostat)               
               client_has_home_automation <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "HAS_HOME_AUTOMATION"]
               client_has_home_automation<- gsub(1, "Yes", client_has_home_automation)
               client_has_home_automation<- gsub(0, "No", client_has_home_automation)               
               client_smart_meter_comments <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "SMART_METER_COMMENTS"]
               client_pv_zoning <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "PV_ZONING"]
               client_pv_zoning<- gsub(1, "Yes", client_pv_zoning)
               client_pv_zoning<- gsub(0, "No", client_pv_zoning)               
               client_has_pv <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "HAS_PV"]
               client_has_pv<- gsub(1, "Yes", client_has_pv)
               client_has_pv<- gsub(0, "No", client_has_pv)               
               client_wind_zoning <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "WIND_ZONING"]
               client_wind_zoning<- gsub(1, "Yes", client_wind_zoning)
               client_wind_zoning<- gsub(0, "No", client_wind_zoning)               
               client_has_wind <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "HAS_WIND"]
               client_has_wind<- gsub(1, "Yes", client_has_wind)
               client_has_wind<- gsub(0, "No", client_has_wind)               
               client_car_owner <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "IS_CAR_OWNER"]
               client_car_owner<- gsub(1, "Yes", client_car_owner)
               client_car_owner<- gsub(0, "No", client_car_owner)               
               client_has_ev <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "HAS_EV"]
               client_has_ev<- gsub(1, "Yes", client_has_ev)
               client_has_ev<- gsub(0, "No", client_has_ev)     
               
               # if the customer has an electric vehicle they must be a car owner
               if (client_has_ev==1) {
                 client_car_owner <- "Yes"
               }
               
               if (client_car_owner==0) {
                 client_has_ev <- "NA"
               }
               
               
               
               output$clientInfo1 <- renderUI({
                 
                 tags$ul( class = 'list-unstyled',
                          tags$li(
                            tags$strong('Name: '), tags$span(class = "pull-right", client_name)
                          ),
                          tags$li(
                            tags$strong('ID: '), tags$span(class = "pull-right", client_id)
                          ),
                          tags$li(
                            tags$strong('Segment: '), tags$span(class = "pull-right", client_segment)
                          ),
                          tags$li(
                            tags$strong('Age: '),tags$span(class = "pull-right", client_age)
                          ),
                          tags$li(
                            tags$strong('City: '), tags$span(class = "pull-right", client_city)
                          ),
                          tags$li(
                            tags$strong('Employment Status: '), tags$span(class = "pull-right", client_car_owner)
                          )
                 )
               })
               
               output$clientInfo2 <- renderUI({
                 tags$ul( class = 'list-unstyled',
                          tags$li(
                            tags$strong('Tenure: '), tags$span(class = "pull-right", client_tenure, " Months")
                          ),
                          tags$li(
                            tags$strong('Previously Made Complaint: '),tags$span(class = "pull-right", client_complaints)
                          ),
                          tags$li(
                            tags$strong('Average Monthly Energy Usage: '), tags$span(class = "pull-right", client_energy_usage, "KWh")
                          ),
                          tags$li(
                            tags$strong('Energy Efficiency: '), tags$span(class = "pull-right", client_energy_efficiency)
                          )
                 )
               })
               
               
               output$clientRetailInfo1 <- renderUI({
                 tags$ul( class = 'list-unstyled',
                          tags$li(
                            tags$strong('Home Owner: '), tags$span(class = "pull-right", client_home_owner)
                          ),
                          tags$li(
                            tags$strong('Smart Meter Comments: '),tags$span(class = "pull-right", client_smart_meter_comments)
                          ),
                          tags$li(
                            tags$strong('Thermostat Installed: '), tags$span(class = "pull-right", client_has_thermostat)
                          ),
                          tags$li(
                            tags$strong('Home Automation: '), tags$span(class = "pull-right", client_has_home_automation)
                          ),
                          tags$li(
                            tags$strong('   ')
                          ),
                          tags$li(
                            tags$strong('Owns Vehicle: '), tags$span(class = "pull-right", client_car_owner)
                          ),
                          tags$li(
                            tags$strong('Vehicle is Electric: '), tags$span(class = "pull-right", client_has_ev)
                          )
                 )
               })               
               
               output$clientRetailInfo2 <- renderUI({
                 tags$ul( class = 'list-unstyled',
                          tags$li(
                            tags$strong('Wind Zoned: '), tags$span(class = "pull-right", client_wind_zoning)
                          ),
                          tags$li(
                            tags$strong('Has Wind Energy: '),tags$span(class = "pull-right", client_has_wind)
                          ),
                          tags$li(
                            tags$strong('    ')
                          ),
                          tags$li(
                            tags$strong('PV Zoned: '), tags$span(class = "pull-right", client_pv_zoning)
                          ),
                          tags$li(
                            tags$strong('Has PV Energy: '), tags$span(class = "pull-right", client_has_pv)
                          )
                 )
               })    
             }
           )
         })
  
  
  # create the button for clients
  output$topClients <- renderUI({
    
    # List of client buttons
    lapply(clients, function(client){
      client_contract <- df_unseen[df_unseen["CUSTOMER_ID"]==client$clientId, "CURRENT_CONTRACT"]
      clientButton(client$clientId, client$name, client_contract, paste0("profiles/", client$image))
    })
    
  })
  
  observe({
    # filter the csv for the selected customer and use as input for the API
    df_filtered <- df_unseen[df_unseen["CUSTOMER_ID"]==sessionVars$selectedClientId, ]
    # remove columns that weren't in the original input dataset
    # we need to do this becuase of the csv file we're using for demo
    # in real scenario this data would come from db or raw csv
    df_filtered$actual <- NULL
    df_filtered$predicted_probability <- NULL	
    df_filtered$Bin <- NULL	
    df_filtered$predicted_class <- NULL
    df_filtered$dataset <- NULL
    
    json_data <- jsonlite::toJSON(df_filtered)
    
    
    # Reset scoring
    removeUI(selector = "#scoringResponse > *", multiple = TRUE)
    shinyjs::hide(id = "scoringResponse")
    shinyjs::show(id = "scoreBtnSection")
    output$scoringError <- renderText('')
    sessionVars$pipelineInput <- json_data
    output$pipelineInput <- renderText(json_data)
  })
  
  # Set default hostname for CP4D API
  observeEvent(session$clientData$url_hostname, {
    updateTextInput(session, "hostname", value = session$clientData$url_hostname)
  })
  
  # Enable buttons when inputs are provided
  observe({
    toggleState("authBtn", nchar(input$hostname) > 0 && nchar(input$username) > 0 && nchar(input$password) > 0)
    toggleState("scoreBtn", nchar(input$endpoint) > 0 && nchar(input$token) > 0 && length(input$allCustomers_rows_selected) > 0)
  })
  
  # Handle CP4D API authentication button
  observeEvent(input$authBtn, {
    shinyjs::disable("authBtn")
    
    tryCatch({
      deploymentsResp = collectDeployments(input$hostname, input$username, input$password, "attrition_scoring_pipeline_function_deployment")
      serverVariables$deployments <- deploymentsResp$deployments
      serverVariables$token = deploymentsResp$token
    }, warning = function(w) {
      output$authError <- renderText(w$message)
    }, error = function(e) {
      output$authError <- renderText(e$message)
    })
    
    shinyjs::enable("authBtn")
    
    if(length(serverVariables$deployments) > 0) {
      updateSelectInput(session, "deploymentSelector", choices = names(serverVariables$deployments))
      shinyjs::hide(id = "authPanel")
      shinyjs::show(id = "deploymentPanel")
    }
  })
  
  # Handle model deployment dropdown switching
  observeEvent(input$deploymentSelector, {
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    output$deployment_guid <- renderText(selectedDeployment$guid)
    output$space_name <- renderText(selectedDeployment$space_name)
    output$deployment_tags <- renderText(selectedDeployment$tags)
    output$scoring_url <- renderText(selectedDeployment$scoring_url)
    toggleState("scoreBtn", nchar(selectedDeployment$scoring_url) > 0 && nchar(serverVariables$token) > 0)
  })
  
  observeEvent(input$scoreBtn, {
    shinyjs::disable("scoreBtn")
    
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    sessionVars$selectedDeployment <- selectedDeployment
    
    payload <- sessionVars$pipelineInput
    
    response <- scoreModelDeployment(selectedDeployment$scoring_url, payload, serverVariables$token)
    
    if(length(response$error) > 0) {
      output$scoringError <- renderText(toString(response$error))
    } else if (length(response$predictions) > 0) {
      shinyjs::hide(id = "scoreBtnSection")
      shinyjs::show(id = "scoringResponse")
      
      predicted_prob <- response$predictions[[1]]$values$predictions[[1]]$values[[1]][[2]][[2]]
      
      insertUI(
        selector = "#scoringResponse",
        where = "beforeEnd",
        ui = panel(
          tags$head(
            tags$style(HTML("
                      .datatables {
                      width: 100% !important;
                      }
                      .html-widget.gauge svg {
                        height: 300px;
                        width: 600px;
                      }
                      "))
          ),
          h3("Client Attrition Probability:"),
          p(
            gaugeOutput("gauge")
          )
        )
      )
      
      output$gauge = renderGauge({
        gauge(round(predicted_prob*100), 
              symbol = '%',
              min = 0, 
              max = 100, 
              sectors = gaugeSectors(success = c(0, 30),
                                     warning = c(30, 70),
                                     danger = c(70, 100)))
      })
    } else {
      output$scoringError <- renderText(response)
    }
    
    
  })
  observeEvent(input$reauthenticateBtn, {
    shinyjs::show(id = "scoreBtnSection")
    removeUI(selector = "#scoringResponse > *", multiple = TRUE)
    shinyjs::show(id = "authPanel")
    shinyjs::hide(id = "deploymentPanel")
    shinyjs::enable("scoreBtn")
  })
  
}




