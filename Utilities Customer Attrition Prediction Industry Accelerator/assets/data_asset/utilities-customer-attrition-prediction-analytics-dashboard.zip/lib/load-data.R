# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyrig ht IBM Corp. 2019. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

# Load Data from CSV files
library(readr)
library(scales)

set.seed(0)
readDataset <- function(fileName) {read.csv(file.path(fileName), stringsAsFactors = FALSE)}

df <- readDataset("model output summary.csv")

# split the data between the seen and unseen
# seen data has the actual target variable as well as the predictions - used for model insights
# the unseen data has predictions from the training notebook but no actuals - for demo purposes only - we are reusing the valiation and test data

df_unseen <- df[df['dataset']=='Unseen', ]
df <- df[df['dataset']=='Seen', ]

# the ordering hasn't been preserved
df <- df[order(-df$predicted_probability),]
df_unseen <- df_unseen[order(-df_unseen$predicted_probability),]

l_clientIDs <- c(2, 18105, 27212, 3088, 20)

# if the pre-defined customer ID's aren't in the unseen data select a random customer
i <- 1
for (clientID in l_clientIDs) {
    if (!(clientID %in% as.numeric(unlist(df_unseen["CUSTOMER_ID"])))) {
      l_clientIDs[i] <- sample(df_unseen[, "CUSTOMER_ID"], 1)
      i <- i + 1
    } 
}



clients <- list(
  list(name="Ima Labadie", image="1F.jpg", clientId=l_clientIDs[1]),
  list(name="Aiden Russel", image="2M.jpg", clientId=l_clientIDs[2]),
  list(name="Andrew Johns", image="3M.jpg", clientId=l_clientIDs[3]),
  list(name="Heidi Grant", image="7F.jpg", clientId=l_clientIDs[4]),
  list(name="Jesse Grady", image="4M.jpg", clientId=l_clientIDs[5])
)


