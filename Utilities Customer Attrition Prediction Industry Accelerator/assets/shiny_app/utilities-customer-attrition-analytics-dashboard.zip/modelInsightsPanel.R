# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.


modelInsightPanel <- function() {
  
  
  tabPanel(
    "Model Insights",
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 90% !important;
                      }
                      .shiny-split-layout > div {
                                overflow: visible;
                      }
                      .small-box {height: 75px}
                      .fa { font-size: 40px; }
                      "))
    ),
    shinyjs::useShinyjs(),
    useShinydashboard(),
    
    fluidRow(
      column(12, 
             panel(
               valueBoxOutput("numCustomers"),
               valueBoxOutput("attritedCustomers"),
               valueBoxOutput("percAttritedCustomers")
             )
      )
    ),
    fluidRow(
      column(2, 
             
             panel(
                
               checkboxGroupInput("seg_checkbox", "Choose Segment(s):",
                                  choices = str_to_title(as.character(unique(df$SEGMENT))),
                                  selected = str_to_title(as.character(unique(df$SEGMENT))),
               ),
               checkboxGroupInput("city_checkbox", "Choose City(s):",
                                  choices = as.character(unique(df$CITY)),
                                  selected = as.character(unique(df$CITY)),
               ),
               checkboxGroupInput("contract_checkbox", "Choose Current Contract(s):",
                                  choices = as.character(unique(df$CURRENT_CONTRACT)),
                                  selected = as.character(unique(df$CURRENT_CONTRACT)),
               ),  
               selectInput("complaints", "Has the Customer Previously Complained?",
                           c("Either" = 99,
                             "No" = 0,
                             "Yes" = 1), selected=99
               )
               
             )
      ),
      column(5,
             panel(
               h3("Percentage of customers predicted to Attrit"),
               br(),
               plotOutput("pieAttrit", width = "100%", height = "460px")
               #br(),
               #br(),
               #br()
             ),
             
             panel(
               h3("Customers Ranked on their Predicted Attrition Probability"),
               h4("Click on a point on the cumulative gains chart to filter only clients within the threshold"),
               
               dataTableOutput("showFilteredTable")
               # br(),
               # downloadButton("downloadData", "Download Table")
             )
      ),
      column(5,             
             panel(
               h3("Optimize Customer Attrition Targeting"),
               h5("Use the cumulative gains and lift charts below to optimize customer targeting by selecting the customers most likely to attrit "),
               h6("The cumulative gains chart shows the percentage of attrited customers selected by targeting a specific percentage of total customers. Click on a red point in the chart to get a  description of the result."),
               plotOutput("cumGainPlot", click = "cumGainsClick"),

             ),
             panel(
               hidden(
                 tags$div(id = "gainsThresholdText",
                          h4(htmlOutput("describeCutoff"))
                 )
               ),
               h3("Lift Chart"),
               h6("The Lift chart is derived from the cumulative gains chart. It shows the ratio of the cumulative gain from the model vs random choice. "),
               plotOutput("liftPlot"),
               br()
             )
      )
    )
  )
}



insightsServer <- function(input, output, session) {
  
  
  
  
  
  
  observe({
    
    # we filter the datasets based on the user's selection
    # filter both datasets - df which is the seen data that has the actual target
    # and df_unseen, where we don't know the actual attrition value
    selected_segment <- str_to_upper(input$seg_checkbox)
    selected_city <- input$city_checkbox
    selected_complaint <- input$complaints
    #selected_gender <- input$gender_checkbox
    selected_contract <- input$contract_checkbox

  

    # if the user has selected to show both customer's who have and haven't made complaints previously
    # they input is set to 99, we don't include the complaints in the filter
    if (selected_complaint==99) {
      df_temp <- dplyr::filter(df, (df$SEGMENT %in% selected_segment) & (df$CITY %in% selected_city) & (df$CURRENT_CONTRACT %in% selected_contract) )
      df_temp_unseen <- dplyr::filter(df_unseen, (df_unseen$SEGMENT %in% selected_segment) & (df_unseen$CITY %in% selected_city) & (df_unseen$CURRENT_CONTRACT %in% selected_contract)
      )      
    } else {
      df_temp <- dplyr::filter(df, (df$SEGMENT %in% selected_segment) & (df$CITY %in% selected_city)
                               & (df$COMPLAINTS %in% selected_complaint)  & (df$CURRENT_CONTRACT %in% selected_contract) )
      df_temp_unseen <- dplyr::filter(df_unseen, (df_unseen$SEGMENT %in% selected_segment) & (df_unseen$CITY %in% selected_city) 
                                      & (df_unseen$COMPLAINTS %in% selected_complaint)  & (df_unseen$CURRENT_CONTRACT %in% selected_contract) )
    }


    df_temp$Bin <- ntile(as.numeric(rownames(df_temp)), 20)
    df_temp_unseen$Bin <- ntile(as.numeric(rownames(df_temp_unseen)), 20)
    
    # get the cumulative % of customers
    df_temp$cumulativePercCust <- (1:nrow(df_temp))/nrow(df_temp)   
    df_temp_unseen$cumulativePercCust <- (1:nrow(df_temp_unseen))/nrow(df_temp_unseen) 
    
    
    
    num_customers <- dim(df_temp)[1]
    num_predicted_attrited <- sum(df_temp$predicted_class)
    perc_predicted_attrited <- round((num_predicted_attrited/num_customers)*100)
    

    df_temp_attrit_perc <- df_temp %>%
      group_by(predicted_class) %>%
      summarize(num_cust = n()) %>%
      mutate(perc_cust = num_cust/sum(num_cust))  %>%
      as.data.frame()
    
    df_temp_attrit_perc$predicted_class[df_temp_attrit_perc$predicted_class == 1] <- "Predicted to Attrit"
    df_temp_attrit_perc$predicted_class[df_temp_attrit_perc$predicted_class == 0] <- "Predicted to Retain"
    
    df_summary <- df_temp %>%
      group_by(Bin) %>%
      summarize(num_cust = n(), num_attrited_cust=sum(actual)) %>%
      mutate(cumulative_perc_cust = cumsum(num_cust)/sum(num_cust))  %>%
      mutate(cumulative_perc_attrited_cust = cumsum(num_attrited_cust)/sum(num_attrited_cust)) %>%
      mutate(lift = cumulative_perc_attrited_cust / cumulative_perc_cust) %>%
      as.data.frame()
    
    df_summary <- rbind(c(0,0,0,0,0), df_summary)
    
    output$cumGainPlot <- renderPlot({
      #req(input$var_y)
      #ggplot(df_summary, aes_string("cumulative_perc_attrited_cust", input$var_y)) + 
      #geom_point()
      ggplot(df_summary, aes(x=cumulative_perc_cust, y=cumulative_perc_attrited_cust)) + 
        geom_line(color="red") + 
        geom_point(color="red") + 
        geom_segment(aes(x = 0, y = 0, xend = 1, yend = 1), color="grey") +
        theme_minimal() +
        theme(legend.position = c(0, 1)) +
        scale_x_continuous(breaks = seq(0, 1, by = 0.1)) + 
        scale_y_continuous(breaks = seq(0, 1, by = 0.1)) +
        labs(x = "Cumulative % of Customers", y = "Cumulative % of Attrited Customers")
      
    })
    
    output$liftPlot <- renderPlot({
      ggplot(tail(df_summary, -1), aes(x=cumulative_perc_cust, y=lift)) + 
        geom_line(color="red") + 
        geom_point(color="red") + 
        geom_hline(yintercept=1, linetype = "dashed", color="black") +
        expand_limits(x = 0, y = 0) +
        theme_minimal() + 
        theme(legend.position="top") + 
        scale_x_continuous(breaks = seq(0, 1, by = 0.1)) +
        labs(x = "Cumulative % of Customers", y = "Lift")
      
    })
    
    #not used
    df_temp_attrit_perc$CUSTOMER_PERCENTGE=df_temp_attrit_perc$perc_cust
    df_temp_attrit_perc$PREDICTED_CLASS=df_temp_attrit_perc$predicted_class
    
    output$pieAttrit <- renderPlot({
      ggplot(data=df_temp_attrit_perc)+
        geom_bar(aes(x="", y=CUSTOMER_PERCENTGE, fill=PREDICTED_CLASS), stat="identity", width = 1,color="white")+
        coord_polar("y", start=0)+
        geom_text(aes(x=1, y = cumsum(CUSTOMER_PERCENTGE) - CUSTOMER_PERCENTGE/2, label=paste0(round(CUSTOMER_PERCENTGE*100), "%"))) +
        scale_fill_brewer(palette="Blues")+
        theme_void()
      
      
      
    })
    
    
    output$numCustomers <- renderValueBox({
      shinydashboard::valueBox(
        tags$p(paste0(format(num_customers,big.mark = ',')), style = "font-size: 30px;"), 
        tags$p(" Clients Analyzed", style = "font-size: 15px;"),
        color = "aqua", width = 4, icon = icon("user")
      )
    })
    
    output$attritedCustomers <- renderValueBox({
      shinydashboard::valueBox(
        tags$p(paste0(format(num_predicted_attrited,big.mark = ',')), style = "font-size: 30px;"), 
        tags$p(" Clients Predicted to Attrit", style = "font-size: 15px;"),
        color = "red", width = 4, icon = icon("walking")
      )
    })
    
    output$percAttritedCustomers <- renderValueBox({
      shinydashboard::valueBox(
        tags$p(paste0(perc_predicted_attrited, "%"), style = "font-size: 30px;"), 
        tags$p(" Predicted Attrition Rate", style = "font-size: 15px;"),
        color = "red", width = 4, icon = icon("percent")
      )
    })
    
    
    
    coords <- reactiveValues(x = NULL, y = NULL, filtered_df = NULL)
    
    # when the user selects the cutoff point, we display the unseen data that meets the probability threshold
    output$showFilteredTable <- DT::renderDataTable({
      
      list_nearest_points <- nearPoints(select(df_summary, "cumulative_perc_cust", "cumulative_perc_attrited_cust"), input$cumGainsClick)
      x_val <- round(list_nearest_points[[1]], 2)
      y_val <- round(list_nearest_points[[2]], 2)
      
      coords$x <- x_val
      coords$y <-y_val
      
      if (length(x_val)) {
        shinyjs::show(id = "gainsThresholdText")
        filtered_df <- df_temp_unseen[df_temp_unseen["cumulativePercCust"]<=x_val, ]
        filtered_df <- select(filtered_df, "CUSTOMER_ID", "FIRST_NAME",	"LAST_NAME", "PHONE_1", "EMAIL", "predicted_probability")
        #kf <- filtered_df[order(-filtered_df$predicted_probability),]
        filtered_df$predicted_probability <- filtered_df$predicted_probability * 100
        filtered_df <- filtered_df[order(-filtered_df$predicted_probability),]
        filtered_df <- filtered_df %>% mutate_if(is.numeric, round, 1)
        
        if (dim(filtered_df)[1] > 0) {
          filtered_df$predicted_probability <- paste0(as.character(filtered_df$predicted_probability), "%")
        }
        
        
        
        filtered_df <- rename(filtered_df, 'Attrition Probability' = 'predicted_probability')
        
        coords$filtered_df <- filtered_df
        
      } else {
        filtered_df <- select(df_temp_unseen, "CUSTOMER_ID", "FIRST_NAME",	"LAST_NAME", "PHONE_1", "EMAIL", "predicted_probability")
        filtered_df$predicted_probability <- filtered_df$predicted_probability * 100
        filtered_df <- filtered_df[order(-filtered_df$predicted_probability),]
        filtered_df <- filtered_df %>% mutate_if(is.numeric, round, 1)
        if (dim(filtered_df)[1] > 0) {
          filtered_df$predicted_probability <- paste0(as.character(filtered_df$predicted_probability), "%")
        }
        
        
        filtered_df <- rename(filtered_df, 'Attrition Probability' = 'predicted_probability')
      }
    }, rownames = FALSE, selection = 'single',  options = list(pageLength = 5),server = FALSE)
    
    output$describeCutoff <- renderUI({
      str <- paste0("By targeting the top <b>", (coords$x*100), "%</b> of customers, we reach <b>", (coords$y*100), "%</b> of attrited customers in the training data.")
      HTML(str)
    })
    
    
    
    
  })
  
  
}
