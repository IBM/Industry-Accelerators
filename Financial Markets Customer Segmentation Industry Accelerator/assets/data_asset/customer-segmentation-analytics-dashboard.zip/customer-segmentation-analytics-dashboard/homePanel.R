# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2019, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

getMinMax <-function(d_f,cluster)
{
  colMax <- function(data) sapply(data, max, na.rm = TRUE)
  colMin <- function(data) sapply(data, min, na.rm = TRUE)
  
  num_df <- select_if(d_f, is.numeric)
  num_df$X=NULL
  
  temp_df <- subset(num_df, CLUSTERS==cluster)  
  temp_df$CLUSTERS=NULL
  
  new_df = array(0,dim=c(2,ncol(temp_df)))
  new_df[1,]=colMax(temp_df)
  new_df[2,]=colMin(temp_df)
  
  final =data.frame(new_df)
  names(final)=names(temp_df)
  rownames(final)<-c("Maximum","Minimum")
  
  return(final) 
}


clientButton <- function(id, name, image, income, segment = NULL) {
  tags$p(
    actionButton(paste0('client-btn-', id),
                 fluidRow(
                   column(4, 
                          tags$img(class = "pull-left", src = image, width = "60px", height = "60px")
                   ),
                   column(3,
                          tags$h4(strong(name)),
                          tags$h6(em(paste('Customer ID: ', id))),
                          tags$h6(em(paste('Income: ', income))),
                          if(!is.null(segment)) {
                            tags$h6(em(paste('Segment: ', segment)))
                          }
                          
                   )
                 ),
                 style="width:100%"
    ),
    clientInfo(id)
  )
}

clientInfo <- function(id) {
  hidden(
    tags$ul(id= paste0("clientInfo-",id), class = 'list-unstyled',
            tags$li(
              tags$strong('Behavior: '), tags$span(class = "pull-right", customerInfo[customerInfo$CUSTOMER_ID == id,"CUSTOMER_BEHAVIOR"])
            ),
            tags$li(
              tags$strong('Financial Pursuit: '),tags$span(class = "pull-right", customerInfo[customerInfo$CUSTOMER_ID == id,"PURSUIT"])
            ),
            tags$li(
              tags$strong('Market Group: '), tags$span(class = "pull-right", customerInfo[customerInfo$CUSTOMER_ID == id,"MARKET_GROUP"])
            )
    ))
}


refreshCode <- "shinyjs.refresh = function() { location.reload(); }"

homePanel <- function() {
  
  tabPanel(
    "Dashboard",
    
    tags$head(
      tags$style(HTML("
                      .datatables {
                      width: 100% !important;
                      }
                      "))
    ),
    shinyjs::useShinyjs(),
    shinyjs::extendShinyjs(text = refreshCode, functions = c("refresh")),
    
    fluidRow(
      div( id = "topActionClients",
           column(3, class = "pull-left", panel(
             span(align = "center", h2("TOP ACTION CLIENTS")),
             span(align = "center", h5("Click on Client for Behavioral features")),
             br(), 
             uiOutput("segmentClients")
           ))
      ),
      
      div(id = "Customer Segments",align="center",
          column (4, panel(
            h2("OVERALL CUSTOMER SEGMENTS "),
            h4("Choose segment for top stats"),
            
            d3Output("d3"), align = "center"
            
          ), #panel
          panel(
            h2("TOP STATS OF SEGMENT"), align = "center",
            br(),
            h5("Most frequent features of the segment"), htmlOutput("features")
          )
          
        )
      ),#end of div bubbles
      
      
      div(id = "Segment ",align = "right",
          
          column (5, class = "pull-right",
                  
                  
                  
                  div(id = "Plots",
                      panel(h2("CUSTOMER SEGMENT FEATURES"),align = "center",
                        textOutput("selected"),
                        br(),
                        
                        #column(6,
                              
                               plotlyOutput('pursuitPlot', height="250px", width="400px"),
                        #column(6, 
                               plotlyOutput('behavePlot', height="250px", width="400px"),
                        #column(6, 
                               plotlyOutput('spendPlot', height="250px", width="400px"),
                      #  column(6, 
                               plotlyOutput('marketPlot', height="250px", width="400px")
                      
                       
                        
                      )         
                  )#div
                  
                  
          )
          
      ),#end of div stats
      
      div(id = "Stats ",
       column(6,
        h2("FINANCIAL STATS OF SEGMENT"), align="center",
        br(),
        tableOutput('statTable')
      )
    ),
      # panel
    
    uiOutput("segmentTable"),
      
      div(id = "rightPanel",
          column(8, 
                 panel(
                   
                   h2("Customer Segmentation"),
                   br(),
                   
                   tags$div(
                     id = "authPanel",
                     column(5,
                            panel(
                              h4("Connect to IBM Cloud API"),
                              br(),
                              
                              pickerInput(
                                inputId = 'username',
                                label = 'Select a Region',
                                choices = list("us-south","eu-de","eu-gb","jp_tok"),
                                options = pickerOptions(width = "auto", style = "btn-primary")
                              ),
                              passwordInput("password", "API KEY"),
                              actionButton("authBtn", "Authenticate API", class = "btn-primary btn-lg btn-block", style = "max-width:300px", disabled = TRUE),
                              tags$head(tags$style("#authError{color:red;}")),
                              verbatimTextOutput("authError")
                            ),
                            style = "max-width:360px;"
                     )
                   ),
                   
                   hidden(
                     tags$div(
                       id = "deploymentPanel",

                       panel(
                         
                         fluidRow(
                           
                           column(6,
                                  tags$div(id = "scoreBtnSection",
                                           h4("Input JSON:"),
                                           verbatimTextOutput("pipelineInput"),
                                           br(),
                                           actionButton(
                                             "scoreBtn",
                                             "Segment Customers",
                                             class = "btn-primary btn-lg btn-block",
                                             disabled = TRUE
                                           ),
                                           tags$head(tags$style("#scoringError{color:red;}")),
                                           verbatimTextOutput("scoringError")
                                  )),
                           column(6,
                                  
                                  tags$h4("Model Scoring Pipeline Deployment"),
                                  pickerInput(
                                    inputId = 'deploymentSelector',
                                    label = 'Deployment Name:',
                                    choices = list(),
                                    options = pickerOptions(width = "auto", style = "btn-primary")
                                  ),
                                  tags$p(
                                    tags$strong("Space Name: "),
                                    textOutput(outputId = "space_name", inline = TRUE)
                                  ),
                                  tags$p(
                                    tags$strong("GUID: "),
                                    textOutput(outputId = "deployment_guid", inline = TRUE)
                                  ),
                              #    tags$p(
                              #      tags$strong("Tags: "),
                              #      textOutput(outputId = "deployment_tags", inline = TRUE)
                              #    ),
                                  tags$p(
                                    tags$strong("Scoring Endpoint: "),
                                    textOutput(outputId = "scoring_url", inline = TRUE),
                                    style = "word-wrap: break-word"
                                  )
                           )
                           #panel(
                           # actionButton(
                           #    "reauthenticateBtn",
                           #   "Re-Authenticate",
                           #   class = "btn-primary btn-lg"
                           #  ) 
                           #)
                         )))),
                   tags$div(id = "scoringResponse")
                 )
          )))
  )
}



#BUBBLEPLOT

getmode <- function(v) {
  v = as.vector(v)
  uniqv <- unique(v)
  if(length(unique(tabulate(match(v, uniqv))))==1){
    return(v)
  }
  else{
    return(uniqv[which.max(tabulate(match(v, uniqv)))])
  }
}

getmode_results <- function(d_f){
  
  
  catCols= c()
  k=1
  for(i in 1:ncol(d_f)){
    if(class(d_f[,i])=="factor"){
      catCols[k]=colnames(d_f)[i]
      k=k+1
    }
  }
  
  new_df=c()
  
  i=1
  k=1
  while(i <= length(unique(d_f$CLUSTERS))){
    
    f<-subset(d_f, CLUSTERS==i)
    
    for(j in 1:ncol(f)){
      if(class(f[,j])=="factor"){
        new_df[k] = getmode(f[,j])
        k=k+1
      }
    }
    if(i==1){
      mode_results = new_df
    }
    else{
      mode_results = rbind(mode_results, new_df)
    }
    k=1
    
    i=i+1
  }
  
  mode_results = data.frame(mode_results)
  colnames(mode_results)=catCols
  return(mode_results)
}

df <- cluster_df
df$X1 <- NULL

topFeatures <- getmode_results(df)


data1 <- (df %>%
            group_by(CLUSTERS) %>%
            dplyr::select(CLUSTERS) %>%
            summarize(Count = n()) %>%
            arrange(desc(Count)))

xjson <- jsonlite::toJSON(data1)
# Generate the layout. This function return a dataframe with one line per bubble. 
# It gives its center (x and y) and its radius, proportional of the value
packing <- circleProgressiveLayout(data1$Count, sizetype='area')

# We can add these packing information to the initial data frame
data = cbind(data1, packing)
group=paste("Segment", data$CLUSTERS)
# Check that radius is proportional to value. We don't want a linear relationship, since it is the AREA that must be proportionnal to the value
plot(data$radius, data$Count)

# The next step is to go from one center + a radius to the coordinates of a circle that
# is drawn by a multitude of straight lines.
dat.gg <- circleLayoutVertices(packing, npoints=50)


segments <- ggplot() + 
  
  # Make the bubbles
  geom_polygon(data = dat.gg, aes(x, y, group = id, fill=as.factor(id)), colour = "black", alpha = 0.9) +
  
  # Add text in the center of each bubble + control its size
  geom_text(size = 5,data = data, aes(x, y, size=Count, label = group)) +
  scale_size_continuous(range = c(1,4)) +
  
  # General theme:
  theme_void() +  theme(legend.position="none") +
  coord_equal()


#----------------END OF BUBBLE PLOT


########################## END OF PLOT 1 #########################

# server variables (reactive)

serverVariables = reactiveValues(deployments = list(), token = '')

pipelineInput <- list(cust_id = as.list(clientIds), values = "2018-09-30")

homeServer <- function(input, output, session, sessionVars) {
  
  #default top client Actions
  output$segmentClients <- renderUI({
    
    # List of client buttons
    lapply(clientIds, function(id){
      client <- clients[[toString(id)]]
      clientButton(id, client$name, paste0("profiles/", client$image), client$income)
    })
  })
  
  
  #refresh page
  observeEvent( input$refresh, {shinyjs::js$refresh()})
  
  #toggle client informations
  observe({
    clientIds <- customerInfo[["CUSTOMER_ID"]]
    input_btn <- paste0("client-btn-",clientIds)
    lapply(input_btn, function(btn){
      observeEvent(
        input[[btn]],
        {
          shinyjs::toggleElement(paste0("clientInfo-",substr(btn,12,nchar(btn))))
        }
      )
    })
  }, label= "clientButtonObserver", priority = 10)
  
  output$d3 <- renderD3({
    r2d3(
      data = xjson, d3_version = 4, 
      script = "bar.js"
    )
  })
  
  output$selected <- renderText({
    bar_number <- as.numeric(req(input$bar_clicked))
    if (bar_number > 0) paste0("Current segment: ", toString(bar_number))
  })
  
  output$rbselect <- renderText({paste(as.numeric(req(input$bar_clicked)))}) #selection in bubbles
  # top features
  
  
  output$features <- renderUI({
    
    temp_df <- topFeatures[1,]
    if(length(input$bar_clicked) != 0) {
      temp_df <- topFeatures[strtoi(input$bar_clicked),]
    }
    
    str2 <- paste("")
    
    for(i in 1:ncol(temp_df)){
      
      str1 <- paste("<font color=\"#000000\"><b>",str_replace_all(colnames(temp_df)[i], "[^[:alnum:]]", " ")," : </b></font>","<font color=\"#FF0000\"><b>",temp_df[1,i],"<br /></b></font>")
      str2 <- paste(str2, str1)
    }
    HTML(paste(str2 , sep = '<br/>'))
  })

  #MinMax_df=getMinMax(cluster_df,1)
  output$statTable <- renderTable({
    if(is.null(input$bar_clicked)==TRUE)
    {
      MinMax_df <- getMinMax(cluster_df,1)
    }
    else{
      #print(input$bar_clicked)
      MinMax_df <- getMinMax(cluster_df,input$bar_clicked)
      }
    }, rownames = TRUE)
  
  output$pursuitPlot <- renderPlotly({

    plot_df <- subset(df, CLUSTERS == "1") 
    if(length(input$bar_clicked) != 0) {
      plot_df <- subset(df, CLUSTERS == input$bar_clicked)
      }
  
    feat1 <- plot_df %>%
      group_by(CUSTOMER_PURSUIT) %>%
      dplyr::select(CUSTOMER_PURSUIT) %>%
      summarize(Count = n()) %>%
      arrange(desc(Count))
  
    plot1 <- ggplot(data=feat1) +  aes(x=reorder(feat1$CUSTOMER_PURSUIT, - feat1$Count), y=feat1$Count) + 
      geom_bar(stat="identity", fill="steelblue", width = 0.4) +
      coord_flip()+
      labs(x=" Choice of Pursuit", y="Count", title="Customer Financial Pursuit") +
      theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )+
      theme(legend.position="none")
    
    ggplotly(plot1)%>%
      layout(autosize=TRUE)
  
  })
  
  output$behavePlot <- renderPlotly({
    
    plot_df <- subset(df, CLUSTERS == "1")
    if(length(input$bar_clicked) != 0) {
      plot_df <- subset(df, CLUSTERS == input$bar_clicked)
    }
    
    feat2 <- plot_df %>%
      group_by(CUSTOMER_CUSTOMER_BEHAVIOR) %>%
      dplyr::select(CUSTOMER_CUSTOMER_BEHAVIOR) %>%
      summarize(Count = n()) %>%
      arrange(desc(Count))
    
    plot2 <- ggplot(data=feat2) + aes(x=reorder(feat2$CUSTOMER_CUSTOMER_BEHAVIOR, - feat2$Count), y=feat2$Count) +
      geom_bar(stat="identity", fill="steelblue", width = 0.4) +
      coord_flip()+
      labs(x=" Type of Behavior", y="Count", title="Customer Behaviour Analysis") +
      theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )+
      theme(legend.position="none")
    
    ggplotly(plot2)%>%
      layout(autosize=TRUE)
    
  })
  
  
  output$spendPlot <-  renderPlotly({
    plot_df <- subset(df, CLUSTERS == "1")
    if(length(input$bar_clicked) != 0) {
      plot_df <- subset(df, CLUSTERS == input$bar_clicked)
    }
    
    
    feat3 <- plot_df %>%
      group_by(CUSTOMER_SUMMARY_TOP_SPENDING_CATEGORY) %>%
      dplyr::select(CUSTOMER_SUMMARY_TOP_SPENDING_CATEGORY) %>%
      summarize(Count = n()) %>%
      arrange(desc(Count))
    
    plot3 <- ggplot(data=feat3) + aes(x=reorder(feat3$CUSTOMER_SUMMARY_TOP_SPENDING_CATEGORY, - feat3$Count), y=feat3$Count) +
      geom_bar(stat="identity", fill="steelblue", width = 0.4) +
      coord_flip()+
      labs(x=" Customer Expenses", y="Count", title="Top Customer Expenditure") +
      theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )+
      theme(legend.position="none")
   
    ggplotly(plot3)%>%
      layout(autosize=TRUE)
  })
  
  output$marketPlot <-  renderPlotly({
    plot_df <- subset(df, CLUSTERS == "1")
    if(length(input$bar_clicked) != 0) {
      plot_df <- subset(df, CLUSTERS == input$bar_clicked)
    }
    
    
    feat4 <- plot_df %>%
      group_by(CUSTOMER_MARKET_GROUP) %>%
      dplyr::select(CUSTOMER_MARKET_GROUP) %>%
      summarize(Count = n()) %>%
      arrange(desc(Count))
    
    plot4 <- ggplot(data=feat4) + aes(x=reorder(feat4$CUSTOMER_MARKET_GROUP, - feat4$Count), y=feat4$Count) +
      geom_bar(stat="identity", fill="steelblue", width = 0.4) +
      coord_flip()+
      labs(x=" Group Type", y="Count", title="Customer Market Group") +
      theme(axis.text.x = element_text(vjust=0.5), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank() )+
      theme(legend.position="none")
    
    ggplotly(plot4)%>%
      layout(autosize=TRUE)
  })
  
  #################################### DEPLOYMENT #############################################
  
  sessionVariables = reactiveValues(deployments = list(), token = '')
  
  if(nchar(Sys.getenv('CP4D_HOSTNAME')) > 0 && nchar(Sys.getenv('CP4D_USERNAME')) > 0 && nchar(Sys.getenv('CP4D_PASSWORD')) > 0) {
    tryCatch({
      deploymentsResp = collectDeployments(input$username, input$password, "customer_segmentation_scoring_pipeline_function_deployment")
      serverVariables$deployments <- deploymentsResp$deployments
      serverVariables$token = deploymentsResp$token
    }, warning = function(w) {
      print(w$message)
    }, error = function(e) {
      print(e$message)
    })
  }
  
  # Set default hostname for CP4D API
#  observeEvent(session$clientData$url_hostname, {
#    updateTextInput(session, "hostname", value = session$clientData$url_hostname)
#  })
  
  # Enable buttons when inputs are provided
  observe({
    toggleState("authBtn", nchar(input$username) > 0 && nchar(input$password) > 0)
    toggleState("scoreBtn", nchar(input$endpoint) > 0 && nchar(input$token) > 0 && length(input$allCustomers_rows_selected) > 0)
  })
  
 #Handle CP4D API authentication button
  observeEvent(input$authBtn, {
    shinyjs::disable("authBtn")
    
    tryCatch({
      deploymentsResp = collectDeployments(input$username, input$password, "customer_segmentation_scoring_pipeline_function_deployment")
      serverVariables$deployments <- deploymentsResp$deployments
      serverVariables$token = deploymentsResp$token
    }, warning = function(w) {
      output$authError <- renderText(w$message)
    }, error = function(e) {
      output$authError <- renderText(e$message)
    })
    
    shinyjs::enable("authBtn")

    if(length(serverVariables$deployments) > 0) {
      updateSelectInput(session, "deploymentSelector", choices = names(serverVariables$deployments))
      shinyjs::hide(id = "authPanel")
      shinyjs::show(id = "deploymentPanel")
    }
  })
  
  # Handle model deployment dropdown switching
  observeEvent(input$deploymentSelector, {
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    output$deployment_guid <- renderText(selectedDeployment$guid)
    output$space_name <- renderText(selectedDeployment$space_name)
    #output$deployment_tags <- renderText(selectedDeployment$tags)
    output$scoring_url <- renderText(selectedDeployment$scoring_url)
    toggleState("scoreBtn", nchar(selectedDeployment$scoring_url) > 0 && nchar(serverVariables$token) > 0)
  })
  
  # Handle model deployment scoring button
  observeEvent(input$scoreBtn, {
    shinyjs::disable("scoreBtn")
    
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]

    response <- scoreModelDeployment(selectedDeployment$scoring_url, pipelineInput, serverVariables$token)
    #print(response)
    
    if(length(response$error) > 0) {
      output$scoringError <- renderText(toString(response$error))
    }
    else if(length(response$predictions) > 0) {
      shinyjs::hide(id = "deploymentPanel")
      
      sessionVariables$clusterMapping <- response$predictions[[1]]$values
      clusterFeatures <- names(select_if(cluster_df, is.numeric))
      
      names(sessionVariables$clusterMapping) <- pipelineInput$cust_id
      
      # Generate table of cluster mapping
      df <- data.frame(clusterID=t(t(sessionVariables$clusterMapping)))
      names(df) <- c("Segment ID")
      clusterMappingTable <- tibble::rownames_to_column(df, "Customer ID") %>%
        mutate_all(as.integer)
      
      # Generate tables of cluster features
      sessionVariables$featureTables <- list()
      for(clusterID in names(clusterFeatures)) {
        cluster <- clusterFeatures[[clusterID]]
        clusterTable <- list()
        for(feature in names(cluster)) {
          newFeatureName <- sub("CUSTOMER_", "", feature)
          newFeatureName <- sub("SUMMARY_", "", newFeatureName)
          clusterTable[[feature]] <- list(feature=newFeatureName, min=cluster[[feature]]$min, max=cluster[[feature]]$max)
        }
        sessionVariables$featureTables[[clusterID]] <- do.call(rbind.data.frame, clusterTable) %>%
          mutate_at(vars(min, max), funs(ifelse(grepl("NUMBER|MONTHS",feature), as.integer(.), dollar(.)))) %>%
          mutate(feature=sub("NUMBER_OF_|TOTAL_AMOUNT_OF_", "", feature))
        names(sessionVariables$featureTables[[clusterID]]) <- c("Feature", "Min", "Max")
      }
      
      
      lapply(names(sessionVariables$featureTables), function(id){
        output[[paste0("features-",id)]] <- renderTable(sessionVariables$featureTables[[id]], bordered = TRUE)
      })
      
      
      
      #removeUI("#topActionClients")
      shinyjs::hide(id = "rightPanel")
      
      clusters = list()
      for(custID in names(sessionVariables$clusterMapping)){
        clusterID <- sessionVariables$clusterMapping[custID]
        clusters[[toString(clusterID)]] <- c(clusters[[toString(clusterID)]], custID)
      }
      
      lapply(names(sessionVariables$featureTables), function(id){
        output[[paste0("features2-",id)]] <- renderTable(sessionVariables$featureTables[[id]], bordered = FALSE, width = "100%")
      })
      
      
      output$segmentClients <- renderUI(
        div(
          h3(paste("Segment",1), style = "text-align:center"),
          lapply(clusters[[1]], function(custID) {
            client <- clients[[custID]]
            clientButton(custID, client$name,paste0("profiles/", client$image), client$income, 1)
          }),
          panel(actionButton("refresh", "Back to Dashboard", class = "btn-primary btn-lg btn-block"))
        )
      )
      
      output$segmentTable <- renderUI(
        tableOutput(paste0("features2-", 1))
      )
      
      observeEvent(input$bar_clicked, {
        segment_num <- as.integer(input$bar_clicked)
        
        output$segmentClients <- renderUI(
          div(
            h3(paste("Segment",segment_num), style = "text-align:center"),
            lapply(clusters[[segment_num]], function(custID) {
              client <- clients[[custID]]
              clientButton(custID, client$name,paste0("profiles/", client$image), client$income, as.integer(input$bar_clicked))
            }),
            panel(actionButton("refresh", "Back to Dashboard", class = "btn-primary btn-lg btn-block"))
          )
        )
        
        output$segmentTable <- renderUI(
          tableOutput(paste0("features2-", segment_num))
        )
      })
      
    } else {
      output$scoringError <- renderText(response)
    }
    
    shinyjs::enable("scoreBtn")
  })
  
  
  output$pipelineInput <- renderText(rjson::toJSON(pipelineInput, indent = 2))
  #observeEvent(input$reauthenticateBtn, {
  #  shinyjs::show(id = "scoreBtnSection")
  #  removeUI(selector = "#scoringResponse > *", multiple = TRUE)
  #  shinyjs::show(id = "authPanel")
  #  shinyjs::hide(id = "deploymentPanel")
  #})
  
}
